<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="7.7.0">
<drawing>
<settings>
<setting alwaysvectorfont="no"/>
<setting verticaltext="up"/>
</settings>
<grid distance="50" unitdist="mil" unit="mil" style="dots" multiple="1" display="yes" altdistance="10" altunitdist="mil" altunit="mil"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="no" active="no"/>
<layer number="2" name="Route2" color="4" fill="3" visible="no" active="no"/>
<layer number="3" name="Route3" color="4" fill="3" visible="no" active="no"/>
<layer number="4" name="Route4" color="1" fill="4" visible="no" active="no"/>
<layer number="5" name="Route5" color="4" fill="4" visible="no" active="no"/>
<layer number="6" name="Route6" color="1" fill="8" visible="no" active="no"/>
<layer number="7" name="Route7" color="4" fill="8" visible="no" active="no"/>
<layer number="8" name="Route8" color="1" fill="2" visible="no" active="no"/>
<layer number="9" name="Route9" color="4" fill="2" visible="no" active="no"/>
<layer number="10" name="Route10" color="1" fill="7" visible="no" active="no"/>
<layer number="11" name="Route11" color="4" fill="7" visible="no" active="no"/>
<layer number="12" name="Route12" color="1" fill="5" visible="no" active="no"/>
<layer number="13" name="Route13" color="4" fill="5" visible="no" active="no"/>
<layer number="14" name="Route14" color="1" fill="6" visible="no" active="no"/>
<layer number="15" name="Route15" color="1" fill="6" visible="no" active="no"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="no" active="no"/>
<layer number="17" name="Pads" color="2" fill="1" visible="no" active="no"/>
<layer number="18" name="Vias" color="3" fill="1" visible="no" active="no"/>
<layer number="19" name="Unrouted" color="5" fill="1" visible="no" active="no"/>
<layer number="20" name="Dimension" color="10" fill="1" visible="no" active="no"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="22" name="bPlace" color="8" fill="1" visible="no" active="no"/>
<layer number="23" name="tOrigins" color="14" fill="1" visible="no" active="no"/>
<layer number="24" name="bOrigins" color="6" fill="1" visible="no" active="no"/>
<layer number="25" name="tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="26" name="bNames" color="8" fill="1" visible="no" active="no"/>
<layer number="27" name="tValues" color="7" fill="1" visible="no" active="no"/>
<layer number="28" name="bValues" color="8" fill="1" visible="no" active="no"/>
<layer number="29" name="tStop" color="15" fill="3" visible="no" active="no"/>
<layer number="30" name="bStop" color="15" fill="6" visible="no" active="no"/>
<layer number="31" name="tCream" color="13" fill="4" visible="no" active="no"/>
<layer number="32" name="bCream" color="5" fill="5" visible="no" active="no"/>
<layer number="33" name="tFinish" color="6" fill="3" visible="no" active="no"/>
<layer number="34" name="bFinish" color="6" fill="6" visible="no" active="no"/>
<layer number="35" name="tGlue" color="7" fill="4" visible="no" active="no"/>
<layer number="36" name="bGlue" color="7" fill="5" visible="no" active="no"/>
<layer number="37" name="tTest" color="7" fill="1" visible="no" active="no"/>
<layer number="38" name="bTest" color="7" fill="1" visible="no" active="no"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="no" active="no"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="no" active="no"/>
<layer number="41" name="tRestrict" color="4" fill="7" visible="no" active="no"/>
<layer number="42" name="bRestrict" color="1" fill="7" visible="no" active="no"/>
<layer number="43" name="vRestrict" color="5" fill="7" visible="no" active="no"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="no"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="no"/>
<layer number="46" name="Milling" color="3" fill="1" visible="no" active="no"/>
<layer number="47" name="Koty" color="7" fill="1" visible="no" active="no"/>
<layer number="48" name="Freza" color="7" fill="1" visible="no" active="no"/>
<layer number="49" name="Reference" color="7" fill="1" visible="no" active="no"/>
<layer number="50" name="dxf" color="7" fill="1" visible="no" active="no"/>
<layer number="51" name="tPotisk" color="14" fill="1" visible="no" active="no"/>
<layer number="52" name="bPotisk" color="6" fill="1" visible="no" active="no"/>
<layer number="53" name="tPadExt" color="7" fill="1" visible="no" active="no"/>
<layer number="54" name="bPadExt" color="1" fill="1" visible="no" active="no"/>
<layer number="88" name="SimResults" color="9" fill="1" visible="no" active="no"/>
<layer number="89" name="SimProbes" color="9" fill="1" visible="no" active="no"/>
<layer number="90" name="Modules" color="5" fill="1" visible="yes" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
<layer number="98" name="Guide" color="6" fill="1" visible="yes" active="yes"/>
<layer number="99" name="SpiceOrder" color="5" fill="1" visible="no" active="no"/>
<layer number="100" name="Trafo" color="7" fill="1" visible="yes" active="yes"/>
<layer number="101" name="Frames" color="11" fill="1" visible="yes" active="yes"/>
<layer number="102" name="Potisk" color="14" fill="1" visible="yes" active="yes"/>
<layer number="105" name="bFrames" color="3" fill="1" visible="yes" active="yes"/>
<layer number="160" name="FAB" color="7" fill="1" visible="yes" active="yes"/>
<layer number="200" name="200bmp" color="1" fill="10" visible="no" active="no"/>
<layer number="250" name="Descript" color="3" fill="1" visible="no" active="no"/>
<layer number="251" name="SMDround" color="12" fill="11" visible="no" active="no"/>
</layers>
<schematic xreflabel="%F%N/S%S" xrefpart="/%S.%C%R">
<libraries>
<library name="74499">
<packages>
<package name="DIL20">
<wire x1="-0.635" y1="1.27" x2="23.495" y2="1.27" width="0.254" layer="21"/>
<wire x1="23.495" y1="1.27" x2="23.495" y2="6.35" width="0.254" layer="21"/>
<wire x1="23.495" y1="6.35" x2="-0.635" y2="6.35" width="0.254" layer="21"/>
<wire x1="-0.635" y1="6.35" x2="-0.635" y2="5.08" width="0.254" layer="21"/>
<wire x1="-0.635" y1="5.08" x2="0.635" y2="5.08" width="0.254" layer="21"/>
<wire x1="0.635" y1="5.08" x2="0.635" y2="2.54" width="0.254" layer="21"/>
<wire x1="0.635" y1="2.54" x2="-0.635" y2="2.54" width="0.254" layer="21"/>
<wire x1="-0.635" y1="2.54" x2="-0.635" y2="1.27" width="0.254" layer="21"/>
<wire x1="24.13" y1="-1.27" x2="24.13" y2="8.89" width="0.2032" layer="51"/>
<wire x1="24.13" y1="8.89" x2="-1.27" y2="8.89" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="8.89" x2="-1.27" y2="5.08" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="5.08" x2="0" y2="5.08" width="0.2032" layer="51"/>
<wire x1="0" y1="5.08" x2="0" y2="2.54" width="0.2032" layer="51"/>
<wire x1="0" y1="2.54" x2="-1.27" y2="2.54" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="2.54" x2="-1.27" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="-1.27" x2="24.13" y2="-1.27" width="0.2032" layer="51"/>
<pad name="1" x="0" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="2" x="2.54" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="3" x="5.08" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="4" x="7.62" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="5" x="10.16" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="6" x="12.7" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="7" x="15.24" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="8" x="17.78" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="9" x="20.32" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="10" x="22.86" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="11" x="22.86" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="12" x="20.32" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="13" x="17.78" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="14" x="15.24" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="15" x="12.7" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="16" x="10.16" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="17" x="7.62" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="18" x="5.08" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="19" x="2.54" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="20" x="0" y="7.62" drill="0.8128" diameter="1.4986"/>
<text x="8.89" y="4.445" size="1.27" layer="25">&gt;NAME</text>
<text x="8.89" y="1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="8.89" y="3.175" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
</packages>
<symbols>
<symbol name="PWRN">
<text x="-1.27" y="-1.27" size="1.27" layer="95">&gt;NAME</text>
<text x="0.635" y="-6.985" size="1.27" layer="95" rot="R90">GND</text>
<text x="0.635" y="3.81" size="1.27" layer="95" rot="R90">VCC</text>
<pin name="GND" x="0" y="-10.16" visible="pad" length="short" direction="pwr" rot="R90"/>
<pin name="VCC" x="0" y="10.16" visible="pad" length="short" direction="pwr" rot="R270"/>
</symbol>
<symbol name="244">
<wire x1="0" y1="16.51" x2="0" y2="17.78" width="0.254" layer="94"/>
<wire x1="15.24" y1="17.78" x2="0" y2="17.78" width="0.254" layer="94"/>
<wire x1="15.24" y1="17.78" x2="15.24" y2="16.51" width="0.254" layer="94"/>
<wire x1="0" y1="6.35" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="15.24" y1="0" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="15.24" y1="0" x2="15.24" y2="6.35" width="0.254" layer="94"/>
<text x="0" y="18.415" size="1.524" layer="95">&gt;NAME</text>
<text x="0" y="-1.905" size="1.524" layer="96">&gt;VALUE</text>
<pin name="G" x="-7.62" y="2.54" direction="in" function="dot"/>
</symbol>
<symbol name="244A">
<wire x1="-7.62" y1="1.27" x2="-7.62" y2="-1.27" width="0.254" layer="94"/>
<wire x1="7.62" y1="1.27" x2="7.62" y2="-1.27" width="0.254" layer="94"/>
<text x="-0.635" y="-0.635" size="1.524" layer="94">&gt;GATE</text>
<pin name="A" x="-15.24" y="0" direction="in"/>
<pin name="Y" x="15.24" y="0" direction="hiz" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="74244" prefix="IC" uservalue="yes">
<gates>
<gate name="P" symbol="PWRN" x="-5.08" y="0" addlevel="request"/>
<gate name="A" symbol="244" x="17.78" y="5.08" swaplevel="1"/>
<gate name="A1" symbol="244A" x="25.4" y="20.32" swaplevel="2"/>
<gate name="A2" symbol="244A" x="25.4" y="17.78" swaplevel="2"/>
<gate name="A3" symbol="244A" x="25.4" y="15.24" swaplevel="2"/>
<gate name="A4" symbol="244A" x="25.4" y="12.7" swaplevel="2"/>
<gate name="B" symbol="244" x="17.78" y="-17.78" swaplevel="1"/>
<gate name="B1" symbol="244A" x="25.4" y="-2.54" swaplevel="2"/>
<gate name="B2" symbol="244A" x="25.4" y="-5.08" swaplevel="2"/>
<gate name="B3" symbol="244A" x="25.4" y="-7.62" swaplevel="2"/>
<gate name="B4" symbol="244A" x="25.4" y="-10.16" swaplevel="2"/>
</gates>
<devices>
<device name="" package="DIL20">
<connects>
<connect gate="A" pin="G" pad="1"/>
<connect gate="A1" pin="A" pad="2"/>
<connect gate="A1" pin="Y" pad="18"/>
<connect gate="A2" pin="A" pad="4"/>
<connect gate="A2" pin="Y" pad="16"/>
<connect gate="A3" pin="A" pad="6"/>
<connect gate="A3" pin="Y" pad="14"/>
<connect gate="A4" pin="A" pad="8"/>
<connect gate="A4" pin="Y" pad="12"/>
<connect gate="B" pin="G" pad="19"/>
<connect gate="B1" pin="A" pad="11"/>
<connect gate="B1" pin="Y" pad="9"/>
<connect gate="B2" pin="A" pad="13"/>
<connect gate="B2" pin="Y" pad="7"/>
<connect gate="B3" pin="A" pad="15"/>
<connect gate="B3" pin="Y" pad="5"/>
<connect gate="B4" pin="A" pad="17"/>
<connect gate="B4" pin="Y" pad="3"/>
<connect gate="P" pin="GND" pad="10"/>
<connect gate="P" pin="VCC" pad="20"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="40XX">
<packages>
<package name="DIL16">
<wire x1="-0.635" y1="1.27" x2="18.415" y2="1.27" width="0.254" layer="21"/>
<wire x1="18.415" y1="1.27" x2="18.415" y2="6.35" width="0.254" layer="21"/>
<wire x1="18.415" y1="6.35" x2="-0.635" y2="6.35" width="0.254" layer="21"/>
<wire x1="-0.635" y1="6.35" x2="-0.635" y2="5.08" width="0.254" layer="21"/>
<wire x1="-0.635" y1="5.08" x2="0.635" y2="5.08" width="0.254" layer="21"/>
<wire x1="0.635" y1="5.08" x2="0.635" y2="2.54" width="0.254" layer="21"/>
<wire x1="0.635" y1="2.54" x2="-0.635" y2="2.54" width="0.254" layer="21"/>
<wire x1="-0.635" y1="2.54" x2="-0.635" y2="1.27" width="0.254" layer="21"/>
<wire x1="19.05" y1="-1.27" x2="19.05" y2="8.89" width="0.2032" layer="51"/>
<wire x1="19.05" y1="8.89" x2="-1.27" y2="8.89" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="8.89" x2="-1.27" y2="5.08" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="5.08" x2="0" y2="5.08" width="0.2032" layer="51"/>
<wire x1="0" y1="5.08" x2="0" y2="2.54" width="0.2032" layer="51"/>
<wire x1="0" y1="2.54" x2="-1.27" y2="2.54" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="2.54" x2="-1.27" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="-1.27" x2="19.05" y2="-1.27" width="0.2032" layer="51"/>
<pad name="1" x="0" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="2" x="2.54" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="3" x="5.08" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="4" x="7.62" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="5" x="10.16" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="6" x="12.7" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="7" x="15.24" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="8" x="17.78" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="9" x="17.78" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="10" x="15.24" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="11" x="12.7" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="12" x="10.16" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="13" x="7.62" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="14" x="5.08" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="15" x="2.54" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="16" x="0" y="7.62" drill="0.8128" diameter="1.4986"/>
<text x="6.35" y="4.445" size="1.27" layer="25">&gt;NAME</text>
<text x="6.35" y="1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="6.35" y="3.175" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
</packages>
<symbols>
<symbol name="4040">
<wire x1="-7.62" y1="-17.78" x2="7.62" y2="-17.78" width="0.254" layer="94"/>
<wire x1="7.62" y1="-17.78" x2="7.62" y2="15.24" width="0.254" layer="94"/>
<wire x1="7.62" y1="15.24" x2="-7.62" y2="15.24" width="0.254" layer="94"/>
<wire x1="-7.62" y1="15.24" x2="-7.62" y2="-17.78" width="0.254" layer="94"/>
<text x="-7.62" y="16.51" size="1.524" layer="95">&gt;NAME</text>
<text x="-7.62" y="-20.32" size="1.524" layer="96">&gt;VALUE</text>
<pin name="Q12" x="15.24" y="-15.24" direction="out" rot="R180"/>
<pin name="Q6" x="15.24" y="0" direction="out" rot="R180"/>
<pin name="Q5" x="15.24" y="2.54" direction="out" rot="R180"/>
<pin name="Q7" x="15.24" y="-2.54" direction="out" rot="R180"/>
<pin name="Q4" x="15.24" y="5.08" direction="out" rot="R180"/>
<pin name="Q3" x="15.24" y="7.62" direction="out" rot="R180"/>
<pin name="Q2" x="15.24" y="10.16" direction="out" rot="R180"/>
<pin name="Q1" x="15.24" y="12.7" direction="out" rot="R180"/>
<pin name="P1" x="-15.24" y="12.7" direction="in" function="clk"/>
<pin name="RES" x="-15.24" y="-15.24" direction="in"/>
<pin name="Q9" x="15.24" y="-7.62" direction="out" rot="R180"/>
<pin name="Q8" x="15.24" y="-5.08" direction="out" rot="R180"/>
<pin name="Q10" x="15.24" y="-10.16" direction="out" rot="R180"/>
<pin name="Q11" x="15.24" y="-12.7" direction="out" rot="R180"/>
</symbol>
<symbol name="PWRN">
<text x="-0.635" y="-0.635" size="1.27" layer="95">&gt;NAME</text>
<text x="0.635" y="-6.985" size="1.27" layer="95" rot="R90">GND</text>
<text x="0.635" y="3.81" size="1.27" layer="95" rot="R90">VCC</text>
<pin name="GND" x="0" y="-10.16" visible="pad" length="short" direction="pwr" rot="R90"/>
<pin name="VCC" x="0" y="10.16" visible="pad" length="short" direction="pwr" rot="R270"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="4040" prefix="IC" uservalue="yes">
<gates>
<gate name="A" symbol="4040" x="20.32" y="0"/>
<gate name="P" symbol="PWRN" x="-5.08" y="0" addlevel="request"/>
</gates>
<devices>
<device name="" package="DIL16">
<connects>
<connect gate="A" pin="P1" pad="10"/>
<connect gate="A" pin="Q1" pad="9"/>
<connect gate="A" pin="Q10" pad="14"/>
<connect gate="A" pin="Q11" pad="15"/>
<connect gate="A" pin="Q12" pad="1"/>
<connect gate="A" pin="Q2" pad="7"/>
<connect gate="A" pin="Q3" pad="6"/>
<connect gate="A" pin="Q4" pad="5"/>
<connect gate="A" pin="Q5" pad="3"/>
<connect gate="A" pin="Q6" pad="2"/>
<connect gate="A" pin="Q7" pad="4"/>
<connect gate="A" pin="Q8" pad="13"/>
<connect gate="A" pin="Q9" pad="12"/>
<connect gate="A" pin="RES" pad="11"/>
<connect gate="P" pin="GND" pad="8"/>
<connect gate="P" pin="VCC" pad="16"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="PASIV">
<packages>
<package name="KER-C">
<wire x1="-1.016" y1="-1.27" x2="-1.016" y2="1.27" width="0.254" layer="21"/>
<wire x1="-1.016" y1="1.27" x2="6.096" y2="1.27" width="0.254" layer="21"/>
<wire x1="6.096" y1="1.27" x2="6.096" y2="-1.27" width="0.254" layer="21"/>
<wire x1="6.096" y1="-1.27" x2="-1.016" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-1.016" y1="-1.27" x2="6.096" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="6.096" y1="-1.27" x2="6.096" y2="1.27" width="0.2032" layer="51"/>
<wire x1="6.096" y1="1.27" x2="-1.016" y2="1.27" width="0.2032" layer="51"/>
<wire x1="-1.016" y1="1.27" x2="-1.016" y2="-1.27" width="0.2032" layer="51"/>
<pad name="1" x="0" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="2" x="5.08" y="0" drill="0.8128" diameter="1.4986"/>
<text x="1.27" y="-0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="0.635" y="1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="0.635" y="1.905" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="KER-C10">
<wire x1="-5" y1="-2" x2="-5" y2="2" width="0.254" layer="21"/>
<wire x1="-5" y1="2" x2="5" y2="2" width="0.254" layer="21"/>
<wire x1="5" y1="2" x2="5" y2="-2" width="0.254" layer="21"/>
<wire x1="5" y1="-2" x2="-5" y2="-2" width="0.254" layer="21"/>
<wire x1="-5" y1="-2" x2="5" y2="-2" width="0.2032" layer="51"/>
<wire x1="5" y1="-2" x2="5" y2="2" width="0.2032" layer="51"/>
<wire x1="5" y1="2" x2="-5" y2="2" width="0.2032" layer="51"/>
<wire x1="-5" y1="2" x2="-5" y2="-2" width="0.2032" layer="51"/>
<pad name="1" x="-2.54" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="2" x="2.54" y="0" drill="0.8128" diameter="1.4986"/>
<text x="-1.27" y="-0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="2.54" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.905" y="2.54" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="E-TANT-5">
<wire x1="-2.032" y1="0" x2="-0.508" y2="0" width="0.3048" layer="21"/>
<wire x1="-1.27" y1="0.762" x2="-1.27" y2="-0.762" width="0.3048" layer="21"/>
<wire x1="-0.127" y1="1.27" x2="-1.397" y2="1.27" width="0.2032" layer="51"/>
<wire x1="-0.762" y1="0.635" x2="-0.762" y2="1.905" width="0.2032" layer="51"/>
<circle x="0" y="0" radius="2.413" width="0.254" layer="21"/>
<circle x="0" y="0" radius="2.413" width="0.2032" layer="51"/>
<pad name="K" x="1.27" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="A" x="-1.27" y="0" drill="0.8128" diameter="1.4986"/>
<text x="1.905" y="-1.905" size="1.27" layer="25" rot="R90">&gt;NAME</text>
<text x="-2.54" y="2.54" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.905" y="2.54" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="R-NET8A">
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-1.27" y1="-1.27" x2="21.59" y2="-1.27" width="0.254" layer="21"/>
<wire x1="21.59" y1="1.27" x2="21.59" y2="-1.27" width="0.254" layer="21"/>
<wire x1="21.59" y1="1.27" x2="-1.27" y2="1.27" width="0.254" layer="21"/>
<wire x1="-1.27" y1="-1.27" x2="21.59" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="21.59" y1="-1.27" x2="21.59" y2="1.27" width="0.2032" layer="51"/>
<wire x1="21.59" y1="1.27" x2="-1.27" y2="1.27" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-1.4605" y1="1.27" x2="-1.4605" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-1.651" y1="1.27" x2="-1.651" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-1.651" y1="1.27" x2="-1.4605" y2="1.27" width="0.2032" layer="51"/>
<wire x1="-1.4605" y1="1.27" x2="-1.27" y2="1.27" width="0.2032" layer="51"/>
<wire x1="-1.651" y1="-1.27" x2="-1.4605" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-1.4605" y1="-1.27" x2="-1.27" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-1.651" y1="1.27" x2="-1.8415" y2="1.27" width="0.2032" layer="51"/>
<wire x1="-1.8415" y1="1.27" x2="-2.032" y2="1.27" width="0.2032" layer="51"/>
<wire x1="-1.651" y1="-1.27" x2="-2.032" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-2.032" y1="1.27" x2="-2.032" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-1.524" y1="1.27" x2="-1.524" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-1.778" y1="1.27" x2="-1.778" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-1.778" y1="1.27" x2="-1.524" y2="1.27" width="0.254" layer="21"/>
<wire x1="-1.524" y1="1.27" x2="-1.27" y2="1.27" width="0.254" layer="21"/>
<wire x1="-1.778" y1="-1.27" x2="-1.524" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-1.524" y1="-1.27" x2="-1.27" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-1.778" y1="1.27" x2="-2.032" y2="1.27" width="0.254" layer="21"/>
<wire x1="-1.778" y1="-1.27" x2="-2.032" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-2.032" y1="1.27" x2="-2.032" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-1.8415" y1="1.27" x2="-1.8415" y2="-1.27" width="0.2032" layer="51"/>
<pad name="1" x="0" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="2" x="2.54" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="3" x="5.08" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="4" x="7.62" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="5" x="10.16" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="6" x="12.7" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="7" x="15.24" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="8" x="17.78" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="9" x="20.32" y="0" drill="0.8128" diameter="1.4986"/>
<text x="1.27" y="-0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="8.89" y="-0.635" size="1.016" layer="27">&gt;VALUE</text>
<text x="6.35" y="1.905" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
</packages>
<symbols>
<symbol name="KOND">
<wire x1="-2.54" y1="0" x2="-0.762" y2="0" width="0.1524" layer="94"/>
<wire x1="0.762" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="-0.762" y1="-2.54" x2="-0.762" y2="0" width="0.508" layer="94"/>
<wire x1="0.762" y1="-2.54" x2="0.762" y2="0" width="0.508" layer="94"/>
<wire x1="0.762" y1="0" x2="0.762" y2="2.54" width="0.508" layer="94"/>
<wire x1="-0.762" y1="0" x2="-0.762" y2="2.54" width="0.508" layer="94"/>
<text x="-2.54" y="3.556" size="1.524" layer="95">&gt;NAME</text>
<text x="-2.54" y="-5.08" size="1.524" layer="96">&gt;VALUE</text>
<pin name="1" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="EL">
<wire x1="-2.54" y1="0" x2="-0.762" y2="0" width="0.1524" layer="94"/>
<wire x1="0.762" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="-0.762" y1="-2.54" x2="-0.762" y2="0" width="0.508" layer="94"/>
<wire x1="0.762" y1="-2.54" x2="0.762" y2="0" width="0.508" layer="94"/>
<wire x1="-2.032" y1="1.27" x2="-2.032" y2="2.54" width="0.254" layer="94"/>
<wire x1="-2.667" y1="1.905" x2="-1.397" y2="1.905" width="0.254" layer="94"/>
<wire x1="0.762" y1="0" x2="0.762" y2="2.54" width="0.508" layer="94"/>
<wire x1="-0.762" y1="0" x2="-0.762" y2="2.54" width="0.508" layer="94"/>
<text x="-2.54" y="3.556" size="1.524" layer="95">&gt;NAME</text>
<text x="-2.54" y="-5.08" size="1.524" layer="96">&gt;VALUE</text>
<pin name="A" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="K" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="R-NET8">
<wire x1="0" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="15.24" y1="0" x2="17.78" y2="0" width="0.1524" layer="94"/>
<wire x1="12.7" y1="0" x2="15.24" y2="0" width="0.1524" layer="94"/>
<wire x1="10.16" y1="0" x2="12.7" y2="0" width="0.1524" layer="94"/>
<wire x1="7.62" y1="0" x2="10.16" y2="0" width="0.1524" layer="94"/>
<wire x1="5.08" y1="0" x2="7.62" y2="0" width="0.1524" layer="94"/>
<wire x1="2.54" y1="0" x2="5.08" y2="0" width="0.1524" layer="94"/>
<wire x1="-1.016" y1="-7.62" x2="-1.016" y2="-2.54" width="0.254" layer="94"/>
<wire x1="1.016" y1="-2.54" x2="1.016" y2="-7.62" width="0.254" layer="94"/>
<wire x1="1.016" y1="-7.62" x2="0" y2="-7.62" width="0.254" layer="94"/>
<wire x1="-1.016" y1="-2.54" x2="0" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="1.016" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-7.62" x2="-1.016" y2="-7.62" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="0" y2="0" width="0.1524" layer="94"/>
<wire x1="1.524" y1="-7.62" x2="1.524" y2="-2.54" width="0.254" layer="94"/>
<wire x1="3.556" y1="-2.54" x2="3.556" y2="-7.62" width="0.254" layer="94"/>
<wire x1="3.556" y1="-7.62" x2="2.54" y2="-7.62" width="0.254" layer="94"/>
<wire x1="1.524" y1="-2.54" x2="2.54" y2="-2.54" width="0.254" layer="94"/>
<wire x1="2.54" y1="-2.54" x2="3.556" y2="-2.54" width="0.254" layer="94"/>
<wire x1="2.54" y1="-7.62" x2="1.524" y2="-7.62" width="0.254" layer="94"/>
<wire x1="2.54" y1="-2.54" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="4.064" y1="-7.62" x2="4.064" y2="-2.54" width="0.254" layer="94"/>
<wire x1="6.096" y1="-2.54" x2="6.096" y2="-7.62" width="0.254" layer="94"/>
<wire x1="6.096" y1="-7.62" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<wire x1="4.064" y1="-2.54" x2="5.08" y2="-2.54" width="0.254" layer="94"/>
<wire x1="5.08" y1="-2.54" x2="6.096" y2="-2.54" width="0.254" layer="94"/>
<wire x1="5.08" y1="-7.62" x2="4.064" y2="-7.62" width="0.254" layer="94"/>
<wire x1="5.08" y1="-2.54" x2="5.08" y2="0" width="0.1524" layer="94"/>
<wire x1="6.604" y1="-7.62" x2="6.604" y2="-2.54" width="0.254" layer="94"/>
<wire x1="8.636" y1="-2.54" x2="8.636" y2="-7.62" width="0.254" layer="94"/>
<wire x1="8.636" y1="-7.62" x2="7.62" y2="-7.62" width="0.254" layer="94"/>
<wire x1="6.604" y1="-2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="8.636" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-7.62" x2="6.604" y2="-7.62" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="7.62" y2="0" width="0.1524" layer="94"/>
<wire x1="9.144" y1="-7.62" x2="9.144" y2="-2.54" width="0.254" layer="94"/>
<wire x1="11.176" y1="-2.54" x2="11.176" y2="-7.62" width="0.254" layer="94"/>
<wire x1="11.176" y1="-7.62" x2="10.16" y2="-7.62" width="0.254" layer="94"/>
<wire x1="9.144" y1="-2.54" x2="10.16" y2="-2.54" width="0.254" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="11.176" y2="-2.54" width="0.254" layer="94"/>
<wire x1="10.16" y1="-7.62" x2="9.144" y2="-7.62" width="0.254" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="10.16" y2="0" width="0.1524" layer="94"/>
<wire x1="11.684" y1="-7.62" x2="11.684" y2="-2.54" width="0.254" layer="94"/>
<wire x1="13.716" y1="-2.54" x2="13.716" y2="-7.62" width="0.254" layer="94"/>
<wire x1="13.716" y1="-7.62" x2="12.7" y2="-7.62" width="0.254" layer="94"/>
<wire x1="11.684" y1="-2.54" x2="12.7" y2="-2.54" width="0.254" layer="94"/>
<wire x1="12.7" y1="-2.54" x2="13.716" y2="-2.54" width="0.254" layer="94"/>
<wire x1="12.7" y1="-7.62" x2="11.684" y2="-7.62" width="0.254" layer="94"/>
<wire x1="12.7" y1="-2.54" x2="12.7" y2="0" width="0.1524" layer="94"/>
<wire x1="14.224" y1="-7.62" x2="14.224" y2="-2.54" width="0.254" layer="94"/>
<wire x1="16.256" y1="-2.54" x2="16.256" y2="-7.62" width="0.254" layer="94"/>
<wire x1="16.256" y1="-7.62" x2="15.24" y2="-7.62" width="0.254" layer="94"/>
<wire x1="14.224" y1="-2.54" x2="15.24" y2="-2.54" width="0.254" layer="94"/>
<wire x1="15.24" y1="-2.54" x2="16.256" y2="-2.54" width="0.254" layer="94"/>
<wire x1="15.24" y1="-7.62" x2="14.224" y2="-7.62" width="0.254" layer="94"/>
<wire x1="15.24" y1="-2.54" x2="15.24" y2="0" width="0.1524" layer="94"/>
<wire x1="16.764" y1="-7.62" x2="16.764" y2="-2.54" width="0.254" layer="94"/>
<wire x1="18.796" y1="-2.54" x2="18.796" y2="-7.62" width="0.254" layer="94"/>
<wire x1="18.796" y1="-7.62" x2="17.78" y2="-7.62" width="0.254" layer="94"/>
<wire x1="16.764" y1="-2.54" x2="17.78" y2="-2.54" width="0.254" layer="94"/>
<wire x1="17.78" y1="-2.54" x2="18.796" y2="-2.54" width="0.254" layer="94"/>
<wire x1="17.78" y1="-7.62" x2="16.764" y2="-7.62" width="0.254" layer="94"/>
<wire x1="17.78" y1="-2.54" x2="17.78" y2="0" width="0.1524" layer="94"/>
<circle x="0" y="0" radius="0.2032" width="0.4064" layer="94"/>
<circle x="15.24" y="0" radius="0.2032" width="0.4064" layer="94"/>
<circle x="12.7" y="0" radius="0.2032" width="0.4064" layer="94"/>
<circle x="10.16" y="0" radius="0.2032" width="0.4064" layer="94"/>
<circle x="7.62" y="0" radius="0.2032" width="0.4064" layer="94"/>
<circle x="5.08" y="0" radius="0.2032" width="0.4064" layer="94"/>
<circle x="2.54" y="0" radius="0.2032" width="0.4064" layer="94"/>
<text x="-1.905" y="-7.62" size="1.524" layer="95" rot="R90">&gt;NAME</text>
<text x="20.955" y="-7.62" size="1.524" layer="96" rot="R90">&gt;VALUE</text>
<pin name="1" x="-2.54" y="0" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="0" y="-10.16" visible="pad" length="short" direction="pas" swaplevel="1" rot="R90"/>
<pin name="3" x="2.54" y="-10.16" visible="pad" length="short" direction="pas" swaplevel="1" rot="R90"/>
<pin name="4" x="5.08" y="-10.16" visible="pad" length="short" direction="pas" swaplevel="1" rot="R90"/>
<pin name="5" x="7.62" y="-10.16" visible="pad" length="short" direction="pas" swaplevel="1" rot="R90"/>
<pin name="6" x="10.16" y="-10.16" visible="pad" length="short" direction="pas" swaplevel="1" rot="R90"/>
<pin name="7" x="12.7" y="-10.16" visible="pad" length="short" direction="pas" swaplevel="1" rot="R90"/>
<pin name="8" x="15.24" y="-10.16" visible="pad" length="short" direction="pas" swaplevel="1" rot="R90"/>
<pin name="9" x="17.78" y="-10.16" visible="pad" length="short" direction="pas" swaplevel="1" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="KER-C" prefix="C" uservalue="yes">
<gates>
<gate name="A" symbol="KOND" x="0" y="0" swaplevel="1"/>
</gates>
<devices>
<device name="" package="KER-C">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="10" package="KER-C10">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="E-TANT-5" prefix="C" uservalue="yes">
<gates>
<gate name="A" symbol="EL" x="0" y="0" swaplevel="1"/>
</gates>
<devices>
<device name="" package="E-TANT-5">
<connects>
<connect gate="A" pin="A" pad="A"/>
<connect gate="A" pin="K" pad="K"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="R-NET8A" prefix="RA" uservalue="yes">
<gates>
<gate name="A" symbol="R-NET8" x="-8.89" y="5.08" swaplevel="1"/>
</gates>
<devices>
<device name="" package="R-NET8A">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
<connect gate="A" pin="9" pad="9"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="SVORKY">
<packages>
<package name="DIL40">
<wire x1="-0.635" y1="1.27" x2="48.895" y2="1.27" width="0.254" layer="21"/>
<wire x1="48.895" y1="1.27" x2="48.895" y2="13.97" width="0.254" layer="21"/>
<wire x1="48.895" y1="13.97" x2="-0.635" y2="13.97" width="0.254" layer="21"/>
<wire x1="-0.635" y1="13.97" x2="-0.635" y2="8.89" width="0.254" layer="21"/>
<wire x1="-0.635" y1="8.89" x2="0.635" y2="8.89" width="0.254" layer="21"/>
<wire x1="0.635" y1="8.89" x2="0.635" y2="6.35" width="0.254" layer="21"/>
<wire x1="0.635" y1="6.35" x2="-0.635" y2="6.35" width="0.254" layer="21"/>
<wire x1="-0.635" y1="6.35" x2="-0.635" y2="1.27" width="0.254" layer="21"/>
<wire x1="-1.27" y1="-1.27" x2="49.53" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="49.53" y1="16.51" x2="49.53" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="49.53" y1="16.51" x2="-1.27" y2="16.51" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="16.51" x2="-1.27" y2="8.89" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="8.89" x2="0" y2="8.89" width="0.2032" layer="51"/>
<wire x1="0" y1="6.35" x2="0" y2="8.89" width="0.2032" layer="51"/>
<wire x1="0" y1="6.35" x2="-1.27" y2="6.35" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="-1.27" x2="-1.27" y2="6.35" width="0.2032" layer="51"/>
<pad name="1" x="0" y="0" drill="0.9" diameter="1.6764"/>
<text x="21.59" y="8.255" size="1.27" layer="25">&gt;NAME</text>
<text x="21.59" y="5.715" size="1.016" layer="27">&gt;VALUE</text>
<text x="21.59" y="6.985" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<pad name="2" x="2.54" y="0" drill="0.9" diameter="1.6764"/>
<pad name="3" x="5.08" y="0" drill="0.9" diameter="1.6764"/>
<pad name="4" x="7.62" y="0" drill="0.9" diameter="1.6764"/>
<pad name="5" x="10.16" y="0" drill="0.9" diameter="1.6764"/>
<pad name="6" x="12.7" y="0" drill="0.9" diameter="1.6764"/>
<pad name="7" x="15.24" y="0" drill="0.9" diameter="1.6764"/>
<pad name="8" x="17.78" y="0" drill="0.9" diameter="1.6764"/>
<pad name="9" x="20.32" y="0" drill="0.9" diameter="1.6764"/>
<pad name="10" x="22.86" y="0" drill="0.9" diameter="1.6764"/>
<pad name="11" x="25.4" y="0" drill="0.9" diameter="1.6764"/>
<pad name="12" x="27.94" y="0" drill="0.9" diameter="1.6764"/>
<pad name="13" x="30.48" y="0" drill="0.9" diameter="1.6764"/>
<pad name="14" x="33.02" y="0" drill="0.9" diameter="1.6764"/>
<pad name="15" x="35.56" y="0" drill="0.9" diameter="1.6764"/>
<pad name="16" x="38.1" y="0" drill="0.9" diameter="1.6764"/>
<pad name="17" x="40.64" y="0" drill="0.9" diameter="1.6764"/>
<pad name="18" x="43.18" y="0" drill="0.9" diameter="1.6764"/>
<pad name="19" x="45.72" y="0" drill="0.9" diameter="1.6764"/>
<pad name="20" x="48.26" y="0" drill="0.9" diameter="1.6764"/>
<pad name="21" x="48.26" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="22" x="45.72" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="23" x="43.18" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="24" x="40.64" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="25" x="38.1" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="26" x="35.56" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="27" x="33.02" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="28" x="30.48" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="29" x="27.94" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="30" x="25.4" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="31" x="22.86" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="32" x="20.32" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="33" x="17.78" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="34" x="15.24" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="35" x="12.7" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="36" x="10.16" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="37" x="7.62" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="38" x="5.08" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="39" x="2.54" y="15.24" drill="0.9" diameter="1.6764"/>
<pad name="40" x="0" y="15.24" drill="0.9" diameter="1.6764"/>
</package>
</packages>
<symbols>
<symbol name="DIL40">
<wire x1="-8.89" y1="-26.67" x2="8.89" y2="-26.67" width="0.254" layer="94"/>
<wire x1="8.89" y1="-26.67" x2="8.89" y2="26.67" width="0.254" layer="94"/>
<wire x1="8.89" y1="26.67" x2="1.27" y2="26.67" width="0.254" layer="94"/>
<wire x1="-1.27" y1="26.67" x2="-8.89" y2="26.67" width="0.254" layer="94"/>
<wire x1="-8.89" y1="26.67" x2="-8.89" y2="-26.67" width="0.254" layer="94"/>
<text x="-8.89" y="27.94" size="1.524" layer="95">&gt;NAME</text>
<text x="-8.89" y="-29.21" size="1.524" layer="96">&gt;VALUE</text>
<pin name="1" x="-13.97" y="24.13" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="2" x="-13.97" y="21.59" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="3" x="-13.97" y="19.05" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="4" x="-13.97" y="16.51" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="5" x="-13.97" y="13.97" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="6" x="-13.97" y="11.43" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="7" x="-13.97" y="8.89" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="8" x="-13.97" y="6.35" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="9" x="-13.97" y="3.81" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="10" x="-13.97" y="1.27" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="11" x="-13.97" y="-1.27" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="12" x="-13.97" y="-3.81" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="13" x="-13.97" y="-6.35" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="14" x="-13.97" y="-8.89" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="15" x="-13.97" y="-11.43" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="16" x="-13.97" y="-13.97" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="17" x="-13.97" y="-16.51" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="18" x="-13.97" y="-19.05" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="19" x="-13.97" y="-21.59" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="20" x="-13.97" y="-24.13" visible="pad" length="middle" direction="pas" swaplevel="1"/>
<pin name="21" x="13.97" y="-24.13" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="22" x="13.97" y="-21.59" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="23" x="13.97" y="-19.05" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="24" x="13.97" y="-16.51" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="25" x="13.97" y="-13.97" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="26" x="13.97" y="-11.43" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="27" x="13.97" y="-8.89" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="28" x="13.97" y="-6.35" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="29" x="13.97" y="-3.81" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="30" x="13.97" y="-1.27" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="31" x="13.97" y="1.27" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="32" x="13.97" y="3.81" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="33" x="13.97" y="6.35" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="34" x="13.97" y="8.89" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="35" x="13.97" y="11.43" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="36" x="13.97" y="13.97" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="37" x="13.97" y="16.51" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="38" x="13.97" y="19.05" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="39" x="13.97" y="21.59" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="40" x="13.97" y="24.13" visible="pad" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<wire x1="-1.27" y1="26.67" x2="-1.27" y2="25.4" width="0.254" layer="94"/>
<wire x1="-1.27" y1="25.4" x2="1.27" y2="25.4" width="0.254" layer="94"/>
<wire x1="1.27" y1="25.4" x2="1.27" y2="26.67" width="0.254" layer="94"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="DIL40" prefix="IC" uservalue="yes">
<gates>
<gate name="A" symbol="DIL40" x="0" y="0"/>
</gates>
<devices>
<device name="" package="DIL40">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="10" pad="10"/>
<connect gate="A" pin="11" pad="11"/>
<connect gate="A" pin="12" pad="12"/>
<connect gate="A" pin="13" pad="13"/>
<connect gate="A" pin="14" pad="14"/>
<connect gate="A" pin="15" pad="15"/>
<connect gate="A" pin="16" pad="16"/>
<connect gate="A" pin="17" pad="17"/>
<connect gate="A" pin="18" pad="18"/>
<connect gate="A" pin="19" pad="19"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="20" pad="20"/>
<connect gate="A" pin="21" pad="21"/>
<connect gate="A" pin="22" pad="22"/>
<connect gate="A" pin="23" pad="23"/>
<connect gate="A" pin="24" pad="24"/>
<connect gate="A" pin="25" pad="25"/>
<connect gate="A" pin="26" pad="26"/>
<connect gate="A" pin="27" pad="27"/>
<connect gate="A" pin="28" pad="28"/>
<connect gate="A" pin="29" pad="29"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="30" pad="30"/>
<connect gate="A" pin="31" pad="31"/>
<connect gate="A" pin="32" pad="32"/>
<connect gate="A" pin="33" pad="33"/>
<connect gate="A" pin="34" pad="34"/>
<connect gate="A" pin="35" pad="35"/>
<connect gate="A" pin="36" pad="36"/>
<connect gate="A" pin="37" pad="37"/>
<connect gate="A" pin="38" pad="38"/>
<connect gate="A" pin="39" pad="39"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="40" pad="40"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
<connect gate="A" pin="9" pad="9"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="CONNEC">
<packages>
<package name="IC-176-2">
<text x="-7.62" y="8.255" size="1.27" layer="25">&gt;NAME</text>
<text x="2.54" y="8.255" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="8.255" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<hole x="-67" y="0" drill="3.2"/>
<hole x="67" y="0" drill="3.2"/>
<wire x1="-71.5" y1="7.5" x2="71.5" y2="7.5" width="0.2032" layer="51"/>
<pad name="T38" x="4.445" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T40" x="6.985" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T42" x="9.525" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T44" x="12.065" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T46" x="14.605" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T48" x="17.145" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T50" x="19.685" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T52" x="22.225" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T54" x="24.765" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T56" x="27.305" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T58" x="29.845" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T60" x="32.385" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T62" x="34.925" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T64" x="37.465" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T66" x="40.005" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T68" x="42.545" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T70" x="45.085" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T72" x="47.625" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T1" x="-47.625" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T3" x="-45.085" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T5" x="-42.545" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T7" x="-40.005" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T9" x="-37.465" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T11" x="-34.925" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T13" x="-32.385" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T15" x="-29.845" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T17" x="-27.305" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T19" x="-24.765" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T21" x="-22.225" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T23" x="-19.685" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T25" x="-17.145" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T27" x="-14.605" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T29" x="-12.065" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T31" x="-9.525" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T33" x="-6.985" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T35" x="-4.445" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="B37" x="3.175" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B39" x="5.715" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B41" x="8.255" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B43" x="10.795" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B45" x="13.335" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B47" x="15.875" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B49" x="18.415" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B51" x="20.955" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B53" x="23.495" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B55" x="26.035" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B57" x="28.575" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B59" x="31.115" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B61" x="33.655" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B63" x="36.195" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B65" x="38.735" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B67" x="41.275" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B69" x="43.815" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B71" x="46.355" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B2" x="-46.355" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B4" x="-43.815" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B6" x="-41.275" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B8" x="-38.735" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B10" x="-36.195" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B12" x="-33.655" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B14" x="-31.115" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B16" x="-28.575" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B18" x="-26.035" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B20" x="-23.495" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B22" x="-20.955" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B24" x="-18.415" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B26" x="-15.875" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B28" x="-13.335" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B30" x="-10.795" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B32" x="-8.255" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B34" x="-5.715" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B36" x="-3.175" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B1" x="-47.625" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B3" x="-45.085" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B5" x="-42.545" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B7" x="-40.005" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B9" x="-37.465" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B11" x="-34.925" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B13" x="-32.385" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B15" x="-29.845" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B17" x="-27.305" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B19" x="-24.765" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B21" x="-22.225" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B23" x="-19.685" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B25" x="-17.145" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B27" x="-14.605" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B29" x="-12.065" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B31" x="-9.525" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B33" x="-6.985" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="B35" x="-4.445" y="2.54" drill="0.8" diameter="1.4"/>
<pad name="T2" x="-46.355" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T4" x="-43.815" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T6" x="-41.275" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T8" x="-38.735" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T10" x="-36.195" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T12" x="-33.655" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T14" x="-31.115" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T16" x="-28.575" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T18" x="-26.035" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T20" x="-23.495" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T22" x="-20.955" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T24" x="-18.415" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T26" x="-15.875" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T28" x="-13.335" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T30" x="-10.795" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T32" x="-8.255" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T34" x="-5.715" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="T36" x="-3.175" y="-2.54" drill="0.8" diameter="1.4"/>
<pad name="B38" x="4.445" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B40" x="6.985" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B42" x="9.525" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B44" x="12.065" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B46" x="14.605" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B48" x="17.145" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B50" x="19.685" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B52" x="22.225" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B54" x="24.765" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B56" x="27.305" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B58" x="29.845" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B60" x="32.385" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B62" x="34.925" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B64" x="37.465" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B66" x="40.005" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B68" x="42.545" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B70" x="45.085" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="B72" x="47.625" y="4.14" drill="0.8" diameter="1.4"/>
<pad name="T37" x="3.175" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T39" x="5.715" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T41" x="8.255" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T43" x="10.795" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T45" x="13.335" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T47" x="15.875" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T49" x="18.415" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T51" x="20.955" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T53" x="23.495" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T55" x="26.035" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T57" x="28.575" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T59" x="31.115" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T61" x="33.655" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T63" x="36.195" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T65" x="38.735" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T67" x="41.275" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T69" x="43.815" y="-4.14" drill="0.8" diameter="1.4"/>
<pad name="T71" x="46.355" y="-4.14" drill="0.8" diameter="1.4"/>
<wire x1="-71.5" y1="-7.5" x2="71.5" y2="-7.5" width="0.2032" layer="51"/>
<wire x1="-71.5" y1="7.5" x2="-71.5" y2="-7.5" width="0.2032" layer="51"/>
<wire x1="71.5" y1="-7.5" x2="71.5" y2="7.5" width="0.2032" layer="51"/>
<wire x1="-71.5" y1="7.5" x2="-62.5" y2="7.5" width="0.254" layer="21"/>
<wire x1="-62.5" y1="7.5" x2="-57.8" y2="7.5" width="0.254" layer="21"/>
<wire x1="-57.8" y1="7.5" x2="-49.15" y2="7.5" width="0.254" layer="21"/>
<wire x1="-49.15" y1="7.5" x2="49.15" y2="7.5" width="0.254" layer="21"/>
<wire x1="49.15" y1="7.5" x2="62.5" y2="7.5" width="0.254" layer="21"/>
<wire x1="62.5" y1="7.5" x2="71.5" y2="7.5" width="0.254" layer="21"/>
<wire x1="68.5" y1="-7.5" x2="62.5" y2="-7.5" width="0.254" layer="21"/>
<wire x1="62.5" y1="-7.5" x2="49.15" y2="-7.5" width="0.254" layer="21"/>
<wire x1="49.15" y1="-7.5" x2="-49.15" y2="-7.5" width="0.254" layer="21"/>
<wire x1="-49.15" y1="-7.5" x2="-62.5" y2="-7.5" width="0.254" layer="21"/>
<wire x1="-62.5" y1="-7.5" x2="-68.5" y2="-7.5" width="0.254" layer="21"/>
<wire x1="-71.5" y1="7.5" x2="-71.5" y2="-4.5" width="0.254" layer="21"/>
<circle x="-67" y="0" radius="1.6" width="0.2032" layer="21"/>
<circle x="67" y="0" radius="1.6" width="0.2032" layer="21"/>
<wire x1="71.5" y1="-4.5" x2="71.5" y2="7.5" width="0.254" layer="21"/>
<wire x1="-62.5" y1="7.5" x2="-62.5" y2="-7.5" width="0.254" layer="21"/>
<wire x1="62.5" y1="-7.5" x2="62.5" y2="7.5" width="0.254" layer="21"/>
<wire x1="-49.15" y1="7.5" x2="-49.15" y2="4.5" width="0.254" layer="21"/>
<wire x1="-49.15" y1="4.5" x2="-49.15" y2="0.8" width="0.254" layer="21"/>
<wire x1="-49.15" y1="0.8" x2="-49.15" y2="-0.8" width="0.254" layer="21"/>
<wire x1="-49.15" y1="-0.8" x2="-49.15" y2="-2.8" width="0.254" layer="21"/>
<wire x1="-49.15" y1="-2.8" x2="-49.15" y2="-5.5" width="0.254" layer="21"/>
<wire x1="-49.15" y1="-5.5" x2="-49.15" y2="-7.5" width="0.254" layer="21"/>
<wire x1="49.15" y1="-7.5" x2="49.15" y2="7.5" width="0.254" layer="21"/>
<wire x1="-49.15" y1="4.5" x2="-54.45" y2="4.5" width="0.254" layer="21"/>
<wire x1="-54.45" y1="4.5" x2="-57.8" y2="4.5" width="0.254" layer="21"/>
<wire x1="-57.8" y1="4.5" x2="-60.5" y2="4.5" width="0.254" layer="21"/>
<wire x1="-60.5" y1="4.5" x2="-60.85" y2="4.5" width="0.254" layer="21"/>
<wire x1="-60.85" y1="4.5" x2="-60.85" y2="0.8" width="0.254" layer="21"/>
<wire x1="-60.85" y1="0.8" x2="-60.5" y2="0.8" width="0.254" layer="21"/>
<wire x1="-60.5" y1="0.8" x2="-57.8" y2="0.8" width="0.254" layer="21"/>
<wire x1="-57.8" y1="0.8" x2="-55.8" y2="0.8" width="0.254" layer="21"/>
<wire x1="-55.8" y1="0.8" x2="-54.45" y2="0.8" width="0.254" layer="21"/>
<wire x1="-54.45" y1="0.8" x2="-52" y2="0.8" width="0.254" layer="21"/>
<wire x1="-52" y1="0.8" x2="-50" y2="0.8" width="0.254" layer="21"/>
<wire x1="-50" y1="0.8" x2="-49.15" y2="0.8" width="0.254" layer="21"/>
<wire x1="-54.45" y1="4.5" x2="-54.45" y2="0.8" width="0.254" layer="21"/>
<wire x1="-52" y1="0.8" x2="-52" y2="-0.4" width="0.254" layer="21"/>
<wire x1="-52" y1="-0.4" x2="-50" y2="-0.4" width="0.254" layer="21"/>
<wire x1="-50" y1="-0.4" x2="-50" y2="0.8" width="0.254" layer="21"/>
<wire x1="-57.8" y1="7.5" x2="-57.8" y2="5.5" width="0.254" layer="21"/>
<wire x1="-57.8" y1="5.5" x2="-57.8" y2="4.5" width="0.254" layer="21"/>
<wire x1="-57.8" y1="5.5" x2="-60.5" y2="5.5" width="0.254" layer="21"/>
<wire x1="-60.5" y1="5.5" x2="-60.5" y2="4.5" width="0.254" layer="21"/>
<wire x1="-62.5" y1="7.5" x2="-60.5" y2="5.5" width="0.254" layer="21"/>
<wire x1="-60.5" y1="0.8" x2="-60.5" y2="-5.5" width="0.254" layer="21"/>
<wire x1="-60.5" y1="-5.5" x2="-49.15" y2="-5.5" width="0.254" layer="21"/>
<wire x1="-62.5" y1="-7.5" x2="-60.5" y2="-5.5" width="0.254" layer="21"/>
<wire x1="-49.15" y1="-2.8" x2="-57.8" y2="-2.8" width="0.254" layer="21"/>
<wire x1="-57.8" y1="-2.8" x2="-57.8" y2="0.8" width="0.254" layer="21"/>
<wire x1="-55.8" y1="0.8" x2="-55.8" y2="-0.8" width="0.254" layer="21"/>
<wire x1="-55.8" y1="-0.8" x2="-49.15" y2="-0.8" width="0.254" layer="21"/>
<wire x1="-57.8" y1="-2.8" x2="-55.8" y2="-0.8" width="0.254" layer="21"/>
<wire x1="49.15" y1="4.5" x2="54.45" y2="4.5" width="0.254" layer="21"/>
<wire x1="54.45" y1="4.5" x2="57.8" y2="4.5" width="0.254" layer="21"/>
<wire x1="57.8" y1="4.5" x2="60.5" y2="4.5" width="0.254" layer="21"/>
<wire x1="60.5" y1="4.5" x2="60.85" y2="4.5" width="0.254" layer="21"/>
<wire x1="60.85" y1="4.5" x2="60.85" y2="0.8" width="0.254" layer="21"/>
<wire x1="60.85" y1="0.8" x2="60.5" y2="0.8" width="0.254" layer="21"/>
<wire x1="60.5" y1="0.8" x2="57.8" y2="0.8" width="0.254" layer="21"/>
<wire x1="57.8" y1="0.8" x2="55.8" y2="0.8" width="0.254" layer="21"/>
<wire x1="55.8" y1="0.8" x2="54.45" y2="0.8" width="0.254" layer="21"/>
<wire x1="54.45" y1="0.8" x2="52" y2="0.8" width="0.254" layer="21"/>
<wire x1="52" y1="0.8" x2="50" y2="0.8" width="0.254" layer="21"/>
<wire x1="50" y1="0.8" x2="49.15" y2="0.8" width="0.254" layer="21"/>
<wire x1="54.45" y1="4.5" x2="54.45" y2="0.8" width="0.254" layer="21"/>
<wire x1="52" y1="0.8" x2="52" y2="-0.4" width="0.254" layer="21"/>
<wire x1="52" y1="-0.4" x2="50" y2="-0.4" width="0.254" layer="21"/>
<wire x1="50" y1="-0.4" x2="50" y2="0.8" width="0.254" layer="21"/>
<wire x1="57.8" y1="7.5" x2="57.8" y2="5.5" width="0.254" layer="21"/>
<wire x1="57.8" y1="5.5" x2="57.8" y2="4.5" width="0.254" layer="21"/>
<wire x1="57.8" y1="5.5" x2="60.5" y2="5.5" width="0.254" layer="21"/>
<wire x1="60.5" y1="5.5" x2="60.5" y2="4.5" width="0.254" layer="21"/>
<wire x1="62.5" y1="7.5" x2="60.5" y2="5.5" width="0.254" layer="21"/>
<wire x1="60.5" y1="0.8" x2="60.5" y2="-5.5" width="0.254" layer="21"/>
<wire x1="60.5" y1="-5.5" x2="49.15" y2="-5.5" width="0.254" layer="21"/>
<wire x1="62.5" y1="-7.5" x2="60.5" y2="-5.5" width="0.254" layer="21"/>
<wire x1="49.15" y1="-2.8" x2="57.8" y2="-2.8" width="0.254" layer="21"/>
<wire x1="57.8" y1="-2.8" x2="57.8" y2="0.8" width="0.254" layer="21"/>
<wire x1="55.8" y1="0.8" x2="55.8" y2="-0.8" width="0.254" layer="21"/>
<wire x1="55.8" y1="-0.8" x2="49.15" y2="-0.8" width="0.254" layer="21"/>
<wire x1="57.8" y1="-2.8" x2="55.8" y2="-0.8" width="0.254" layer="21"/>
<wire x1="-68.5" y1="-7.5" x2="-71.5" y2="-4.5" width="0.254" layer="21" curve="-90"/>
<wire x1="68.5" y1="-7.5" x2="71.5" y2="-4.5" width="0.254" layer="21" curve="90"/>
<wire x1="-48.075" y1="5.2" x2="-48.075" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-48.075" y1="-5.2" x2="-47.175" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-47.175" y1="-5.2" x2="-47.175" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-47.175" y1="5.2" x2="-48.075" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-46.805" y1="5.2" x2="-46.805" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-46.805" y1="-5.2" x2="-45.905" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-45.905" y1="-5.2" x2="-45.905" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-45.905" y1="5.2" x2="-46.805" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-45.535" y1="5.2" x2="-45.535" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-45.535" y1="-5.2" x2="-44.635" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-44.635" y1="-5.2" x2="-44.635" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-44.635" y1="5.2" x2="-45.535" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-44.265" y1="5.2" x2="-44.265" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-44.265" y1="-5.2" x2="-43.365" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-43.365" y1="-5.2" x2="-43.365" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-43.365" y1="5.2" x2="-44.265" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-42.995" y1="5.2" x2="-42.995" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-42.995" y1="-5.2" x2="-42.095" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-42.095" y1="-5.2" x2="-42.095" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-42.095" y1="5.2" x2="-42.995" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-41.725" y1="5.2" x2="-41.725" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-41.725" y1="-5.2" x2="-40.825" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-40.825" y1="-5.2" x2="-40.825" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-40.825" y1="5.2" x2="-41.725" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-40.455" y1="5.2" x2="-40.455" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-40.455" y1="-5.2" x2="-39.555" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-39.555" y1="-5.2" x2="-39.555" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-39.555" y1="5.2" x2="-40.455" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-39.185" y1="5.2" x2="-39.185" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-39.185" y1="-5.2" x2="-38.285" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-38.285" y1="-5.2" x2="-38.285" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-38.285" y1="5.2" x2="-39.185" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-37.915" y1="5.2" x2="-37.915" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-37.915" y1="-5.2" x2="-37.015" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-37.015" y1="-5.2" x2="-37.015" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-37.015" y1="5.2" x2="-37.915" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-36.645" y1="5.2" x2="-36.645" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-36.645" y1="-5.2" x2="-35.745" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-35.745" y1="-5.2" x2="-35.745" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-35.745" y1="5.2" x2="-36.645" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-35.375" y1="5.2" x2="-35.375" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-35.375" y1="-5.2" x2="-34.475" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-34.475" y1="-5.2" x2="-34.475" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-34.475" y1="5.2" x2="-35.375" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-34.105" y1="5.2" x2="-34.105" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-34.105" y1="-5.2" x2="-33.205" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-33.205" y1="-5.2" x2="-33.205" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-33.205" y1="5.2" x2="-34.105" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-32.835" y1="5.2" x2="-32.835" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-32.835" y1="-5.2" x2="-31.935" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-31.935" y1="-5.2" x2="-31.935" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-31.935" y1="5.2" x2="-32.835" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-31.565" y1="5.2" x2="-31.565" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-31.565" y1="-5.2" x2="-30.665" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-30.665" y1="-5.2" x2="-30.665" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-30.665" y1="5.2" x2="-31.565" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-30.295" y1="5.2" x2="-30.295" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-30.295" y1="-5.2" x2="-29.395" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-29.395" y1="-5.2" x2="-29.395" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-29.395" y1="5.2" x2="-30.295" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-29.025" y1="5.2" x2="-29.025" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-29.025" y1="-5.2" x2="-28.125" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-28.125" y1="-5.2" x2="-28.125" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-28.125" y1="5.2" x2="-29.025" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-27.755" y1="5.2" x2="-27.755" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-27.755" y1="-5.2" x2="-26.855" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-26.855" y1="-5.2" x2="-26.855" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-26.855" y1="5.2" x2="-27.755" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-26.485" y1="5.2" x2="-26.485" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-26.485" y1="-5.2" x2="-25.585" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-25.585" y1="-5.2" x2="-25.585" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-25.585" y1="5.2" x2="-26.485" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-25.215" y1="5.2" x2="-25.215" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-25.215" y1="-5.2" x2="-24.315" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-24.315" y1="-5.2" x2="-24.315" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-24.315" y1="5.2" x2="-25.215" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-23.945" y1="5.2" x2="-23.945" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-23.945" y1="-5.2" x2="-23.045" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-23.045" y1="-5.2" x2="-23.045" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-23.045" y1="5.2" x2="-23.945" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-22.675" y1="5.2" x2="-22.675" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-22.675" y1="-5.2" x2="-21.775" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-21.775" y1="-5.2" x2="-21.775" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-21.775" y1="5.2" x2="-22.675" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-21.405" y1="5.2" x2="-21.405" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-21.405" y1="-5.2" x2="-20.505" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-20.505" y1="-5.2" x2="-20.505" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-20.505" y1="5.2" x2="-21.405" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-20.135" y1="5.2" x2="-20.135" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-20.135" y1="-5.2" x2="-19.235" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-19.235" y1="-5.2" x2="-19.235" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-19.235" y1="5.2" x2="-20.135" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-18.865" y1="5.2" x2="-18.865" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-18.865" y1="-5.2" x2="-17.965" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-17.965" y1="-5.2" x2="-17.965" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-17.965" y1="5.2" x2="-18.865" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-17.595" y1="5.2" x2="-17.595" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-17.595" y1="-5.2" x2="-16.695" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-16.695" y1="-5.2" x2="-16.695" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-16.695" y1="5.2" x2="-17.595" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-16.325" y1="5.2" x2="-16.325" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-16.325" y1="-5.2" x2="-15.425" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-15.425" y1="-5.2" x2="-15.425" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-15.425" y1="5.2" x2="-16.325" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-15.055" y1="5.2" x2="-15.055" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-15.055" y1="-5.2" x2="-14.155" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-14.155" y1="-5.2" x2="-14.155" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-14.155" y1="5.2" x2="-15.055" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-13.785" y1="5.2" x2="-13.785" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-13.785" y1="-5.2" x2="-12.885" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-12.885" y1="-5.2" x2="-12.885" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-12.885" y1="5.2" x2="-13.785" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-12.515" y1="5.2" x2="-12.515" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-12.515" y1="-5.2" x2="-11.615" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-11.615" y1="-5.2" x2="-11.615" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-11.615" y1="5.2" x2="-12.515" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-11.245" y1="5.2" x2="-11.245" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-11.245" y1="-5.2" x2="-10.345" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-10.345" y1="-5.2" x2="-10.345" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-10.345" y1="5.2" x2="-11.245" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-9.975" y1="5.2" x2="-9.975" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-9.975" y1="-5.2" x2="-9.075" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-9.075" y1="-5.2" x2="-9.075" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-9.075" y1="5.2" x2="-9.975" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-8.705" y1="5.2" x2="-8.705" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-8.705" y1="-5.2" x2="-7.805" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-7.805" y1="-5.2" x2="-7.805" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-7.805" y1="5.2" x2="-8.705" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-7.435" y1="5.2" x2="-7.435" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-7.435" y1="-5.2" x2="-6.535" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-6.535" y1="-5.2" x2="-6.535" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-6.535" y1="5.2" x2="-7.435" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-6.165" y1="5.2" x2="-6.165" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-6.165" y1="-5.2" x2="-5.265" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-5.265" y1="-5.2" x2="-5.265" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-5.265" y1="5.2" x2="-6.165" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-4.895" y1="5.2" x2="-4.895" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-4.895" y1="-5.2" x2="-3.995" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-3.995" y1="-5.2" x2="-3.995" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-3.995" y1="5.2" x2="-4.895" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-3.625" y1="5.2" x2="-3.625" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-3.625" y1="2.3" x2="-3.625" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-3.625" y1="0.55" x2="-3.625" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-3.625" y1="-0.55" x2="-3.625" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-3.625" y1="-2.3" x2="-3.625" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-3.625" y1="-5.2" x2="-2.725" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="-2.725" y1="-5.2" x2="-2.725" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-2.725" y1="-2.3" x2="-2.725" y2="-1.25" width="0.2032" layer="21"/>
<wire x1="-2.725" y1="-1.25" x2="-2.725" y2="-0.8" width="0.2032" layer="21"/>
<wire x1="-2.725" y1="-0.8" x2="-2.725" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-2.725" y1="-0.55" x2="-2.725" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-2.725" y1="0.55" x2="-2.725" y2="1.25" width="0.2032" layer="21"/>
<wire x1="-2.725" y1="1.25" x2="-2.725" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-2.725" y1="2.3" x2="-2.725" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-2.725" y1="5.2" x2="-3.625" y2="5.2" width="0.2032" layer="21"/>
<wire x1="2.725" y1="5.2" x2="2.725" y2="1.25" width="0.2032" layer="21"/>
<wire x1="2.725" y1="1.25" x2="2.725" y2="0.8" width="0.2032" layer="21"/>
<wire x1="2.725" y1="0.8" x2="2.725" y2="-0.8" width="0.2032" layer="21"/>
<wire x1="2.725" y1="-0.8" x2="2.725" y2="-1.25" width="0.2032" layer="21"/>
<wire x1="2.725" y1="-1.25" x2="2.725" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="2.725" y1="-5.2" x2="3.625" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="3.625" y1="-5.2" x2="3.625" y2="5.2" width="0.2032" layer="21"/>
<wire x1="3.625" y1="5.2" x2="2.725" y2="5.2" width="0.2032" layer="21"/>
<wire x1="3.995" y1="5.2" x2="3.995" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="3.995" y1="-5.2" x2="4.895" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="4.895" y1="-5.2" x2="4.895" y2="5.2" width="0.2032" layer="21"/>
<wire x1="4.895" y1="5.2" x2="3.995" y2="5.2" width="0.2032" layer="21"/>
<wire x1="5.265" y1="5.2" x2="5.265" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="5.265" y1="-5.2" x2="6.165" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="6.165" y1="-5.2" x2="6.165" y2="5.2" width="0.2032" layer="21"/>
<wire x1="6.165" y1="5.2" x2="5.265" y2="5.2" width="0.2032" layer="21"/>
<wire x1="6.535" y1="5.2" x2="6.535" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="6.535" y1="-5.2" x2="7.435" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="7.435" y1="-5.2" x2="7.435" y2="5.2" width="0.2032" layer="21"/>
<wire x1="7.435" y1="5.2" x2="6.535" y2="5.2" width="0.2032" layer="21"/>
<wire x1="7.805" y1="5.2" x2="7.805" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="7.805" y1="-5.2" x2="8.705" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="8.705" y1="-5.2" x2="8.705" y2="5.2" width="0.2032" layer="21"/>
<wire x1="8.705" y1="5.2" x2="7.805" y2="5.2" width="0.2032" layer="21"/>
<wire x1="9.075" y1="5.2" x2="9.075" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="9.075" y1="-5.2" x2="9.975" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="9.975" y1="-5.2" x2="9.975" y2="5.2" width="0.2032" layer="21"/>
<wire x1="9.975" y1="5.2" x2="9.075" y2="5.2" width="0.2032" layer="21"/>
<wire x1="10.345" y1="5.2" x2="10.345" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="10.345" y1="-5.2" x2="11.245" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="11.245" y1="-5.2" x2="11.245" y2="5.2" width="0.2032" layer="21"/>
<wire x1="11.245" y1="5.2" x2="10.345" y2="5.2" width="0.2032" layer="21"/>
<wire x1="11.615" y1="5.2" x2="11.615" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="11.615" y1="-5.2" x2="12.515" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="12.515" y1="-5.2" x2="12.515" y2="5.2" width="0.2032" layer="21"/>
<wire x1="12.515" y1="5.2" x2="11.615" y2="5.2" width="0.2032" layer="21"/>
<wire x1="12.885" y1="5.2" x2="12.885" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="12.885" y1="-5.2" x2="13.785" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="13.785" y1="-5.2" x2="13.785" y2="5.2" width="0.2032" layer="21"/>
<wire x1="13.785" y1="5.2" x2="12.885" y2="5.2" width="0.2032" layer="21"/>
<wire x1="14.155" y1="5.2" x2="14.155" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="14.155" y1="-5.2" x2="15.055" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="15.055" y1="-5.2" x2="15.055" y2="5.2" width="0.2032" layer="21"/>
<wire x1="15.055" y1="5.2" x2="14.155" y2="5.2" width="0.2032" layer="21"/>
<wire x1="15.425" y1="5.2" x2="15.425" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="15.425" y1="-5.2" x2="16.325" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="16.325" y1="-5.2" x2="16.325" y2="5.2" width="0.2032" layer="21"/>
<wire x1="16.325" y1="5.2" x2="15.425" y2="5.2" width="0.2032" layer="21"/>
<wire x1="16.695" y1="5.2" x2="16.695" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="16.695" y1="-5.2" x2="17.595" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="17.595" y1="-5.2" x2="17.595" y2="5.2" width="0.2032" layer="21"/>
<wire x1="17.595" y1="5.2" x2="16.695" y2="5.2" width="0.2032" layer="21"/>
<wire x1="17.965" y1="5.2" x2="17.965" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="17.965" y1="-5.2" x2="18.865" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="18.865" y1="-5.2" x2="18.865" y2="5.2" width="0.2032" layer="21"/>
<wire x1="18.865" y1="5.2" x2="17.965" y2="5.2" width="0.2032" layer="21"/>
<wire x1="19.235" y1="5.2" x2="19.235" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="19.235" y1="-5.2" x2="20.135" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="20.135" y1="-5.2" x2="20.135" y2="5.2" width="0.2032" layer="21"/>
<wire x1="20.135" y1="5.2" x2="19.235" y2="5.2" width="0.2032" layer="21"/>
<wire x1="20.505" y1="5.2" x2="20.505" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="20.505" y1="-5.2" x2="21.405" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="21.405" y1="-5.2" x2="21.405" y2="5.2" width="0.2032" layer="21"/>
<wire x1="21.405" y1="5.2" x2="20.505" y2="5.2" width="0.2032" layer="21"/>
<wire x1="21.775" y1="5.2" x2="21.775" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="21.775" y1="-5.2" x2="22.675" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="22.675" y1="-5.2" x2="22.675" y2="5.2" width="0.2032" layer="21"/>
<wire x1="22.675" y1="5.2" x2="21.775" y2="5.2" width="0.2032" layer="21"/>
<wire x1="23.045" y1="5.2" x2="23.045" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="23.045" y1="-5.2" x2="23.945" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="23.945" y1="-5.2" x2="23.945" y2="5.2" width="0.2032" layer="21"/>
<wire x1="23.945" y1="5.2" x2="23.045" y2="5.2" width="0.2032" layer="21"/>
<wire x1="24.315" y1="5.2" x2="24.315" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="24.315" y1="-5.2" x2="25.215" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="25.215" y1="-5.2" x2="25.215" y2="5.2" width="0.2032" layer="21"/>
<wire x1="25.215" y1="5.2" x2="24.315" y2="5.2" width="0.2032" layer="21"/>
<wire x1="25.585" y1="5.2" x2="25.585" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="25.585" y1="-5.2" x2="26.485" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="26.485" y1="-5.2" x2="26.485" y2="5.2" width="0.2032" layer="21"/>
<wire x1="26.485" y1="5.2" x2="25.585" y2="5.2" width="0.2032" layer="21"/>
<wire x1="26.855" y1="5.2" x2="26.855" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="26.855" y1="-5.2" x2="27.755" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="27.755" y1="-5.2" x2="27.755" y2="5.2" width="0.2032" layer="21"/>
<wire x1="27.755" y1="5.2" x2="26.855" y2="5.2" width="0.2032" layer="21"/>
<wire x1="28.125" y1="5.2" x2="28.125" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="28.125" y1="-5.2" x2="29.025" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="29.025" y1="-5.2" x2="29.025" y2="5.2" width="0.2032" layer="21"/>
<wire x1="29.025" y1="5.2" x2="28.125" y2="5.2" width="0.2032" layer="21"/>
<wire x1="29.395" y1="5.2" x2="29.395" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="29.395" y1="-5.2" x2="30.295" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="30.295" y1="-5.2" x2="30.295" y2="5.2" width="0.2032" layer="21"/>
<wire x1="30.295" y1="5.2" x2="29.395" y2="5.2" width="0.2032" layer="21"/>
<wire x1="30.665" y1="5.2" x2="30.665" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="30.665" y1="-5.2" x2="31.565" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="31.565" y1="-5.2" x2="31.565" y2="5.2" width="0.2032" layer="21"/>
<wire x1="31.565" y1="5.2" x2="30.665" y2="5.2" width="0.2032" layer="21"/>
<wire x1="31.935" y1="5.2" x2="31.935" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="31.935" y1="-5.2" x2="32.835" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="32.835" y1="-5.2" x2="32.835" y2="5.2" width="0.2032" layer="21"/>
<wire x1="32.835" y1="5.2" x2="31.935" y2="5.2" width="0.2032" layer="21"/>
<wire x1="33.205" y1="5.2" x2="33.205" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="33.205" y1="-5.2" x2="34.105" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="34.105" y1="-5.2" x2="34.105" y2="5.2" width="0.2032" layer="21"/>
<wire x1="34.105" y1="5.2" x2="33.205" y2="5.2" width="0.2032" layer="21"/>
<wire x1="34.475" y1="5.2" x2="34.475" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="34.475" y1="-5.2" x2="35.375" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="35.375" y1="-5.2" x2="35.375" y2="5.2" width="0.2032" layer="21"/>
<wire x1="35.375" y1="5.2" x2="34.475" y2="5.2" width="0.2032" layer="21"/>
<wire x1="35.745" y1="5.2" x2="35.745" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="35.745" y1="-5.2" x2="36.645" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="36.645" y1="-5.2" x2="36.645" y2="5.2" width="0.2032" layer="21"/>
<wire x1="36.645" y1="5.2" x2="35.745" y2="5.2" width="0.2032" layer="21"/>
<wire x1="37.015" y1="5.2" x2="37.015" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="37.015" y1="-5.2" x2="37.915" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="37.915" y1="-5.2" x2="37.915" y2="5.2" width="0.2032" layer="21"/>
<wire x1="37.915" y1="5.2" x2="37.015" y2="5.2" width="0.2032" layer="21"/>
<wire x1="38.285" y1="5.2" x2="38.285" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="38.285" y1="-5.2" x2="39.185" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="39.185" y1="-5.2" x2="39.185" y2="5.2" width="0.2032" layer="21"/>
<wire x1="39.185" y1="5.2" x2="38.285" y2="5.2" width="0.2032" layer="21"/>
<wire x1="39.555" y1="5.2" x2="39.555" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="39.555" y1="-5.2" x2="40.455" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="40.455" y1="-5.2" x2="40.455" y2="5.2" width="0.2032" layer="21"/>
<wire x1="40.455" y1="5.2" x2="39.555" y2="5.2" width="0.2032" layer="21"/>
<wire x1="40.825" y1="5.2" x2="40.825" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="40.825" y1="-5.2" x2="41.725" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="41.725" y1="-5.2" x2="41.725" y2="5.2" width="0.2032" layer="21"/>
<wire x1="41.725" y1="5.2" x2="40.825" y2="5.2" width="0.2032" layer="21"/>
<wire x1="42.095" y1="5.2" x2="42.095" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="42.095" y1="-5.2" x2="42.995" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="42.995" y1="-5.2" x2="42.995" y2="5.2" width="0.2032" layer="21"/>
<wire x1="42.995" y1="5.2" x2="42.095" y2="5.2" width="0.2032" layer="21"/>
<wire x1="43.365" y1="5.2" x2="43.365" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="43.365" y1="-5.2" x2="44.265" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="44.265" y1="-5.2" x2="44.265" y2="5.2" width="0.2032" layer="21"/>
<wire x1="44.265" y1="5.2" x2="43.365" y2="5.2" width="0.2032" layer="21"/>
<wire x1="44.635" y1="5.2" x2="44.635" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="44.635" y1="-5.2" x2="45.535" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="45.535" y1="-5.2" x2="45.535" y2="5.2" width="0.2032" layer="21"/>
<wire x1="45.535" y1="5.2" x2="44.635" y2="5.2" width="0.2032" layer="21"/>
<wire x1="45.905" y1="5.2" x2="45.905" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="45.905" y1="-5.2" x2="46.805" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="46.805" y1="-5.2" x2="46.805" y2="5.2" width="0.2032" layer="21"/>
<wire x1="46.805" y1="5.2" x2="45.905" y2="5.2" width="0.2032" layer="21"/>
<wire x1="47.175" y1="5.2" x2="47.175" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="47.175" y1="-5.2" x2="48.075" y2="-5.2" width="0.2032" layer="21"/>
<wire x1="48.075" y1="-5.2" x2="48.075" y2="5.2" width="0.2032" layer="21"/>
<wire x1="48.075" y1="5.2" x2="47.175" y2="5.2" width="0.2032" layer="21"/>
<wire x1="-2.725" y1="0.8" x2="-1.45" y2="0.8" width="0.2032" layer="21"/>
<wire x1="-1.45" y1="0.8" x2="1.45" y2="0.8" width="0.2032" layer="21"/>
<wire x1="1.45" y1="0.8" x2="2.725" y2="0.8" width="0.2032" layer="21"/>
<wire x1="-2.725" y1="-0.8" x2="-1.45" y2="-0.8" width="0.2032" layer="21"/>
<wire x1="-1.45" y1="-0.8" x2="1.45" y2="-0.8" width="0.2032" layer="21"/>
<wire x1="1.45" y1="-0.8" x2="2.725" y2="-0.8" width="0.2032" layer="21"/>
<wire x1="-2.725" y1="1.25" x2="2.725" y2="1.25" width="0.2032" layer="21"/>
<wire x1="-2.725" y1="-1.25" x2="2.725" y2="-1.25" width="0.2032" layer="21"/>
<wire x1="-1.45" y1="0.8" x2="-1.45" y2="-0.8" width="0.2032" layer="21"/>
<wire x1="1.45" y1="0.8" x2="1.45" y2="-0.8" width="0.2032" layer="21"/>
<wire x1="-2.725" y1="2.3" x2="-3.625" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-3.625" y1="0.55" x2="-2.725" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-3.625" y1="-0.55" x2="-2.725" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-3.625" y1="-2.3" x2="-2.725" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-3.995" y1="2.3" x2="-4.895" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-4.895" y1="0.55" x2="-3.995" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-4.895" y1="-0.55" x2="-3.995" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-4.895" y1="-2.3" x2="-3.995" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-5.265" y1="2.3" x2="-6.165" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-6.165" y1="0.55" x2="-5.265" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-6.165" y1="-0.55" x2="-5.265" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-6.165" y1="-2.3" x2="-5.265" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-6.535" y1="2.3" x2="-7.435" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-7.435" y1="0.55" x2="-6.535" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-7.435" y1="-0.55" x2="-6.535" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-7.435" y1="-2.3" x2="-6.535" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-7.805" y1="2.3" x2="-8.705" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-8.705" y1="0.55" x2="-7.805" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-8.705" y1="-0.55" x2="-7.805" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-8.705" y1="-2.3" x2="-7.805" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-9.075" y1="2.3" x2="-9.975" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-9.975" y1="0.55" x2="-9.075" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-9.975" y1="-0.55" x2="-9.075" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-9.975" y1="-2.3" x2="-9.075" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-10.345" y1="2.3" x2="-11.245" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-11.245" y1="0.55" x2="-10.345" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-11.245" y1="-0.55" x2="-10.345" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-11.245" y1="-2.3" x2="-10.345" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-11.615" y1="2.3" x2="-12.515" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-12.515" y1="0.55" x2="-11.615" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-12.515" y1="-0.55" x2="-11.615" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-12.515" y1="-2.3" x2="-11.615" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-12.885" y1="2.3" x2="-13.785" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-13.785" y1="0.55" x2="-12.885" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-13.785" y1="-0.55" x2="-12.885" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-13.785" y1="-2.3" x2="-12.885" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-14.155" y1="2.3" x2="-15.055" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-15.055" y1="0.55" x2="-14.155" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-15.055" y1="-0.55" x2="-14.155" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-15.055" y1="-2.3" x2="-14.155" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-15.425" y1="2.3" x2="-16.325" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-16.325" y1="0.55" x2="-15.425" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-16.325" y1="-0.55" x2="-15.425" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-16.325" y1="-2.3" x2="-15.425" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-16.695" y1="2.3" x2="-17.595" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-17.595" y1="0.55" x2="-16.695" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-17.595" y1="-0.55" x2="-16.695" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-17.595" y1="-2.3" x2="-16.695" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-17.965" y1="2.3" x2="-18.865" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-18.865" y1="0.55" x2="-17.965" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-18.865" y1="-0.55" x2="-17.965" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-18.865" y1="-2.3" x2="-17.965" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-19.235" y1="2.3" x2="-20.135" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-20.135" y1="0.55" x2="-19.235" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-20.135" y1="-0.55" x2="-19.235" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-20.135" y1="-2.3" x2="-19.235" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-20.505" y1="2.3" x2="-21.405" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-21.405" y1="0.55" x2="-20.505" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-21.405" y1="-0.55" x2="-20.505" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-21.405" y1="-2.3" x2="-20.505" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-21.775" y1="2.3" x2="-22.675" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-22.675" y1="0.55" x2="-21.775" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-22.675" y1="-0.55" x2="-21.775" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-22.675" y1="-2.3" x2="-21.775" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-23.045" y1="2.3" x2="-23.945" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-23.945" y1="0.55" x2="-23.045" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-23.945" y1="-0.55" x2="-23.045" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-23.945" y1="-2.3" x2="-23.045" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-24.315" y1="2.3" x2="-25.215" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-25.215" y1="0.55" x2="-24.315" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-25.215" y1="-0.55" x2="-24.315" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-25.215" y1="-2.3" x2="-24.315" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-25.585" y1="2.3" x2="-26.485" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-26.485" y1="0.55" x2="-25.585" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-26.485" y1="-0.55" x2="-25.585" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-26.485" y1="-2.3" x2="-25.585" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-26.855" y1="2.3" x2="-27.755" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-27.755" y1="0.55" x2="-26.855" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-27.755" y1="-0.55" x2="-26.855" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-27.755" y1="-2.3" x2="-26.855" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-28.125" y1="2.3" x2="-29.025" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-29.025" y1="0.55" x2="-28.125" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-29.025" y1="-0.55" x2="-28.125" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-29.025" y1="-2.3" x2="-28.125" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-29.395" y1="2.3" x2="-30.295" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-30.295" y1="0.55" x2="-29.395" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-30.295" y1="-0.55" x2="-29.395" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-30.295" y1="-2.3" x2="-29.395" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-30.665" y1="2.3" x2="-31.565" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-31.565" y1="0.55" x2="-30.665" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-31.565" y1="-0.55" x2="-30.665" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-31.565" y1="-2.3" x2="-30.665" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-31.935" y1="2.3" x2="-32.835" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-32.835" y1="0.55" x2="-31.935" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-32.835" y1="-0.55" x2="-31.935" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-32.835" y1="-2.3" x2="-31.935" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-33.205" y1="2.3" x2="-34.105" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-34.105" y1="0.55" x2="-33.205" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-34.105" y1="-0.55" x2="-33.205" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-34.105" y1="-2.3" x2="-33.205" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-34.475" y1="2.3" x2="-35.375" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-35.375" y1="0.55" x2="-34.475" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-35.375" y1="-0.55" x2="-34.475" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-35.375" y1="-2.3" x2="-34.475" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-35.745" y1="2.3" x2="-36.645" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-36.645" y1="0.55" x2="-35.745" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-36.645" y1="-0.55" x2="-35.745" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-36.645" y1="-2.3" x2="-35.745" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-37.015" y1="2.3" x2="-37.915" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-37.915" y1="0.55" x2="-37.015" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-37.915" y1="-0.55" x2="-37.015" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-37.915" y1="-2.3" x2="-37.015" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-38.285" y1="2.3" x2="-39.185" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-39.185" y1="0.55" x2="-38.285" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-39.185" y1="-0.55" x2="-38.285" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-39.185" y1="-2.3" x2="-38.285" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-39.555" y1="2.3" x2="-40.455" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-40.455" y1="0.55" x2="-39.555" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-40.455" y1="-0.55" x2="-39.555" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-40.455" y1="-2.3" x2="-39.555" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-40.825" y1="2.3" x2="-41.725" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-41.725" y1="0.55" x2="-40.825" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-41.725" y1="-0.55" x2="-40.825" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-41.725" y1="-2.3" x2="-40.825" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-42.095" y1="2.3" x2="-42.995" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-42.995" y1="0.55" x2="-42.095" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-42.995" y1="-0.55" x2="-42.095" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-42.995" y1="-2.3" x2="-42.095" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-43.365" y1="2.3" x2="-44.265" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-44.265" y1="0.55" x2="-43.365" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-44.265" y1="-0.55" x2="-43.365" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-44.265" y1="-2.3" x2="-43.365" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-44.635" y1="2.3" x2="-45.535" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-45.535" y1="0.55" x2="-44.635" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-45.535" y1="-0.55" x2="-44.635" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-45.535" y1="-2.3" x2="-44.635" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-45.905" y1="2.3" x2="-46.805" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-46.805" y1="0.55" x2="-45.905" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-46.805" y1="-0.55" x2="-45.905" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-46.805" y1="-2.3" x2="-45.905" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="-47.175" y1="2.3" x2="-48.075" y2="2.3" width="0.2032" layer="21"/>
<wire x1="-48.075" y1="0.55" x2="-47.175" y2="0.55" width="0.2032" layer="21"/>
<wire x1="-48.075" y1="-0.55" x2="-47.175" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="-48.075" y1="-2.3" x2="-47.175" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="3.625" y1="2.3" x2="2.725" y2="2.3" width="0.2032" layer="21"/>
<wire x1="2.725" y1="0.55" x2="3.625" y2="0.55" width="0.2032" layer="21"/>
<wire x1="2.725" y1="-0.55" x2="3.625" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="2.725" y1="-2.3" x2="3.625" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="4.895" y1="2.3" x2="3.995" y2="2.3" width="0.2032" layer="21"/>
<wire x1="3.995" y1="0.55" x2="4.895" y2="0.55" width="0.2032" layer="21"/>
<wire x1="3.995" y1="-0.55" x2="4.895" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="3.995" y1="-2.3" x2="4.895" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="6.165" y1="2.3" x2="5.265" y2="2.3" width="0.2032" layer="21"/>
<wire x1="5.265" y1="0.55" x2="6.165" y2="0.55" width="0.2032" layer="21"/>
<wire x1="5.265" y1="-0.55" x2="6.165" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="5.265" y1="-2.3" x2="6.165" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="7.435" y1="2.3" x2="6.535" y2="2.3" width="0.2032" layer="21"/>
<wire x1="6.535" y1="0.55" x2="7.435" y2="0.55" width="0.2032" layer="21"/>
<wire x1="6.535" y1="-0.55" x2="7.435" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="6.535" y1="-2.3" x2="7.435" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="8.705" y1="2.3" x2="7.805" y2="2.3" width="0.2032" layer="21"/>
<wire x1="7.805" y1="0.55" x2="8.705" y2="0.55" width="0.2032" layer="21"/>
<wire x1="7.805" y1="-0.55" x2="8.705" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="7.805" y1="-2.3" x2="8.705" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="9.975" y1="2.3" x2="9.075" y2="2.3" width="0.2032" layer="21"/>
<wire x1="9.075" y1="0.55" x2="9.975" y2="0.55" width="0.2032" layer="21"/>
<wire x1="9.075" y1="-0.55" x2="9.975" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="9.075" y1="-2.3" x2="9.975" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="11.245" y1="2.3" x2="10.345" y2="2.3" width="0.2032" layer="21"/>
<wire x1="10.345" y1="0.55" x2="11.245" y2="0.55" width="0.2032" layer="21"/>
<wire x1="10.345" y1="-0.55" x2="11.245" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="10.345" y1="-2.3" x2="11.245" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="12.515" y1="2.3" x2="11.615" y2="2.3" width="0.2032" layer="21"/>
<wire x1="11.615" y1="0.55" x2="12.515" y2="0.55" width="0.2032" layer="21"/>
<wire x1="11.615" y1="-0.55" x2="12.515" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="11.615" y1="-2.3" x2="12.515" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="13.785" y1="2.3" x2="12.885" y2="2.3" width="0.2032" layer="21"/>
<wire x1="12.885" y1="0.55" x2="13.785" y2="0.55" width="0.2032" layer="21"/>
<wire x1="12.885" y1="-0.55" x2="13.785" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="12.885" y1="-2.3" x2="13.785" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="15.055" y1="2.3" x2="14.155" y2="2.3" width="0.2032" layer="21"/>
<wire x1="14.155" y1="0.55" x2="15.055" y2="0.55" width="0.2032" layer="21"/>
<wire x1="14.155" y1="-0.55" x2="15.055" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="14.155" y1="-2.3" x2="15.055" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="16.325" y1="2.3" x2="15.425" y2="2.3" width="0.2032" layer="21"/>
<wire x1="15.425" y1="0.55" x2="16.325" y2="0.55" width="0.2032" layer="21"/>
<wire x1="15.425" y1="-0.55" x2="16.325" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="15.425" y1="-2.3" x2="16.325" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="17.595" y1="2.3" x2="16.695" y2="2.3" width="0.2032" layer="21"/>
<wire x1="16.695" y1="0.55" x2="17.595" y2="0.55" width="0.2032" layer="21"/>
<wire x1="16.695" y1="-0.55" x2="17.595" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="16.695" y1="-2.3" x2="17.595" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="18.865" y1="2.3" x2="17.965" y2="2.3" width="0.2032" layer="21"/>
<wire x1="17.965" y1="0.55" x2="18.865" y2="0.55" width="0.2032" layer="21"/>
<wire x1="17.965" y1="-0.55" x2="18.865" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="17.965" y1="-2.3" x2="18.865" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="20.135" y1="2.3" x2="19.235" y2="2.3" width="0.2032" layer="21"/>
<wire x1="19.235" y1="0.55" x2="20.135" y2="0.55" width="0.2032" layer="21"/>
<wire x1="19.235" y1="-0.55" x2="20.135" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="19.235" y1="-2.3" x2="20.135" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="21.405" y1="2.3" x2="20.505" y2="2.3" width="0.2032" layer="21"/>
<wire x1="20.505" y1="0.55" x2="21.405" y2="0.55" width="0.2032" layer="21"/>
<wire x1="20.505" y1="-0.55" x2="21.405" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="20.505" y1="-2.3" x2="21.405" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="22.675" y1="2.3" x2="21.775" y2="2.3" width="0.2032" layer="21"/>
<wire x1="21.775" y1="0.55" x2="22.675" y2="0.55" width="0.2032" layer="21"/>
<wire x1="21.775" y1="-0.55" x2="22.675" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="21.775" y1="-2.3" x2="22.675" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="23.945" y1="2.3" x2="23.045" y2="2.3" width="0.2032" layer="21"/>
<wire x1="23.045" y1="0.55" x2="23.945" y2="0.55" width="0.2032" layer="21"/>
<wire x1="23.045" y1="-0.55" x2="23.945" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="23.045" y1="-2.3" x2="23.945" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="25.215" y1="2.3" x2="24.315" y2="2.3" width="0.2032" layer="21"/>
<wire x1="24.315" y1="0.55" x2="25.215" y2="0.55" width="0.2032" layer="21"/>
<wire x1="24.315" y1="-0.55" x2="25.215" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="24.315" y1="-2.3" x2="25.215" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="26.485" y1="2.3" x2="25.585" y2="2.3" width="0.2032" layer="21"/>
<wire x1="25.585" y1="0.55" x2="26.485" y2="0.55" width="0.2032" layer="21"/>
<wire x1="25.585" y1="-0.55" x2="26.485" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="25.585" y1="-2.3" x2="26.485" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="27.755" y1="2.3" x2="26.855" y2="2.3" width="0.2032" layer="21"/>
<wire x1="26.855" y1="0.55" x2="27.755" y2="0.55" width="0.2032" layer="21"/>
<wire x1="26.855" y1="-0.55" x2="27.755" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="26.855" y1="-2.3" x2="27.755" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="29.025" y1="2.3" x2="28.125" y2="2.3" width="0.2032" layer="21"/>
<wire x1="28.125" y1="0.55" x2="29.025" y2="0.55" width="0.2032" layer="21"/>
<wire x1="28.125" y1="-0.55" x2="29.025" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="28.125" y1="-2.3" x2="29.025" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="30.295" y1="2.3" x2="29.395" y2="2.3" width="0.2032" layer="21"/>
<wire x1="29.395" y1="0.55" x2="30.295" y2="0.55" width="0.2032" layer="21"/>
<wire x1="29.395" y1="-0.55" x2="30.295" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="29.395" y1="-2.3" x2="30.295" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="31.565" y1="2.3" x2="30.665" y2="2.3" width="0.2032" layer="21"/>
<wire x1="30.665" y1="0.55" x2="31.565" y2="0.55" width="0.2032" layer="21"/>
<wire x1="30.665" y1="-0.55" x2="31.565" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="30.665" y1="-2.3" x2="31.565" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="32.835" y1="2.3" x2="31.935" y2="2.3" width="0.2032" layer="21"/>
<wire x1="31.935" y1="0.55" x2="32.835" y2="0.55" width="0.2032" layer="21"/>
<wire x1="31.935" y1="-0.55" x2="32.835" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="31.935" y1="-2.3" x2="32.835" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="34.105" y1="2.3" x2="33.205" y2="2.3" width="0.2032" layer="21"/>
<wire x1="33.205" y1="0.55" x2="34.105" y2="0.55" width="0.2032" layer="21"/>
<wire x1="33.205" y1="-0.55" x2="34.105" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="33.205" y1="-2.3" x2="34.105" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="35.375" y1="2.3" x2="34.475" y2="2.3" width="0.2032" layer="21"/>
<wire x1="34.475" y1="0.55" x2="35.375" y2="0.55" width="0.2032" layer="21"/>
<wire x1="34.475" y1="-0.55" x2="35.375" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="34.475" y1="-2.3" x2="35.375" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="36.645" y1="2.3" x2="35.745" y2="2.3" width="0.2032" layer="21"/>
<wire x1="35.745" y1="0.55" x2="36.645" y2="0.55" width="0.2032" layer="21"/>
<wire x1="35.745" y1="-0.55" x2="36.645" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="35.745" y1="-2.3" x2="36.645" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="37.915" y1="2.3" x2="37.015" y2="2.3" width="0.2032" layer="21"/>
<wire x1="37.015" y1="0.55" x2="37.915" y2="0.55" width="0.2032" layer="21"/>
<wire x1="37.015" y1="-0.55" x2="37.915" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="37.015" y1="-2.3" x2="37.915" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="39.185" y1="2.3" x2="38.285" y2="2.3" width="0.2032" layer="21"/>
<wire x1="38.285" y1="0.55" x2="39.185" y2="0.55" width="0.2032" layer="21"/>
<wire x1="38.285" y1="-0.55" x2="39.185" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="38.285" y1="-2.3" x2="39.185" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="40.455" y1="2.3" x2="39.555" y2="2.3" width="0.2032" layer="21"/>
<wire x1="39.555" y1="0.55" x2="40.455" y2="0.55" width="0.2032" layer="21"/>
<wire x1="39.555" y1="-0.55" x2="40.455" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="39.555" y1="-2.3" x2="40.455" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="41.725" y1="2.3" x2="40.825" y2="2.3" width="0.2032" layer="21"/>
<wire x1="40.825" y1="0.55" x2="41.725" y2="0.55" width="0.2032" layer="21"/>
<wire x1="40.825" y1="-0.55" x2="41.725" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="40.825" y1="-2.3" x2="41.725" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="42.995" y1="2.3" x2="42.095" y2="2.3" width="0.2032" layer="21"/>
<wire x1="42.095" y1="0.55" x2="42.995" y2="0.55" width="0.2032" layer="21"/>
<wire x1="42.095" y1="-0.55" x2="42.995" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="42.095" y1="-2.3" x2="42.995" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="44.265" y1="2.3" x2="43.365" y2="2.3" width="0.2032" layer="21"/>
<wire x1="43.365" y1="0.55" x2="44.265" y2="0.55" width="0.2032" layer="21"/>
<wire x1="43.365" y1="-0.55" x2="44.265" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="43.365" y1="-2.3" x2="44.265" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="45.535" y1="2.3" x2="44.635" y2="2.3" width="0.2032" layer="21"/>
<wire x1="44.635" y1="0.55" x2="45.535" y2="0.55" width="0.2032" layer="21"/>
<wire x1="44.635" y1="-0.55" x2="45.535" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="44.635" y1="-2.3" x2="45.535" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="46.805" y1="2.3" x2="45.905" y2="2.3" width="0.2032" layer="21"/>
<wire x1="45.905" y1="0.55" x2="46.805" y2="0.55" width="0.2032" layer="21"/>
<wire x1="45.905" y1="-0.55" x2="46.805" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="45.905" y1="-2.3" x2="46.805" y2="-2.3" width="0.2032" layer="21"/>
<wire x1="48.075" y1="2.3" x2="47.175" y2="2.3" width="0.2032" layer="21"/>
<wire x1="47.175" y1="0.55" x2="48.075" y2="0.55" width="0.2032" layer="21"/>
<wire x1="47.175" y1="-0.55" x2="48.075" y2="-0.55" width="0.2032" layer="21"/>
<wire x1="47.175" y1="-2.3" x2="48.075" y2="-2.3" width="0.2032" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="IC-176-2">
<wire x1="-11.43" y1="-92.71" x2="11.43" y2="-92.71" width="0.254" layer="94"/>
<wire x1="11.43" y1="-92.71" x2="11.43" y2="92.71" width="0.254" layer="94"/>
<wire x1="11.43" y1="92.71" x2="-11.43" y2="92.71" width="0.254" layer="94"/>
<wire x1="-11.43" y1="92.71" x2="-11.43" y2="-92.71" width="0.254" layer="94"/>
<text x="-11.43" y="93.98" size="1.524" layer="95">&gt;NAME</text>
<text x="-11.43" y="-95.25" size="1.524" layer="96">&gt;VALUE</text>
<pin name="T1" x="-16.51" y="90.17" length="middle" direction="pas" swaplevel="1"/>
<pin name="B1" x="16.51" y="90.17" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="T2" x="-16.51" y="87.63" length="middle" direction="pas" swaplevel="1"/>
<pin name="T3" x="-16.51" y="85.09" length="middle" direction="pas" swaplevel="1"/>
<pin name="T4" x="-16.51" y="82.55" length="middle" direction="pas" swaplevel="1"/>
<pin name="T5" x="-16.51" y="80.01" length="middle" direction="pas" swaplevel="1"/>
<pin name="T6" x="-16.51" y="77.47" length="middle" direction="pas" swaplevel="1"/>
<pin name="T7" x="-16.51" y="74.93" length="middle" direction="pas" swaplevel="1"/>
<pin name="T8" x="-16.51" y="72.39" length="middle" direction="pas" swaplevel="1"/>
<pin name="T9" x="-16.51" y="69.85" length="middle" direction="pas" swaplevel="1"/>
<pin name="T10" x="-16.51" y="67.31" length="middle" direction="pas" swaplevel="1"/>
<pin name="T11" x="-16.51" y="64.77" length="middle" direction="pas" swaplevel="1"/>
<pin name="T12" x="-16.51" y="62.23" length="middle" direction="pas" swaplevel="1"/>
<pin name="T13" x="-16.51" y="59.69" length="middle" direction="pas" swaplevel="1"/>
<pin name="T14" x="-16.51" y="57.15" length="middle" direction="pas" swaplevel="1"/>
<pin name="T15" x="-16.51" y="54.61" length="middle" direction="pas" swaplevel="1"/>
<pin name="T16" x="-16.51" y="52.07" length="middle" direction="pas" swaplevel="1"/>
<pin name="T17" x="-16.51" y="49.53" length="middle" direction="pas" swaplevel="1"/>
<pin name="T18" x="-16.51" y="46.99" length="middle" direction="pas" swaplevel="1"/>
<pin name="T19" x="-16.51" y="44.45" length="middle" direction="pas" swaplevel="1"/>
<pin name="T20" x="-16.51" y="41.91" length="middle" direction="pas" swaplevel="1"/>
<pin name="T21" x="-16.51" y="39.37" length="middle" direction="pas" swaplevel="1"/>
<pin name="T22" x="-16.51" y="36.83" length="middle" direction="pas" swaplevel="1"/>
<pin name="T23" x="-16.51" y="34.29" length="middle" direction="pas" swaplevel="1"/>
<pin name="T24" x="-16.51" y="31.75" length="middle" direction="pas" swaplevel="1"/>
<pin name="T25" x="-16.51" y="29.21" length="middle" direction="pas" swaplevel="1"/>
<pin name="T26" x="-16.51" y="26.67" length="middle" direction="pas" swaplevel="1"/>
<pin name="T27" x="-16.51" y="24.13" length="middle" direction="pas" swaplevel="1"/>
<pin name="T28" x="-16.51" y="21.59" length="middle" direction="pas" swaplevel="1"/>
<pin name="T29" x="-16.51" y="19.05" length="middle" direction="pas" swaplevel="1"/>
<pin name="T30" x="-16.51" y="16.51" length="middle" direction="pas" swaplevel="1"/>
<pin name="T31" x="-16.51" y="13.97" length="middle" direction="pas" swaplevel="1"/>
<pin name="T32" x="-16.51" y="11.43" length="middle" direction="pas" swaplevel="1"/>
<pin name="T33" x="-16.51" y="8.89" length="middle" direction="pas" swaplevel="1"/>
<pin name="T34" x="-16.51" y="6.35" length="middle" direction="pas" swaplevel="1"/>
<pin name="T35" x="-16.51" y="3.81" length="middle" direction="pas" swaplevel="1"/>
<pin name="T36" x="-16.51" y="1.27" length="middle" direction="pas" swaplevel="1"/>
<pin name="T37" x="-16.51" y="-1.27" length="middle" direction="pas" swaplevel="1"/>
<pin name="T38" x="-16.51" y="-3.81" length="middle" direction="pas" swaplevel="1"/>
<pin name="T39" x="-16.51" y="-6.35" length="middle" direction="pas" swaplevel="1"/>
<pin name="T40" x="-16.51" y="-8.89" length="middle" direction="pas" swaplevel="1"/>
<pin name="T41" x="-16.51" y="-11.43" length="middle" direction="pas" swaplevel="1"/>
<pin name="T42" x="-16.51" y="-13.97" length="middle" direction="pas" swaplevel="1"/>
<pin name="T43" x="-16.51" y="-16.51" length="middle" direction="pas" swaplevel="1"/>
<pin name="T44" x="-16.51" y="-19.05" length="middle" direction="pas" swaplevel="1"/>
<pin name="T45" x="-16.51" y="-21.59" length="middle" direction="pas" swaplevel="1"/>
<pin name="T46" x="-16.51" y="-24.13" length="middle" direction="pas" swaplevel="1"/>
<pin name="T47" x="-16.51" y="-26.67" length="middle" direction="pas" swaplevel="1"/>
<pin name="T48" x="-16.51" y="-29.21" length="middle" direction="pas" swaplevel="1"/>
<pin name="T49" x="-16.51" y="-31.75" length="middle" direction="pas" swaplevel="1"/>
<pin name="T50" x="-16.51" y="-34.29" length="middle" direction="pas" swaplevel="1"/>
<pin name="T51" x="-16.51" y="-36.83" length="middle" direction="pas" swaplevel="1"/>
<pin name="T52" x="-16.51" y="-39.37" length="middle" direction="pas" swaplevel="1"/>
<pin name="T53" x="-16.51" y="-41.91" length="middle" direction="pas" swaplevel="1"/>
<pin name="T54" x="-16.51" y="-44.45" length="middle" direction="pas" swaplevel="1"/>
<pin name="T55" x="-16.51" y="-46.99" length="middle" direction="pas" swaplevel="1"/>
<pin name="T56" x="-16.51" y="-49.53" length="middle" direction="pas" swaplevel="1"/>
<pin name="T57" x="-16.51" y="-52.07" length="middle" direction="pas" swaplevel="1"/>
<pin name="T58" x="-16.51" y="-54.61" length="middle" direction="pas" swaplevel="1"/>
<pin name="T59" x="-16.51" y="-57.15" length="middle" direction="pas" swaplevel="1"/>
<pin name="T60" x="-16.51" y="-59.69" length="middle" direction="pas" swaplevel="1"/>
<pin name="T61" x="-16.51" y="-62.23" length="middle" direction="pas" swaplevel="1"/>
<pin name="T62" x="-16.51" y="-64.77" length="middle" direction="pas" swaplevel="1"/>
<pin name="T63" x="-16.51" y="-67.31" length="middle" direction="pas" swaplevel="1"/>
<pin name="T64" x="-16.51" y="-69.85" length="middle" direction="pas" swaplevel="1"/>
<pin name="T65" x="-16.51" y="-72.39" length="middle" direction="pas" swaplevel="1"/>
<pin name="T66" x="-16.51" y="-74.93" length="middle" direction="pas" swaplevel="1"/>
<pin name="T67" x="-16.51" y="-77.47" length="middle" direction="pas" swaplevel="1"/>
<pin name="T68" x="-16.51" y="-80.01" length="middle" direction="pas" swaplevel="1"/>
<pin name="T69" x="-16.51" y="-82.55" length="middle" direction="pas" swaplevel="1"/>
<pin name="T70" x="-16.51" y="-85.09" length="middle" direction="pas" swaplevel="1"/>
<pin name="T71" x="-16.51" y="-87.63" length="middle" direction="pas" swaplevel="1"/>
<pin name="T72" x="-16.51" y="-90.17" length="middle" direction="pas" swaplevel="1"/>
<pin name="B2" x="16.51" y="87.63" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B3" x="16.51" y="85.09" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B4" x="16.51" y="82.55" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B5" x="16.51" y="80.01" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B6" x="16.51" y="77.47" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B7" x="16.51" y="74.93" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B8" x="16.51" y="72.39" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B9" x="16.51" y="69.85" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B10" x="16.51" y="67.31" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B11" x="16.51" y="64.77" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B12" x="16.51" y="62.23" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B13" x="16.51" y="59.69" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B14" x="16.51" y="57.15" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B15" x="16.51" y="54.61" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B16" x="16.51" y="52.07" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B17" x="16.51" y="49.53" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B18" x="16.51" y="46.99" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B19" x="16.51" y="44.45" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B20" x="16.51" y="41.91" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B21" x="16.51" y="39.37" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B22" x="16.51" y="36.83" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B23" x="16.51" y="34.29" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B24" x="16.51" y="31.75" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B25" x="16.51" y="29.21" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B26" x="16.51" y="26.67" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B27" x="16.51" y="24.13" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B28" x="16.51" y="21.59" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B29" x="16.51" y="19.05" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B30" x="16.51" y="16.51" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B31" x="16.51" y="13.97" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B32" x="16.51" y="11.43" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B33" x="16.51" y="8.89" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B34" x="16.51" y="6.35" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B35" x="16.51" y="3.81" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B36" x="16.51" y="1.27" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B37" x="16.51" y="-1.27" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B38" x="16.51" y="-3.81" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B39" x="16.51" y="-6.35" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B40" x="16.51" y="-8.89" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B41" x="16.51" y="-11.43" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B42" x="16.51" y="-13.97" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B43" x="16.51" y="-16.51" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B44" x="16.51" y="-19.05" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B45" x="16.51" y="-21.59" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B46" x="16.51" y="-24.13" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B47" x="16.51" y="-26.67" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B48" x="16.51" y="-29.21" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B49" x="16.51" y="-31.75" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B50" x="16.51" y="-34.29" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B51" x="16.51" y="-36.83" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B52" x="16.51" y="-39.37" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B53" x="16.51" y="-41.91" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B54" x="16.51" y="-44.45" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B55" x="16.51" y="-46.99" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B56" x="16.51" y="-49.53" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B57" x="16.51" y="-52.07" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B58" x="16.51" y="-54.61" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B59" x="16.51" y="-57.15" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B60" x="16.51" y="-59.69" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B61" x="16.51" y="-62.23" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B62" x="16.51" y="-64.77" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B63" x="16.51" y="-67.31" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B64" x="16.51" y="-69.85" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B65" x="16.51" y="-72.39" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B66" x="16.51" y="-74.93" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B67" x="16.51" y="-77.47" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B68" x="16.51" y="-80.01" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B69" x="16.51" y="-82.55" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B70" x="16.51" y="-85.09" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B71" x="16.51" y="-87.63" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="B72" x="16.51" y="-90.17" length="middle" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="IC-176-2" prefix="T" uservalue="yes">
<gates>
<gate name="A" symbol="IC-176-2" x="0" y="0"/>
</gates>
<devices>
<device name="" package="IC-176-2">
<connects>
<connect gate="A" pin="B1" pad="B1"/>
<connect gate="A" pin="B10" pad="B10"/>
<connect gate="A" pin="B11" pad="B11"/>
<connect gate="A" pin="B12" pad="B12"/>
<connect gate="A" pin="B13" pad="B13"/>
<connect gate="A" pin="B14" pad="B14"/>
<connect gate="A" pin="B15" pad="B15"/>
<connect gate="A" pin="B16" pad="B16"/>
<connect gate="A" pin="B17" pad="B17"/>
<connect gate="A" pin="B18" pad="B18"/>
<connect gate="A" pin="B19" pad="B19"/>
<connect gate="A" pin="B2" pad="B2"/>
<connect gate="A" pin="B20" pad="B20"/>
<connect gate="A" pin="B21" pad="B21"/>
<connect gate="A" pin="B22" pad="B22"/>
<connect gate="A" pin="B23" pad="B23"/>
<connect gate="A" pin="B24" pad="B24"/>
<connect gate="A" pin="B25" pad="B25"/>
<connect gate="A" pin="B26" pad="B26"/>
<connect gate="A" pin="B27" pad="B27"/>
<connect gate="A" pin="B28" pad="B28"/>
<connect gate="A" pin="B29" pad="B29"/>
<connect gate="A" pin="B3" pad="B3"/>
<connect gate="A" pin="B30" pad="B30"/>
<connect gate="A" pin="B31" pad="B31"/>
<connect gate="A" pin="B32" pad="B32"/>
<connect gate="A" pin="B33" pad="B33"/>
<connect gate="A" pin="B34" pad="B34"/>
<connect gate="A" pin="B35" pad="B35"/>
<connect gate="A" pin="B36" pad="B36"/>
<connect gate="A" pin="B37" pad="B37"/>
<connect gate="A" pin="B38" pad="B38"/>
<connect gate="A" pin="B39" pad="B39"/>
<connect gate="A" pin="B4" pad="B4"/>
<connect gate="A" pin="B40" pad="B40"/>
<connect gate="A" pin="B41" pad="B41"/>
<connect gate="A" pin="B42" pad="B42"/>
<connect gate="A" pin="B43" pad="B43"/>
<connect gate="A" pin="B44" pad="B44"/>
<connect gate="A" pin="B45" pad="B45"/>
<connect gate="A" pin="B46" pad="B46"/>
<connect gate="A" pin="B47" pad="B47"/>
<connect gate="A" pin="B48" pad="B48"/>
<connect gate="A" pin="B49" pad="B49"/>
<connect gate="A" pin="B5" pad="B5"/>
<connect gate="A" pin="B50" pad="B50"/>
<connect gate="A" pin="B51" pad="B51"/>
<connect gate="A" pin="B52" pad="B52"/>
<connect gate="A" pin="B53" pad="B53"/>
<connect gate="A" pin="B54" pad="B54"/>
<connect gate="A" pin="B55" pad="B55"/>
<connect gate="A" pin="B56" pad="B56"/>
<connect gate="A" pin="B57" pad="B57"/>
<connect gate="A" pin="B58" pad="B58"/>
<connect gate="A" pin="B59" pad="B59"/>
<connect gate="A" pin="B6" pad="B6"/>
<connect gate="A" pin="B60" pad="B60"/>
<connect gate="A" pin="B61" pad="B61"/>
<connect gate="A" pin="B62" pad="B62"/>
<connect gate="A" pin="B63" pad="B63"/>
<connect gate="A" pin="B64" pad="B64"/>
<connect gate="A" pin="B65" pad="B65"/>
<connect gate="A" pin="B66" pad="B66"/>
<connect gate="A" pin="B67" pad="B67"/>
<connect gate="A" pin="B68" pad="B68"/>
<connect gate="A" pin="B69" pad="B69"/>
<connect gate="A" pin="B7" pad="B7"/>
<connect gate="A" pin="B70" pad="B70"/>
<connect gate="A" pin="B71" pad="B71"/>
<connect gate="A" pin="B72" pad="B72"/>
<connect gate="A" pin="B8" pad="B8"/>
<connect gate="A" pin="B9" pad="B9"/>
<connect gate="A" pin="T1" pad="T1"/>
<connect gate="A" pin="T10" pad="T10"/>
<connect gate="A" pin="T11" pad="T11"/>
<connect gate="A" pin="T12" pad="T12"/>
<connect gate="A" pin="T13" pad="T13"/>
<connect gate="A" pin="T14" pad="T14"/>
<connect gate="A" pin="T15" pad="T15"/>
<connect gate="A" pin="T16" pad="T16"/>
<connect gate="A" pin="T17" pad="T17"/>
<connect gate="A" pin="T18" pad="T18"/>
<connect gate="A" pin="T19" pad="T19"/>
<connect gate="A" pin="T2" pad="T2"/>
<connect gate="A" pin="T20" pad="T20"/>
<connect gate="A" pin="T21" pad="T21"/>
<connect gate="A" pin="T22" pad="T22"/>
<connect gate="A" pin="T23" pad="T23"/>
<connect gate="A" pin="T24" pad="T24"/>
<connect gate="A" pin="T25" pad="T25"/>
<connect gate="A" pin="T26" pad="T26"/>
<connect gate="A" pin="T27" pad="T27"/>
<connect gate="A" pin="T28" pad="T28"/>
<connect gate="A" pin="T29" pad="T29"/>
<connect gate="A" pin="T3" pad="T3"/>
<connect gate="A" pin="T30" pad="T30"/>
<connect gate="A" pin="T31" pad="T31"/>
<connect gate="A" pin="T32" pad="T32"/>
<connect gate="A" pin="T33" pad="T33"/>
<connect gate="A" pin="T34" pad="T34"/>
<connect gate="A" pin="T35" pad="T35"/>
<connect gate="A" pin="T36" pad="T36"/>
<connect gate="A" pin="T37" pad="T37"/>
<connect gate="A" pin="T38" pad="T38"/>
<connect gate="A" pin="T39" pad="T39"/>
<connect gate="A" pin="T4" pad="T4"/>
<connect gate="A" pin="T40" pad="T40"/>
<connect gate="A" pin="T41" pad="T41"/>
<connect gate="A" pin="T42" pad="T42"/>
<connect gate="A" pin="T43" pad="T43"/>
<connect gate="A" pin="T44" pad="T44"/>
<connect gate="A" pin="T45" pad="T45"/>
<connect gate="A" pin="T46" pad="T46"/>
<connect gate="A" pin="T47" pad="T47"/>
<connect gate="A" pin="T48" pad="T48"/>
<connect gate="A" pin="T49" pad="T49"/>
<connect gate="A" pin="T5" pad="T5"/>
<connect gate="A" pin="T50" pad="T50"/>
<connect gate="A" pin="T51" pad="T51"/>
<connect gate="A" pin="T52" pad="T52"/>
<connect gate="A" pin="T53" pad="T53"/>
<connect gate="A" pin="T54" pad="T54"/>
<connect gate="A" pin="T55" pad="T55"/>
<connect gate="A" pin="T56" pad="T56"/>
<connect gate="A" pin="T57" pad="T57"/>
<connect gate="A" pin="T58" pad="T58"/>
<connect gate="A" pin="T59" pad="T59"/>
<connect gate="A" pin="T6" pad="T6"/>
<connect gate="A" pin="T60" pad="T60"/>
<connect gate="A" pin="T61" pad="T61"/>
<connect gate="A" pin="T62" pad="T62"/>
<connect gate="A" pin="T63" pad="T63"/>
<connect gate="A" pin="T64" pad="T64"/>
<connect gate="A" pin="T65" pad="T65"/>
<connect gate="A" pin="T66" pad="T66"/>
<connect gate="A" pin="T67" pad="T67"/>
<connect gate="A" pin="T68" pad="T68"/>
<connect gate="A" pin="T69" pad="T69"/>
<connect gate="A" pin="T7" pad="T7"/>
<connect gate="A" pin="T70" pad="T70"/>
<connect gate="A" pin="T71" pad="T71"/>
<connect gate="A" pin="T72" pad="T72"/>
<connect gate="A" pin="T8" pad="T8"/>
<connect gate="A" pin="T9" pad="T9"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="SYMBOLY">
<packages>
</packages>
<symbols>
<symbol name="GND">
<wire x1="-2.54" y1="0" x2="2.54" y2="0" width="0.6096" layer="94"/>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
<symbol name="VCC1">
<text x="-0.635" y="-0.635" size="1.524" layer="94" rot="MR0">VCC1</text>
<pin name="VCC1" x="2.54" y="0" visible="off" length="short" direction="sup" rot="R180"/>
</symbol>
<symbol name="VCC2">
<text x="-0.635" y="-0.635" size="1.524" layer="94" rot="MR0">VCC2</text>
<pin name="VCC2" x="2.54" y="0" visible="off" length="short" direction="sup" rot="R180"/>
</symbol>
<symbol name="VCC3">
<text x="-0.635" y="-0.635" size="1.524" layer="94" rot="MR0">VCC3</text>
<pin name="VCC3" x="2.54" y="0" visible="off" length="short" direction="sup" rot="R180"/>
</symbol>
<symbol name="VCC4">
<text x="-0.635" y="-0.635" size="1.524" layer="94" rot="MR0">VCC4</text>
<pin name="VCC4" x="2.54" y="0" visible="off" length="short" direction="sup" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="GND">
<gates>
<gate name="GND" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="VCC1">
<gates>
<gate name="G$1" symbol="VCC1" x="0" y="0" swaplevel="1"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="VCC2">
<gates>
<gate name="G$1" symbol="VCC2" x="0" y="0" swaplevel="1"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="VCC3">
<gates>
<gate name="G$1" symbol="VCC3" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="VCC4">
<gates>
<gate name="G$1" symbol="VCC4" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
</libraries>
<attributes>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0" drill="0">
</class>
</classes>
<parts>
<part name="U1" library="74499" deviceset="74244" device="" value="HD74HCT244P"/>
<part name="U2" library="74499" deviceset="74244" device="" value="HD74HCT244P"/>
<part name="U3" library="74499" deviceset="74244" device="" value="HD74HCT244P"/>
<part name="U4" library="74499" deviceset="74244" device="" value="HD74HCT244P"/>
<part name="U5" library="74499" deviceset="74244" device="" value="HD74HCT244P"/>
<part name="U6" library="74499" deviceset="74244" device="" value="HD74HCT244P"/>
<part name="U7" library="74499" deviceset="74244" device="" value="HD74HCT244P"/>
<part name="U8" library="74499" deviceset="74244" device="" value="HD74HCT244P"/>
<part name="U9" library="74499" deviceset="74244" device="" value="HD74HCT244P"/>
<part name="U10" library="74499" deviceset="74244" device="" value="HD74HCT244P"/>
<part name="U11" library="74499" deviceset="74244" device="" value="HD74HCT244P"/>
<part name="U12" library="74499" deviceset="74244" device="" value="HD74HCT244P"/>
<part name="U13" library="40XX" deviceset="4040" device="" value="TC4040BP"/>
<part name="U14" library="40XX" deviceset="4040" device="" value="TC4040BP"/>
<part name="C1" library="PASIV" deviceset="KER-C" device="" value="100n"/>
<part name="C2" library="PASIV" deviceset="KER-C" device="" value="100n"/>
<part name="C3" library="PASIV" deviceset="KER-C" device="" value="100n"/>
<part name="C4" library="PASIV" deviceset="KER-C" device="" value="100n"/>
<part name="C5" library="PASIV" deviceset="KER-C" device="" value="100n"/>
<part name="C6" library="PASIV" deviceset="KER-C" device="" value="100n"/>
<part name="C7" library="PASIV" deviceset="KER-C" device="" value="100n"/>
<part name="C8" library="PASIV" deviceset="KER-C" device="" value="100n"/>
<part name="C9" library="PASIV" deviceset="KER-C" device="" value="100n"/>
<part name="C10" library="PASIV" deviceset="KER-C" device="" value="100n"/>
<part name="C11" library="PASIV" deviceset="KER-C" device="" value="100n"/>
<part name="C12" library="PASIV" deviceset="KER-C" device="" value="100n"/>
<part name="C13" library="PASIV" deviceset="KER-C" device="" value="100n"/>
<part name="C14" library="PASIV" deviceset="KER-C" device="" value="100n"/>
<part name="C15" library="PASIV" deviceset="KER-C" device="" value="10n"/>
<part name="C16" library="PASIV" deviceset="E-TANT-5" device="" value="1u/35V"/>
<part name="RP1" library="PASIV" deviceset="R-NET8A" device="" value="4k7"/>
<part name="RP2" library="PASIV" deviceset="R-NET8A" device="" value="4k7"/>
<part name="RP3" library="PASIV" deviceset="R-NET8A" device="" value="4k7"/>
<part name="RP4" library="PASIV" deviceset="R-NET8A" device="" value="4k7"/>
<part name="RP5" library="PASIV" deviceset="R-NET8A" device="" value="4k7"/>
<part name="CN1" library="SVORKY" deviceset="DIL40" device="" value="2x20"/>
<part name="T1" library="CONNEC" deviceset="IC-176-2" device="" value="IC-176-2"/>
<part name="U$2" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$1" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$3" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$4" library="SYMBOLY" deviceset="VCC1" device=""/>
<part name="U$5" library="SYMBOLY" deviceset="VCC2" device=""/>
<part name="U$6" library="SYMBOLY" deviceset="VCC3" device=""/>
<part name="U$7" library="SYMBOLY" deviceset="VCC4" device=""/>
<part name="U$8" library="SYMBOLY" deviceset="VCC1" device=""/>
<part name="U$9" library="SYMBOLY" deviceset="VCC3" device=""/>
<part name="U$10" library="SYMBOLY" deviceset="VCC4" device=""/>
<part name="U$11" library="SYMBOLY" deviceset="VCC2" device=""/>
<part name="U$12" library="SYMBOLY" deviceset="VCC2" device=""/>
<part name="U$13" library="SYMBOLY" deviceset="VCC2" device=""/>
<part name="U$14" library="SYMBOLY" deviceset="VCC2" device=""/>
<part name="U$15" library="SYMBOLY" deviceset="VCC2" device=""/>
<part name="U$16" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$17" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$18" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$19" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$20" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$21" library="SYMBOLY" deviceset="VCC3" device=""/>
<part name="U$22" library="SYMBOLY" deviceset="VCC3" device=""/>
<part name="U$23" library="SYMBOLY" deviceset="VCC3" device=""/>
<part name="U$24" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$25" library="SYMBOLY" deviceset="VCC3" device=""/>
<part name="U$26" library="SYMBOLY" deviceset="VCC3" device=""/>
<part name="U$27" library="SYMBOLY" deviceset="VCC3" device=""/>
<part name="U$28" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$29" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$30" library="SYMBOLY" deviceset="GND" device=""/>
</parts>
<sheets>
<sheet>
<plain>
</plain>
<instances>
<instance part="U1" gate="A" x="27.94" y="96.52"/>
<instance part="U1" gate="A1" x="35.56" y="111.76" rot="R180"/>
<instance part="U1" gate="A2" x="35.56" y="109.22" rot="R180"/>
<instance part="U1" gate="A3" x="35.56" y="106.68" rot="R180"/>
<instance part="U1" gate="A4" x="35.56" y="104.14" rot="R180"/>
<instance part="U1" gate="B" x="27.94" y="44.45"/>
<instance part="U1" gate="B1" x="35.56" y="59.69" rot="R180"/>
<instance part="U1" gate="B2" x="35.56" y="57.15" rot="R180"/>
<instance part="U1" gate="B3" x="35.56" y="54.61" rot="R180"/>
<instance part="U1" gate="B4" x="35.56" y="52.07" rot="R180"/>
<instance part="U2" gate="A" x="106.68" y="96.52"/>
<instance part="U2" gate="A1" x="114.3" y="111.76" rot="R180"/>
<instance part="U2" gate="A2" x="114.3" y="109.22" rot="R180"/>
<instance part="U2" gate="A3" x="114.3" y="106.68" rot="R180"/>
<instance part="U2" gate="A4" x="114.3" y="104.14" rot="R180"/>
<instance part="U2" gate="B" x="106.68" y="44.45"/>
<instance part="U2" gate="B1" x="114.3" y="59.69" rot="R180"/>
<instance part="U2" gate="B2" x="114.3" y="57.15" rot="R180"/>
<instance part="U2" gate="B3" x="114.3" y="54.61" rot="R180"/>
<instance part="U2" gate="B4" x="114.3" y="52.07" rot="R180"/>
<instance part="U3" gate="A" x="185.42" y="96.52"/>
<instance part="U3" gate="A1" x="193.04" y="111.76" rot="R180"/>
<instance part="U3" gate="A2" x="193.04" y="109.22" rot="R180"/>
<instance part="U3" gate="A3" x="193.04" y="106.68" rot="R180"/>
<instance part="U3" gate="A4" x="193.04" y="104.14" rot="R180"/>
<instance part="U3" gate="B" x="185.42" y="44.45"/>
<instance part="U3" gate="B1" x="193.04" y="59.69" rot="R180"/>
<instance part="U3" gate="B2" x="193.04" y="57.15" rot="R180"/>
<instance part="U3" gate="B3" x="193.04" y="54.61" rot="R180"/>
<instance part="U3" gate="B4" x="193.04" y="52.07" rot="R180"/>
<instance part="U4" gate="A" x="264.16" y="96.52"/>
<instance part="U4" gate="A1" x="271.78" y="111.76" rot="R180"/>
<instance part="U4" gate="A2" x="271.78" y="109.22" rot="R180"/>
<instance part="U4" gate="A3" x="271.78" y="106.68" rot="R180"/>
<instance part="U4" gate="A4" x="271.78" y="104.14" rot="R180"/>
<instance part="U4" gate="B" x="264.16" y="44.45"/>
<instance part="U4" gate="B1" x="271.78" y="59.69" rot="R180"/>
<instance part="U4" gate="B2" x="271.78" y="57.15" rot="R180"/>
<instance part="U4" gate="B3" x="271.78" y="54.61" rot="R180"/>
<instance part="U4" gate="B4" x="271.78" y="52.07" rot="R180"/>
<instance part="U5" gate="A" x="27.94" y="73.66"/>
<instance part="U5" gate="A1" x="35.56" y="88.9"/>
<instance part="U5" gate="A2" x="35.56" y="86.36"/>
<instance part="U5" gate="A3" x="35.56" y="83.82"/>
<instance part="U5" gate="A4" x="35.56" y="81.28"/>
<instance part="U5" gate="B" x="27.94" y="21.59"/>
<instance part="U5" gate="B1" x="35.56" y="36.83"/>
<instance part="U5" gate="B2" x="35.56" y="34.29"/>
<instance part="U5" gate="B3" x="35.56" y="31.75"/>
<instance part="U5" gate="B4" x="35.56" y="29.21"/>
<instance part="U6" gate="A" x="106.68" y="73.66"/>
<instance part="U6" gate="A1" x="114.3" y="88.9"/>
<instance part="U6" gate="A2" x="114.3" y="86.36"/>
<instance part="U6" gate="A3" x="114.3" y="83.82"/>
<instance part="U6" gate="A4" x="114.3" y="81.28"/>
<instance part="U6" gate="B" x="106.68" y="21.59"/>
<instance part="U6" gate="B1" x="114.3" y="36.83"/>
<instance part="U6" gate="B2" x="114.3" y="34.29"/>
<instance part="U6" gate="B3" x="114.3" y="31.75"/>
<instance part="U6" gate="B4" x="114.3" y="29.21"/>
<instance part="U7" gate="A" x="185.42" y="73.66"/>
<instance part="U7" gate="A1" x="193.04" y="88.9"/>
<instance part="U7" gate="A2" x="193.04" y="86.36"/>
<instance part="U7" gate="A3" x="193.04" y="83.82"/>
<instance part="U7" gate="A4" x="193.04" y="81.28"/>
<instance part="U7" gate="B" x="185.42" y="21.59"/>
<instance part="U7" gate="B1" x="193.04" y="36.83"/>
<instance part="U7" gate="B2" x="193.04" y="34.29"/>
<instance part="U7" gate="B3" x="193.04" y="31.75"/>
<instance part="U7" gate="B4" x="193.04" y="29.21"/>
<instance part="U8" gate="A" x="264.16" y="73.66"/>
<instance part="U8" gate="A1" x="271.78" y="88.9"/>
<instance part="U8" gate="A2" x="271.78" y="86.36"/>
<instance part="U8" gate="A3" x="271.78" y="83.82"/>
<instance part="U8" gate="A4" x="271.78" y="81.28"/>
<instance part="U8" gate="B" x="264.16" y="21.59"/>
<instance part="U8" gate="B1" x="271.78" y="36.83"/>
<instance part="U8" gate="B2" x="271.78" y="34.29"/>
<instance part="U8" gate="B3" x="271.78" y="31.75"/>
<instance part="U8" gate="B4" x="271.78" y="29.21"/>
<instance part="U9" gate="A" x="106.68" y="-104.14"/>
<instance part="U9" gate="A1" x="114.3" y="-88.9"/>
<instance part="U9" gate="A2" x="114.3" y="-91.44"/>
<instance part="U9" gate="A3" x="114.3" y="-93.98"/>
<instance part="U9" gate="A4" x="114.3" y="-96.52"/>
<instance part="U9" gate="B" x="106.68" y="-81.28"/>
<instance part="U9" gate="B1" x="114.3" y="-66.04" rot="R180"/>
<instance part="U9" gate="B2" x="114.3" y="-68.58" rot="R180"/>
<instance part="U9" gate="B3" x="114.3" y="-71.12" rot="R180"/>
<instance part="U9" gate="B4" x="114.3" y="-73.66" rot="R180"/>
<instance part="U10" gate="A" x="106.68" y="-6.35"/>
<instance part="U10" gate="A1" x="114.3" y="8.89"/>
<instance part="U10" gate="A2" x="114.3" y="6.35"/>
<instance part="U10" gate="A3" x="114.3" y="3.81"/>
<instance part="U10" gate="A4" x="114.3" y="1.27"/>
<instance part="U10" gate="B" x="106.68" y="-29.21"/>
<instance part="U10" gate="B1" x="114.3" y="-13.97"/>
<instance part="U10" gate="B2" x="114.3" y="-16.51"/>
<instance part="U10" gate="B3" x="114.3" y="-19.05"/>
<instance part="U10" gate="B4" x="114.3" y="-21.59"/>
<instance part="U11" gate="A" x="106.68" y="-52.07"/>
<instance part="U11" gate="A1" x="114.3" y="-36.83"/>
<instance part="U11" gate="A2" x="114.3" y="-39.37"/>
<instance part="U11" gate="A3" x="114.3" y="-41.91"/>
<instance part="U11" gate="A4" x="114.3" y="-44.45"/>
<instance part="U11" gate="B" x="264.16" y="-52.07"/>
<instance part="U11" gate="B1" x="271.78" y="-36.83"/>
<instance part="U11" gate="B2" x="271.78" y="-39.37"/>
<instance part="U11" gate="B3" x="271.78" y="-41.91"/>
<instance part="U11" gate="B4" x="271.78" y="-44.45"/>
<instance part="U12" gate="A" x="264.16" y="-6.35"/>
<instance part="U12" gate="A1" x="271.78" y="8.89"/>
<instance part="U12" gate="A2" x="271.78" y="6.35"/>
<instance part="U12" gate="A3" x="271.78" y="3.81"/>
<instance part="U12" gate="A4" x="271.78" y="1.27"/>
<instance part="U12" gate="B" x="264.16" y="-29.21"/>
<instance part="U12" gate="B1" x="271.78" y="-13.97"/>
<instance part="U12" gate="B2" x="271.78" y="-16.51"/>
<instance part="U12" gate="B3" x="271.78" y="-19.05"/>
<instance part="U12" gate="B4" x="271.78" y="-21.59"/>
<instance part="U13" gate="A" x="35.56" y="-3.81"/>
<instance part="U14" gate="A" x="193.04" y="-3.81"/>
<instance part="U1" gate="P" x="180.34" y="-90.17"/>
<instance part="U13" gate="P" x="-72.39" y="-96.52"/>
<instance part="U14" gate="P" x="-57.15" y="-96.52"/>
<instance part="U2" gate="P" x="195.58" y="-90.17"/>
<instance part="U3" gate="P" x="210.82" y="-90.17"/>
<instance part="U4" gate="P" x="226.06" y="-90.17"/>
<instance part="U5" gate="P" x="241.3" y="-90.17"/>
<instance part="U6" gate="P" x="256.54" y="-90.17"/>
<instance part="U7" gate="P" x="271.78" y="-90.17"/>
<instance part="U8" gate="P" x="287.02" y="-90.17"/>
<instance part="U9" gate="P" x="302.26" y="-90.17"/>
<instance part="U10" gate="P" x="-118.11" y="-96.52"/>
<instance part="U11" gate="P" x="-102.87" y="-96.52"/>
<instance part="U12" gate="P" x="-87.63" y="-96.52"/>
<instance part="C1" gate="A" x="173.99" y="-90.17" smashed="yes" rot="R90">
<attribute name="NAME" x="170.18" y="-87.884" size="1.524" layer="95"/>
<attribute name="VALUE" x="168.91" y="-93.98" size="1.524" layer="96"/>
</instance>
<instance part="C2" gate="A" x="189.23" y="-90.17" smashed="yes" rot="R90">
<attribute name="NAME" x="185.42" y="-87.884" size="1.524" layer="95"/>
<attribute name="VALUE" x="184.15" y="-93.98" size="1.524" layer="96"/>
</instance>
<instance part="C3" gate="A" x="204.47" y="-90.17" smashed="yes" rot="R90">
<attribute name="NAME" x="200.66" y="-87.884" size="1.524" layer="95"/>
<attribute name="VALUE" x="199.39" y="-93.98" size="1.524" layer="96"/>
</instance>
<instance part="C4" gate="A" x="219.71" y="-90.17" smashed="yes" rot="R90">
<attribute name="NAME" x="215.9" y="-87.884" size="1.524" layer="95"/>
<attribute name="VALUE" x="214.63" y="-93.98" size="1.524" layer="96"/>
</instance>
<instance part="C5" gate="A" x="234.95" y="-90.17" smashed="yes" rot="R90">
<attribute name="NAME" x="231.14" y="-87.884" size="1.524" layer="95"/>
<attribute name="VALUE" x="229.87" y="-93.98" size="1.524" layer="96"/>
</instance>
<instance part="C6" gate="A" x="250.19" y="-90.17" smashed="yes" rot="R90">
<attribute name="NAME" x="246.38" y="-87.884" size="1.524" layer="95"/>
<attribute name="VALUE" x="245.11" y="-93.98" size="1.524" layer="96"/>
</instance>
<instance part="C7" gate="A" x="265.43" y="-90.17" smashed="yes" rot="R90">
<attribute name="NAME" x="261.62" y="-87.884" size="1.524" layer="95"/>
<attribute name="VALUE" x="260.35" y="-93.98" size="1.524" layer="96"/>
</instance>
<instance part="C8" gate="A" x="280.67" y="-90.17" smashed="yes" rot="R90">
<attribute name="NAME" x="276.86" y="-87.884" size="1.524" layer="95"/>
<attribute name="VALUE" x="275.59" y="-93.98" size="1.524" layer="96"/>
</instance>
<instance part="C9" gate="A" x="295.91" y="-90.17" smashed="yes" rot="R90">
<attribute name="NAME" x="292.1" y="-87.884" size="1.524" layer="95"/>
<attribute name="VALUE" x="290.83" y="-93.98" size="1.524" layer="96"/>
</instance>
<instance part="C10" gate="A" x="-124.46" y="-96.52" smashed="yes" rot="R90">
<attribute name="NAME" x="-129.54" y="-94.234" size="1.524" layer="95"/>
<attribute name="VALUE" x="-129.54" y="-100.33" size="1.524" layer="96"/>
</instance>
<instance part="C11" gate="A" x="-109.22" y="-96.52" smashed="yes" rot="R90">
<attribute name="NAME" x="-114.3" y="-94.234" size="1.524" layer="95"/>
<attribute name="VALUE" x="-114.3" y="-100.33" size="1.524" layer="96"/>
</instance>
<instance part="C12" gate="A" x="-93.98" y="-96.52" smashed="yes" rot="R90">
<attribute name="NAME" x="-99.06" y="-94.234" size="1.524" layer="95"/>
<attribute name="VALUE" x="-99.06" y="-100.33" size="1.524" layer="96"/>
</instance>
<instance part="C13" gate="A" x="-78.74" y="-96.52" smashed="yes" rot="R90">
<attribute name="NAME" x="-83.82" y="-94.234" size="1.524" layer="95"/>
<attribute name="VALUE" x="-83.82" y="-100.33" size="1.524" layer="96"/>
</instance>
<instance part="C14" gate="A" x="-63.5" y="-96.52" smashed="yes" rot="R90">
<attribute name="NAME" x="-68.58" y="-94.234" size="1.524" layer="95"/>
<attribute name="VALUE" x="-68.58" y="-100.33" size="1.524" layer="96"/>
</instance>
<instance part="C15" gate="A" x="-29.21" y="-96.52" smashed="yes" rot="R270">
<attribute name="NAME" x="-34.29" y="-94.234" size="1.524" layer="95"/>
<attribute name="VALUE" x="-34.29" y="-100.33" size="1.524" layer="96"/>
</instance>
<instance part="C16" gate="A" x="-17.78" y="-96.52" smashed="yes" rot="MR270">
<attribute name="NAME" x="-16.51" y="-94.234" size="1.524" layer="95"/>
<attribute name="VALUE" x="-16.51" y="-100.33" size="1.524" layer="96"/>
</instance>
<instance part="RP1" gate="A" x="-66.04" y="116.84" smashed="yes">
<attribute name="NAME" x="-45.72" y="112.395" size="1.524" layer="95"/>
<attribute name="VALUE" x="-45.72" y="109.855" size="1.524" layer="96"/>
</instance>
<instance part="RP2" gate="A" x="-66.04" y="-68.58" smashed="yes" rot="MR180">
<attribute name="NAME" x="-45.72" y="-62.865" size="1.524" layer="95"/>
<attribute name="VALUE" x="-45.72" y="-65.405" size="1.524" layer="96"/>
</instance>
<instance part="RP3" gate="A" x="-35.56" y="116.84" smashed="yes">
<attribute name="NAME" x="-15.24" y="112.395" size="1.524" layer="95"/>
<attribute name="VALUE" x="-15.24" y="109.855" size="1.524" layer="96"/>
</instance>
<instance part="RP4" gate="A" x="-35.56" y="-68.58" smashed="yes" rot="MR180">
<attribute name="NAME" x="-15.24" y="-62.865" size="1.524" layer="95"/>
<attribute name="VALUE" x="-15.24" y="-65.405" size="1.524" layer="96"/>
</instance>
<instance part="RP5" gate="A" x="-64.77" y="0" smashed="yes" rot="MR180">
<attribute name="NAME" x="-44.45" y="5.715" size="1.524" layer="95"/>
<attribute name="VALUE" x="-44.45" y="3.175" size="1.524" layer="96"/>
</instance>
<instance part="CN1" gate="A" x="35.56" y="-77.47"/>
<instance part="T1" gate="A" x="-109.22" y="16.51"/>
<instance part="U$2" gate="GND" x="168.91" y="-105.41"/>
<instance part="U$1" gate="GND" x="-129.54" y="-111.76"/>
<instance part="U$3" gate="GND" x="-34.29" y="-111.76"/>
<instance part="U$4" gate="G$1" x="16.51" y="-53.34"/>
<instance part="U$5" gate="G$1" x="16.51" y="-63.5"/>
<instance part="U$6" gate="G$1" x="16.51" y="-68.58"/>
<instance part="U$7" gate="G$1" x="16.51" y="-99.06"/>
<instance part="U$8" gate="G$1" x="-130.81" y="-85.09"/>
<instance part="U$9" gate="G$1" x="-35.56" y="-85.09"/>
<instance part="U$10" gate="G$1" x="167.64" y="-78.74"/>
<instance part="U$11" gate="G$1" x="-71.12" y="116.84"/>
<instance part="U$12" gate="G$1" x="-71.12" y="-68.58" rot="MR180"/>
<instance part="U$13" gate="G$1" x="-40.64" y="116.84"/>
<instance part="U$14" gate="G$1" x="-40.64" y="-68.58" rot="MR180"/>
<instance part="U$15" gate="G$1" x="-71.12" y="0" rot="MR180"/>
<instance part="U$16" gate="GND" x="17.78" y="-105.41"/>
<instance part="U$17" gate="GND" x="-81.28" y="106.68"/>
<instance part="U$18" gate="GND" x="-81.28" y="7.62"/>
<instance part="U$19" gate="GND" x="-81.28" y="-12.7"/>
<instance part="U$20" gate="GND" x="-81.28" y="-76.2"/>
<instance part="U$21" gate="G$1" x="-83.82" y="83.82" rot="R180"/>
<instance part="U$22" gate="G$1" x="-83.82" y="33.02" rot="R180"/>
<instance part="U$23" gate="G$1" x="-83.82" y="-40.64" rot="R180"/>
<instance part="U$24" gate="GND" x="-137.16" y="106.68"/>
<instance part="U$25" gate="G$1" x="-134.62" y="33.02"/>
<instance part="U$26" gate="G$1" x="-134.62" y="83.82"/>
<instance part="U$27" gate="G$1" x="-134.62" y="-40.64"/>
<instance part="U$28" gate="GND" x="-137.16" y="7.62"/>
<instance part="U$29" gate="GND" x="-137.16" y="-12.7"/>
<instance part="U$30" gate="GND" x="-137.16" y="-76.2"/>
</instances>
<busses>
<bus name="A[0..10],D[0..35],DP[0..3],!RE!_D0-D15,!RE!_D16-D31,!RE!_D32-D35,!CAS0123,!RAS0_2_,!WE!_D0-D35,!WE!_A11-A21,!WE!_A0-A10,INP_A11-A21,INP_A0-A10,RES_A0-A10,RES_A11-A21,D15/31,D14/30,D13/29,D12/28,D11/27,D10/26,D9/25,D8/24,D7/23,D6/22,D5/21,D4/20,D3/19,D2/18,D1/17,D0/16">
<segment>
<wire x1="231.14" y1="-60.96" x2="231.14" y2="100.33" width="0.762" layer="92"/>
<wire x1="-3.81" y1="105.41" x2="-3.81" y2="-113.03" width="0.762" layer="92"/>
<wire x1="-3.81" y1="-113.03" x2="73.66" y2="-113.03" width="0.762" layer="92"/>
<wire x1="73.66" y1="-113.03" x2="152.4" y2="-113.03" width="0.762" layer="92"/>
<wire x1="73.66" y1="-113.03" x2="73.66" y2="100.33" width="0.762" layer="92"/>
<wire x1="152.4" y1="100.33" x2="152.4" y2="-60.96" width="0.762" layer="92"/>
<wire x1="152.4" y1="-60.96" x2="152.4" y2="-113.03" width="0.762" layer="92"/>
<wire x1="231.14" y1="-60.96" x2="152.4" y2="-60.96" width="0.762" layer="92"/>
<wire x1="231.14" y1="-60.96" x2="306.07" y2="-60.96" width="0.762" layer="92"/>
<wire x1="306.07" y1="-60.96" x2="306.07" y2="90.17" width="0.762" layer="92"/>
</segment>
</bus>
</busses>
<nets>
<net name="GND" class="0">
<segment>
<pinref part="C1" gate="A" pin="1"/>
<wire x1="302.26" y1="-101.6" x2="295.91" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="295.91" y1="-101.6" x2="287.02" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="287.02" y1="-101.6" x2="280.67" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="280.67" y1="-101.6" x2="271.78" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="271.78" y1="-101.6" x2="265.43" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="265.43" y1="-101.6" x2="256.54" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="256.54" y1="-101.6" x2="250.19" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="250.19" y1="-101.6" x2="241.3" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="241.3" y1="-101.6" x2="234.95" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="234.95" y1="-101.6" x2="226.06" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="226.06" y1="-101.6" x2="219.71" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="219.71" y1="-101.6" x2="210.82" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="210.82" y1="-101.6" x2="204.47" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="204.47" y1="-101.6" x2="195.58" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="195.58" y1="-101.6" x2="189.23" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="189.23" y1="-101.6" x2="180.34" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="180.34" y1="-101.6" x2="173.99" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="173.99" y1="-101.6" x2="168.91" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="173.99" y1="-95.25" x2="173.99" y2="-101.6" width="0.1524" layer="91"/>
<junction x="173.99" y="-101.6"/>
<pinref part="U1" gate="P" pin="GND"/>
<wire x1="180.34" y1="-100.33" x2="180.34" y2="-101.6" width="0.1524" layer="91"/>
<junction x="180.34" y="-101.6"/>
<pinref part="C2" gate="A" pin="1"/>
<wire x1="189.23" y1="-95.25" x2="189.23" y2="-101.6" width="0.1524" layer="91"/>
<junction x="189.23" y="-101.6"/>
<pinref part="U2" gate="P" pin="GND"/>
<wire x1="195.58" y1="-100.33" x2="195.58" y2="-101.6" width="0.1524" layer="91"/>
<junction x="195.58" y="-101.6"/>
<pinref part="C3" gate="A" pin="1"/>
<wire x1="204.47" y1="-95.25" x2="204.47" y2="-101.6" width="0.1524" layer="91"/>
<junction x="204.47" y="-101.6"/>
<pinref part="U3" gate="P" pin="GND"/>
<wire x1="210.82" y1="-100.33" x2="210.82" y2="-101.6" width="0.1524" layer="91"/>
<junction x="210.82" y="-101.6"/>
<pinref part="C4" gate="A" pin="1"/>
<wire x1="219.71" y1="-95.25" x2="219.71" y2="-101.6" width="0.1524" layer="91"/>
<junction x="219.71" y="-101.6"/>
<pinref part="U4" gate="P" pin="GND"/>
<wire x1="226.06" y1="-100.33" x2="226.06" y2="-101.6" width="0.1524" layer="91"/>
<junction x="226.06" y="-101.6"/>
<pinref part="C5" gate="A" pin="1"/>
<wire x1="234.95" y1="-95.25" x2="234.95" y2="-101.6" width="0.1524" layer="91"/>
<junction x="234.95" y="-101.6"/>
<pinref part="U5" gate="P" pin="GND"/>
<wire x1="241.3" y1="-100.33" x2="241.3" y2="-101.6" width="0.1524" layer="91"/>
<junction x="241.3" y="-101.6"/>
<pinref part="C6" gate="A" pin="1"/>
<wire x1="250.19" y1="-95.25" x2="250.19" y2="-101.6" width="0.1524" layer="91"/>
<junction x="250.19" y="-101.6"/>
<pinref part="U6" gate="P" pin="GND"/>
<wire x1="256.54" y1="-100.33" x2="256.54" y2="-101.6" width="0.1524" layer="91"/>
<junction x="256.54" y="-101.6"/>
<pinref part="C7" gate="A" pin="1"/>
<wire x1="265.43" y1="-95.25" x2="265.43" y2="-101.6" width="0.1524" layer="91"/>
<junction x="265.43" y="-101.6"/>
<pinref part="C8" gate="A" pin="1"/>
<wire x1="280.67" y1="-95.25" x2="280.67" y2="-101.6" width="0.1524" layer="91"/>
<junction x="280.67" y="-101.6"/>
<pinref part="U7" gate="P" pin="GND"/>
<wire x1="271.78" y1="-100.33" x2="271.78" y2="-101.6" width="0.1524" layer="91"/>
<junction x="271.78" y="-101.6"/>
<pinref part="C9" gate="A" pin="1"/>
<wire x1="295.91" y1="-95.25" x2="295.91" y2="-101.6" width="0.1524" layer="91"/>
<junction x="295.91" y="-101.6"/>
<pinref part="U8" gate="P" pin="GND"/>
<wire x1="287.02" y1="-100.33" x2="287.02" y2="-101.6" width="0.1524" layer="91"/>
<junction x="287.02" y="-101.6"/>
<pinref part="U9" gate="P" pin="GND"/>
<wire x1="302.26" y1="-100.33" x2="302.26" y2="-101.6" width="0.1524" layer="91"/>
<pinref part="U$2" gate="GND" pin="GND"/>
<wire x1="168.91" y1="-101.6" x2="168.91" y2="-102.87" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C10" gate="A" pin="1"/>
<wire x1="-124.46" y1="-101.6" x2="-124.46" y2="-107.95" width="0.1524" layer="91"/>
<wire x1="-118.11" y1="-107.95" x2="-124.46" y2="-107.95" width="0.1524" layer="91"/>
<pinref part="U10" gate="P" pin="GND"/>
<wire x1="-118.11" y1="-106.68" x2="-118.11" y2="-107.95" width="0.1524" layer="91"/>
<junction x="-118.11" y="-107.95"/>
<wire x1="-109.22" y1="-107.95" x2="-118.11" y2="-107.95" width="0.1524" layer="91"/>
<pinref part="C11" gate="A" pin="1"/>
<wire x1="-109.22" y1="-101.6" x2="-109.22" y2="-107.95" width="0.1524" layer="91"/>
<junction x="-109.22" y="-107.95"/>
<wire x1="-102.87" y1="-107.95" x2="-109.22" y2="-107.95" width="0.1524" layer="91"/>
<pinref part="U11" gate="P" pin="GND"/>
<wire x1="-102.87" y1="-106.68" x2="-102.87" y2="-107.95" width="0.1524" layer="91"/>
<junction x="-102.87" y="-107.95"/>
<wire x1="-93.98" y1="-107.95" x2="-102.87" y2="-107.95" width="0.1524" layer="91"/>
<pinref part="C12" gate="A" pin="1"/>
<wire x1="-93.98" y1="-101.6" x2="-93.98" y2="-107.95" width="0.1524" layer="91"/>
<junction x="-93.98" y="-107.95"/>
<wire x1="-87.63" y1="-107.95" x2="-93.98" y2="-107.95" width="0.1524" layer="91"/>
<pinref part="U12" gate="P" pin="GND"/>
<wire x1="-87.63" y1="-106.68" x2="-87.63" y2="-107.95" width="0.1524" layer="91"/>
<junction x="-87.63" y="-107.95"/>
<wire x1="-78.74" y1="-107.95" x2="-87.63" y2="-107.95" width="0.1524" layer="91"/>
<pinref part="C13" gate="A" pin="1"/>
<wire x1="-78.74" y1="-101.6" x2="-78.74" y2="-107.95" width="0.1524" layer="91"/>
<junction x="-78.74" y="-107.95"/>
<pinref part="U14" gate="P" pin="GND"/>
<wire x1="-57.15" y1="-106.68" x2="-57.15" y2="-107.95" width="0.1524" layer="91"/>
<wire x1="-57.15" y1="-107.95" x2="-63.5" y2="-107.95" width="0.1524" layer="91"/>
<pinref part="C14" gate="A" pin="1"/>
<wire x1="-63.5" y1="-101.6" x2="-63.5" y2="-107.95" width="0.1524" layer="91"/>
<junction x="-63.5" y="-107.95"/>
<wire x1="-63.5" y1="-107.95" x2="-72.39" y2="-107.95" width="0.1524" layer="91"/>
<wire x1="-72.39" y1="-107.95" x2="-78.74" y2="-107.95" width="0.1524" layer="91"/>
<pinref part="U13" gate="P" pin="GND"/>
<wire x1="-72.39" y1="-106.68" x2="-72.39" y2="-107.95" width="0.1524" layer="91"/>
<junction x="-72.39" y="-107.95"/>
<pinref part="U$1" gate="GND" pin="GND"/>
<wire x1="-124.46" y1="-107.95" x2="-129.54" y2="-107.95" width="0.1524" layer="91"/>
<wire x1="-129.54" y1="-107.95" x2="-129.54" y2="-109.22" width="0.1524" layer="91"/>
<junction x="-124.46" y="-107.95"/>
</segment>
<segment>
<pinref part="C16" gate="A" pin="K"/>
<wire x1="-17.78" y1="-101.6" x2="-17.78" y2="-107.95" width="0.1524" layer="91"/>
<wire x1="-17.78" y1="-107.95" x2="-29.21" y2="-107.95" width="0.1524" layer="91"/>
<pinref part="C15" gate="A" pin="2"/>
<wire x1="-29.21" y1="-107.95" x2="-34.29" y2="-107.95" width="0.1524" layer="91"/>
<wire x1="-29.21" y1="-101.6" x2="-29.21" y2="-107.95" width="0.1524" layer="91"/>
<junction x="-29.21" y="-107.95"/>
<pinref part="U$3" gate="GND" pin="GND"/>
<wire x1="-34.29" y1="-107.95" x2="-34.29" y2="-109.22" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="CN1" gate="A" pin="20"/>
<pinref part="U$16" gate="GND" pin="GND"/>
<wire x1="21.59" y1="-101.6" x2="17.78" y2="-101.6" width="0.1524" layer="91"/>
<wire x1="17.78" y1="-101.6" x2="17.78" y2="-102.87" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="B1"/>
<pinref part="U$17" gate="GND" pin="GND"/>
<wire x1="-92.71" y1="106.68" x2="-86.36" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-86.36" y1="106.68" x2="-86.36" y2="109.22" width="0.1524" layer="91"/>
<wire x1="-86.36" y1="109.22" x2="-81.28" y2="109.22" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="B39"/>
<pinref part="U$18" gate="GND" pin="GND"/>
<wire x1="-92.71" y1="10.16" x2="-81.28" y2="10.16" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="B48"/>
<pinref part="U$19" gate="GND" pin="GND"/>
<wire x1="-92.71" y1="-12.7" x2="-86.36" y2="-12.7" width="0.1524" layer="91"/>
<wire x1="-86.36" y1="-12.7" x2="-86.36" y2="-10.16" width="0.1524" layer="91"/>
<wire x1="-86.36" y1="-10.16" x2="-81.28" y2="-10.16" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="B72"/>
<pinref part="U$20" gate="GND" pin="GND"/>
<wire x1="-92.71" y1="-73.66" x2="-81.28" y2="-73.66" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T1"/>
<wire x1="-125.73" y1="106.68" x2="-132.08" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-132.08" y1="106.68" x2="-132.08" y2="109.22" width="0.1524" layer="91"/>
<pinref part="U$24" gate="GND" pin="GND"/>
<wire x1="-132.08" y1="109.22" x2="-137.16" y2="109.22" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U$28" gate="GND" pin="GND"/>
<pinref part="T1" gate="A" pin="T39"/>
<wire x1="-137.16" y1="10.16" x2="-125.73" y2="10.16" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T48"/>
<wire x1="-125.73" y1="-12.7" x2="-132.08" y2="-12.7" width="0.1524" layer="91"/>
<wire x1="-132.08" y1="-12.7" x2="-132.08" y2="-10.16" width="0.1524" layer="91"/>
<pinref part="U$29" gate="GND" pin="GND"/>
<wire x1="-132.08" y1="-10.16" x2="-137.16" y2="-10.16" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T72"/>
<wire x1="-125.73" y1="-73.66" x2="-137.16" y2="-73.66" width="0.1524" layer="91"/>
<pinref part="U$30" gate="GND" pin="GND"/>
</segment>
</net>
<net name="VCC1" class="0">
<segment>
<pinref part="CN1" gate="A" pin="1"/>
<pinref part="U$4" gate="G$1" pin="VCC1"/>
<wire x1="19.05" y1="-53.34" x2="21.59" y2="-53.34" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C10" gate="A" pin="2"/>
<wire x1="-124.46" y1="-91.44" x2="-124.46" y2="-85.09" width="0.1524" layer="91"/>
<wire x1="-118.11" y1="-85.09" x2="-124.46" y2="-85.09" width="0.1524" layer="91"/>
<pinref part="U10" gate="P" pin="VCC"/>
<wire x1="-118.11" y1="-86.36" x2="-118.11" y2="-85.09" width="0.1524" layer="91"/>
<junction x="-118.11" y="-85.09"/>
<wire x1="-109.22" y1="-85.09" x2="-118.11" y2="-85.09" width="0.1524" layer="91"/>
<pinref part="C11" gate="A" pin="2"/>
<wire x1="-109.22" y1="-91.44" x2="-109.22" y2="-85.09" width="0.1524" layer="91"/>
<junction x="-109.22" y="-85.09"/>
<wire x1="-102.87" y1="-85.09" x2="-109.22" y2="-85.09" width="0.1524" layer="91"/>
<pinref part="U11" gate="P" pin="VCC"/>
<wire x1="-102.87" y1="-86.36" x2="-102.87" y2="-85.09" width="0.1524" layer="91"/>
<junction x="-102.87" y="-85.09"/>
<pinref part="U14" gate="P" pin="VCC"/>
<wire x1="-57.15" y1="-86.36" x2="-57.15" y2="-85.09" width="0.1524" layer="91"/>
<wire x1="-57.15" y1="-85.09" x2="-63.5" y2="-85.09" width="0.1524" layer="91"/>
<pinref part="C14" gate="A" pin="2"/>
<wire x1="-63.5" y1="-91.44" x2="-63.5" y2="-85.09" width="0.1524" layer="91"/>
<junction x="-63.5" y="-85.09"/>
<wire x1="-63.5" y1="-85.09" x2="-72.39" y2="-85.09" width="0.1524" layer="91"/>
<pinref part="U13" gate="P" pin="VCC"/>
<wire x1="-72.39" y1="-86.36" x2="-72.39" y2="-85.09" width="0.1524" layer="91"/>
<junction x="-72.39" y="-85.09"/>
<wire x1="-72.39" y1="-85.09" x2="-78.74" y2="-85.09" width="0.1524" layer="91"/>
<pinref part="C13" gate="A" pin="2"/>
<wire x1="-78.74" y1="-91.44" x2="-78.74" y2="-85.09" width="0.1524" layer="91"/>
<junction x="-78.74" y="-85.09"/>
<wire x1="-78.74" y1="-85.09" x2="-87.63" y2="-85.09" width="0.1524" layer="91"/>
<pinref part="U12" gate="P" pin="VCC"/>
<wire x1="-87.63" y1="-86.36" x2="-87.63" y2="-85.09" width="0.1524" layer="91"/>
<junction x="-87.63" y="-85.09"/>
<wire x1="-87.63" y1="-85.09" x2="-93.98" y2="-85.09" width="0.1524" layer="91"/>
<wire x1="-93.98" y1="-85.09" x2="-102.87" y2="-85.09" width="0.1524" layer="91"/>
<junction x="-93.98" y="-85.09"/>
<pinref part="C12" gate="A" pin="2"/>
<wire x1="-93.98" y1="-91.44" x2="-93.98" y2="-85.09" width="0.1524" layer="91"/>
<wire x1="-124.46" y1="-85.09" x2="-128.27" y2="-85.09" width="0.1524" layer="91"/>
<junction x="-124.46" y="-85.09"/>
<pinref part="U$8" gate="G$1" pin="VCC1"/>
</segment>
</net>
<net name="VCC2" class="0">
<segment>
<pinref part="CN1" gate="A" pin="5"/>
<pinref part="U$5" gate="G$1" pin="VCC2"/>
<wire x1="19.05" y1="-63.5" x2="21.59" y2="-63.5" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="RP1" gate="A" pin="1"/>
<pinref part="U$11" gate="G$1" pin="VCC2"/>
</segment>
<segment>
<pinref part="RP2" gate="A" pin="1"/>
<pinref part="U$12" gate="G$1" pin="VCC2"/>
</segment>
<segment>
<pinref part="RP3" gate="A" pin="1"/>
<pinref part="U$13" gate="G$1" pin="VCC2"/>
</segment>
<segment>
<pinref part="RP4" gate="A" pin="1"/>
<pinref part="U$14" gate="G$1" pin="VCC2"/>
</segment>
<segment>
<pinref part="RP5" gate="A" pin="1"/>
<pinref part="U$15" gate="G$1" pin="VCC2"/>
<wire x1="-68.58" y1="0" x2="-67.31" y2="0" width="0.1524" layer="91"/>
</segment>
</net>
<net name="VCC3" class="0">
<segment>
<pinref part="CN1" gate="A" pin="7"/>
<pinref part="U$6" gate="G$1" pin="VCC3"/>
<wire x1="19.05" y1="-68.58" x2="20.32" y2="-68.58" width="0.1524" layer="91"/>
<wire x1="20.32" y1="-68.58" x2="21.59" y2="-68.58" width="0.1524" layer="91"/>
<wire x1="20.32" y1="-68.58" x2="20.32" y2="-71.12" width="0.1524" layer="91"/>
<junction x="20.32" y="-68.58"/>
<pinref part="CN1" gate="A" pin="9"/>
<wire x1="20.32" y1="-71.12" x2="20.32" y2="-73.66" width="0.1524" layer="91"/>
<wire x1="20.32" y1="-73.66" x2="21.59" y2="-73.66" width="0.1524" layer="91"/>
<pinref part="CN1" gate="A" pin="8"/>
<wire x1="21.59" y1="-71.12" x2="20.32" y2="-71.12" width="0.1524" layer="91"/>
<junction x="20.32" y="-71.12"/>
</segment>
<segment>
<pinref part="C16" gate="A" pin="A"/>
<wire x1="-17.78" y1="-91.44" x2="-17.78" y2="-85.09" width="0.1524" layer="91"/>
<wire x1="-17.78" y1="-85.09" x2="-29.21" y2="-85.09" width="0.1524" layer="91"/>
<pinref part="C15" gate="A" pin="1"/>
<wire x1="-29.21" y1="-85.09" x2="-33.02" y2="-85.09" width="0.1524" layer="91"/>
<wire x1="-29.21" y1="-91.44" x2="-29.21" y2="-85.09" width="0.1524" layer="91"/>
<junction x="-29.21" y="-85.09"/>
<pinref part="U$9" gate="G$1" pin="VCC3"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="B10"/>
<pinref part="U$21" gate="G$1" pin="VCC3"/>
<wire x1="-86.36" y1="83.82" x2="-92.71" y2="83.82" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="B30"/>
<pinref part="U$22" gate="G$1" pin="VCC3"/>
<wire x1="-86.36" y1="33.02" x2="-92.71" y2="33.02" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="B59"/>
<pinref part="U$23" gate="G$1" pin="VCC3"/>
<wire x1="-86.36" y1="-40.64" x2="-92.71" y2="-40.64" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T30"/>
<pinref part="U$25" gate="G$1" pin="VCC3"/>
<wire x1="-132.08" y1="33.02" x2="-125.73" y2="33.02" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T10"/>
<pinref part="U$26" gate="G$1" pin="VCC3"/>
<wire x1="-132.08" y1="83.82" x2="-125.73" y2="83.82" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T59"/>
<pinref part="U$27" gate="G$1" pin="VCC3"/>
<wire x1="-132.08" y1="-40.64" x2="-125.73" y2="-40.64" width="0.1524" layer="91"/>
</segment>
</net>
<net name="VCC4" class="0">
<segment>
<pinref part="CN1" gate="A" pin="19"/>
<pinref part="U$7" gate="G$1" pin="VCC4"/>
<wire x1="19.05" y1="-99.06" x2="21.59" y2="-99.06" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U1" gate="P" pin="VCC"/>
<wire x1="302.26" y1="-78.74" x2="295.91" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="295.91" y1="-78.74" x2="287.02" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="287.02" y1="-78.74" x2="280.67" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="280.67" y1="-78.74" x2="271.78" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="271.78" y1="-78.74" x2="265.43" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="265.43" y1="-78.74" x2="256.54" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="256.54" y1="-78.74" x2="250.19" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="250.19" y1="-78.74" x2="241.3" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="241.3" y1="-78.74" x2="234.95" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="234.95" y1="-78.74" x2="226.06" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="226.06" y1="-78.74" x2="219.71" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="219.71" y1="-78.74" x2="210.82" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="210.82" y1="-78.74" x2="204.47" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="204.47" y1="-78.74" x2="195.58" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="195.58" y1="-78.74" x2="189.23" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="189.23" y1="-78.74" x2="180.34" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="180.34" y1="-78.74" x2="173.99" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="173.99" y1="-78.74" x2="170.18" y2="-78.74" width="0.1524" layer="91"/>
<wire x1="180.34" y1="-80.01" x2="180.34" y2="-78.74" width="0.1524" layer="91"/>
<junction x="180.34" y="-78.74"/>
<pinref part="C1" gate="A" pin="2"/>
<wire x1="173.99" y1="-85.09" x2="173.99" y2="-78.74" width="0.1524" layer="91"/>
<junction x="173.99" y="-78.74"/>
<pinref part="C2" gate="A" pin="2"/>
<wire x1="189.23" y1="-85.09" x2="189.23" y2="-78.74" width="0.1524" layer="91"/>
<junction x="189.23" y="-78.74"/>
<pinref part="U2" gate="P" pin="VCC"/>
<wire x1="195.58" y1="-80.01" x2="195.58" y2="-78.74" width="0.1524" layer="91"/>
<junction x="195.58" y="-78.74"/>
<pinref part="C3" gate="A" pin="2"/>
<wire x1="204.47" y1="-85.09" x2="204.47" y2="-78.74" width="0.1524" layer="91"/>
<junction x="204.47" y="-78.74"/>
<pinref part="U3" gate="P" pin="VCC"/>
<wire x1="210.82" y1="-80.01" x2="210.82" y2="-78.74" width="0.1524" layer="91"/>
<junction x="210.82" y="-78.74"/>
<pinref part="C4" gate="A" pin="2"/>
<wire x1="219.71" y1="-85.09" x2="219.71" y2="-78.74" width="0.1524" layer="91"/>
<junction x="219.71" y="-78.74"/>
<pinref part="U4" gate="P" pin="VCC"/>
<wire x1="226.06" y1="-80.01" x2="226.06" y2="-78.74" width="0.1524" layer="91"/>
<junction x="226.06" y="-78.74"/>
<pinref part="C5" gate="A" pin="2"/>
<wire x1="234.95" y1="-85.09" x2="234.95" y2="-78.74" width="0.1524" layer="91"/>
<junction x="234.95" y="-78.74"/>
<pinref part="U5" gate="P" pin="VCC"/>
<wire x1="241.3" y1="-80.01" x2="241.3" y2="-78.74" width="0.1524" layer="91"/>
<junction x="241.3" y="-78.74"/>
<pinref part="U6" gate="P" pin="VCC"/>
<wire x1="256.54" y1="-80.01" x2="256.54" y2="-78.74" width="0.1524" layer="91"/>
<junction x="256.54" y="-78.74"/>
<pinref part="C7" gate="A" pin="2"/>
<wire x1="265.43" y1="-85.09" x2="265.43" y2="-78.74" width="0.1524" layer="91"/>
<junction x="265.43" y="-78.74"/>
<pinref part="U7" gate="P" pin="VCC"/>
<wire x1="271.78" y1="-80.01" x2="271.78" y2="-78.74" width="0.1524" layer="91"/>
<junction x="271.78" y="-78.74"/>
<pinref part="C8" gate="A" pin="2"/>
<wire x1="280.67" y1="-85.09" x2="280.67" y2="-78.74" width="0.1524" layer="91"/>
<junction x="280.67" y="-78.74"/>
<pinref part="U8" gate="P" pin="VCC"/>
<wire x1="287.02" y1="-80.01" x2="287.02" y2="-78.74" width="0.1524" layer="91"/>
<junction x="287.02" y="-78.74"/>
<pinref part="C9" gate="A" pin="2"/>
<wire x1="295.91" y1="-85.09" x2="295.91" y2="-78.74" width="0.1524" layer="91"/>
<junction x="295.91" y="-78.74"/>
<pinref part="U9" gate="P" pin="VCC"/>
<wire x1="302.26" y1="-80.01" x2="302.26" y2="-78.74" width="0.1524" layer="91"/>
<pinref part="C6" gate="A" pin="2"/>
<wire x1="250.19" y1="-85.09" x2="250.19" y2="-78.74" width="0.1524" layer="91"/>
<junction x="250.19" y="-78.74"/>
<pinref part="U$10" gate="G$1" pin="VCC4"/>
</segment>
</net>
<net name="!CAS0123" class="0">
<segment>
<pinref part="T1" gate="A" pin="B43"/>
<wire x1="-92.71" y1="0" x2="-88.9" y2="0" width="0.1524" layer="91"/>
<pinref part="T1" gate="A" pin="B40"/>
<wire x1="-92.71" y1="7.62" x2="-88.9" y2="7.62" width="0.1524" layer="91"/>
<wire x1="-88.9" y1="7.62" x2="-88.9" y2="5.08" width="0.1524" layer="91"/>
<pinref part="T1" gate="A" pin="B41"/>
<wire x1="-88.9" y1="5.08" x2="-88.9" y2="2.54" width="0.1524" layer="91"/>
<wire x1="-88.9" y1="2.54" x2="-88.9" y2="0" width="0.1524" layer="91"/>
<wire x1="-92.71" y1="5.08" x2="-88.9" y2="5.08" width="0.1524" layer="91"/>
<junction x="-88.9" y="5.08"/>
<pinref part="T1" gate="A" pin="B42"/>
<wire x1="-92.71" y1="2.54" x2="-88.9" y2="2.54" width="0.1524" layer="91"/>
<junction x="-88.9" y="2.54"/>
<label x="-6.35" y="-4.826" size="1.524" layer="95" rot="MR0"/>
<wire x1="-88.9" y1="0" x2="-88.9" y2="-5.08" width="0.1524" layer="91"/>
<wire x1="-88.9" y1="-5.08" x2="-5.08" y2="-5.08" width="0.1524" layer="91"/>
<junction x="-88.9" y="0"/>
<wire x1="-3.81" y1="-3.81" x2="-5.08" y2="-5.08" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T40"/>
<wire x1="-125.73" y1="7.62" x2="-129.54" y2="7.62" width="0.1524" layer="91"/>
<wire x1="-129.54" y1="7.62" x2="-129.54" y2="5.08" width="0.1524" layer="91"/>
<pinref part="T1" gate="A" pin="T43"/>
<wire x1="-129.54" y1="5.08" x2="-129.54" y2="2.54" width="0.1524" layer="91"/>
<wire x1="-129.54" y1="2.54" x2="-129.54" y2="0" width="0.1524" layer="91"/>
<wire x1="-129.54" y1="0" x2="-125.73" y2="0" width="0.1524" layer="91"/>
<pinref part="T1" gate="A" pin="T41"/>
<wire x1="-125.73" y1="5.08" x2="-129.54" y2="5.08" width="0.1524" layer="91"/>
<junction x="-129.54" y="5.08"/>
<pinref part="T1" gate="A" pin="T42"/>
<wire x1="-125.73" y1="2.54" x2="-129.54" y2="2.54" width="0.1524" layer="91"/>
<junction x="-129.54" y="2.54"/>
<label x="-144.78" y="-4.826" size="1.524" layer="95"/>
<wire x1="-129.54" y1="0" x2="-129.54" y2="-5.08" width="0.1524" layer="91"/>
<wire x1="-129.54" y1="-5.08" x2="-146.05" y2="-5.08" width="0.1524" layer="91"/>
<junction x="-129.54" y="0"/>
</segment>
<segment>
<pinref part="CN1" gate="A" pin="10"/>
<wire x1="21.59" y1="-76.2" x2="-2.54" y2="-76.2" width="0.1524" layer="91"/>
<label x="-1.27" y="-75.946" size="1.524" layer="95"/>
<wire x1="-3.81" y1="-74.93" x2="-2.54" y2="-76.2" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D0" class="0">
<segment>
<pinref part="T1" gate="A" pin="B2"/>
<label x="-6.35" y="104.394" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP1" gate="A" pin="2"/>
<wire x1="-92.71" y1="104.14" x2="-66.04" y2="104.14" width="0.1524" layer="91"/>
<wire x1="-66.04" y1="104.14" x2="-66.04" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-66.04" y1="104.14" x2="-5.08" y2="104.14" width="0.1524" layer="91"/>
<junction x="-66.04" y="104.14"/>
<wire x1="-3.81" y1="105.41" x2="-5.08" y2="104.14" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T2"/>
<wire x1="-125.73" y1="104.14" x2="-146.05" y2="104.14" width="0.1524" layer="91"/>
<label x="-144.78" y="104.394" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U5" gate="A1" pin="Y"/>
<wire x1="50.8" y1="88.9" x2="53.34" y2="88.9" width="0.1524" layer="91"/>
<pinref part="U1" gate="A1" pin="A"/>
<wire x1="50.8" y1="111.76" x2="53.34" y2="111.76" width="0.1524" layer="91"/>
<wire x1="53.34" y1="111.76" x2="53.34" y2="88.9" width="0.1524" layer="91"/>
<wire x1="53.34" y1="88.9" x2="72.39" y2="88.9" width="0.1524" layer="91"/>
<junction x="53.34" y="88.9"/>
<label x="71.12" y="89.154" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="90.17" x2="72.39" y2="88.9" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D16" class="0">
<segment>
<pinref part="T1" gate="A" pin="B3"/>
<label x="-6.35" y="101.854" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP3" gate="A" pin="2"/>
<wire x1="-92.71" y1="101.6" x2="-35.56" y2="101.6" width="0.1524" layer="91"/>
<wire x1="-35.56" y1="101.6" x2="-35.56" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-35.56" y1="101.6" x2="-5.08" y2="101.6" width="0.1524" layer="91"/>
<junction x="-35.56" y="101.6"/>
<wire x1="-3.81" y1="102.87" x2="-5.08" y2="101.6" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T3"/>
<wire x1="-125.73" y1="101.6" x2="-146.05" y2="101.6" width="0.1524" layer="91"/>
<label x="-144.78" y="101.854" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U7" gate="A1" pin="Y"/>
<wire x1="208.28" y1="88.9" x2="210.82" y2="88.9" width="0.1524" layer="91"/>
<pinref part="U3" gate="A1" pin="A"/>
<wire x1="210.82" y1="88.9" x2="229.87" y2="88.9" width="0.1524" layer="91"/>
<wire x1="208.28" y1="111.76" x2="210.82" y2="111.76" width="0.1524" layer="91"/>
<wire x1="210.82" y1="111.76" x2="210.82" y2="88.9" width="0.1524" layer="91"/>
<junction x="210.82" y="88.9"/>
<label x="228.6" y="89.154" size="1.524" layer="95" rot="MR0"/>
<wire x1="231.14" y1="90.17" x2="229.87" y2="88.9" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D1" class="0">
<segment>
<pinref part="T1" gate="A" pin="B4"/>
<label x="-6.35" y="99.314" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP1" gate="A" pin="3"/>
<wire x1="-92.71" y1="99.06" x2="-63.5" y2="99.06" width="0.1524" layer="91"/>
<wire x1="-63.5" y1="99.06" x2="-63.5" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-63.5" y1="99.06" x2="-5.08" y2="99.06" width="0.1524" layer="91"/>
<junction x="-63.5" y="99.06"/>
<wire x1="-3.81" y1="100.33" x2="-5.08" y2="99.06" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T4"/>
<wire x1="-125.73" y1="99.06" x2="-146.05" y2="99.06" width="0.1524" layer="91"/>
<label x="-144.78" y="99.314" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U1" gate="A2" pin="A"/>
<wire x1="50.8" y1="109.22" x2="55.88" y2="109.22" width="0.1524" layer="91"/>
<wire x1="55.88" y1="109.22" x2="55.88" y2="86.36" width="0.1524" layer="91"/>
<pinref part="U5" gate="A2" pin="Y"/>
<wire x1="55.88" y1="86.36" x2="50.8" y2="86.36" width="0.1524" layer="91"/>
<wire x1="55.88" y1="86.36" x2="72.39" y2="86.36" width="0.1524" layer="91"/>
<junction x="55.88" y="86.36"/>
<label x="71.12" y="86.614" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="87.63" x2="72.39" y2="86.36" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D17" class="0">
<segment>
<pinref part="T1" gate="A" pin="B5"/>
<label x="-6.35" y="96.774" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP3" gate="A" pin="3"/>
<wire x1="-92.71" y1="96.52" x2="-33.02" y2="96.52" width="0.1524" layer="91"/>
<wire x1="-33.02" y1="96.52" x2="-33.02" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-33.02" y1="96.52" x2="-5.08" y2="96.52" width="0.1524" layer="91"/>
<junction x="-33.02" y="96.52"/>
<wire x1="-3.81" y1="97.79" x2="-5.08" y2="96.52" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T5"/>
<wire x1="-125.73" y1="96.52" x2="-146.05" y2="96.52" width="0.1524" layer="91"/>
<label x="-144.78" y="96.774" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U7" gate="A2" pin="Y"/>
<wire x1="208.28" y1="86.36" x2="213.36" y2="86.36" width="0.1524" layer="91"/>
<pinref part="U3" gate="A2" pin="A"/>
<wire x1="213.36" y1="86.36" x2="229.87" y2="86.36" width="0.1524" layer="91"/>
<wire x1="208.28" y1="109.22" x2="213.36" y2="109.22" width="0.1524" layer="91"/>
<wire x1="213.36" y1="109.22" x2="213.36" y2="86.36" width="0.1524" layer="91"/>
<junction x="213.36" y="86.36"/>
<label x="228.6" y="86.614" size="1.524" layer="95" rot="MR0"/>
<wire x1="231.14" y1="87.63" x2="229.87" y2="86.36" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D2" class="0">
<segment>
<pinref part="T1" gate="A" pin="B6"/>
<label x="-6.35" y="94.234" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP1" gate="A" pin="4"/>
<wire x1="-92.71" y1="93.98" x2="-60.96" y2="93.98" width="0.1524" layer="91"/>
<wire x1="-60.96" y1="93.98" x2="-60.96" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-60.96" y1="93.98" x2="-5.08" y2="93.98" width="0.1524" layer="91"/>
<junction x="-60.96" y="93.98"/>
<wire x1="-3.81" y1="95.25" x2="-5.08" y2="93.98" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T6"/>
<wire x1="-125.73" y1="93.98" x2="-146.05" y2="93.98" width="0.1524" layer="91"/>
<label x="-144.78" y="94.234" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U1" gate="A3" pin="A"/>
<wire x1="50.8" y1="106.68" x2="58.42" y2="106.68" width="0.1524" layer="91"/>
<wire x1="58.42" y1="106.68" x2="58.42" y2="83.82" width="0.1524" layer="91"/>
<pinref part="U5" gate="A3" pin="Y"/>
<wire x1="58.42" y1="83.82" x2="50.8" y2="83.82" width="0.1524" layer="91"/>
<wire x1="58.42" y1="83.82" x2="72.39" y2="83.82" width="0.1524" layer="91"/>
<junction x="58.42" y="83.82"/>
<label x="71.12" y="84.074" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="85.09" x2="72.39" y2="83.82" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D18" class="0">
<segment>
<pinref part="T1" gate="A" pin="B7"/>
<label x="-6.35" y="91.694" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP3" gate="A" pin="4"/>
<wire x1="-92.71" y1="91.44" x2="-30.48" y2="91.44" width="0.1524" layer="91"/>
<wire x1="-30.48" y1="91.44" x2="-30.48" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-30.48" y1="91.44" x2="-5.08" y2="91.44" width="0.1524" layer="91"/>
<junction x="-30.48" y="91.44"/>
<wire x1="-3.81" y1="92.71" x2="-5.08" y2="91.44" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T7"/>
<wire x1="-125.73" y1="91.44" x2="-146.05" y2="91.44" width="0.1524" layer="91"/>
<label x="-144.78" y="91.694" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U7" gate="A3" pin="Y"/>
<wire x1="208.28" y1="83.82" x2="215.9" y2="83.82" width="0.1524" layer="91"/>
<label x="228.6" y="84.074" size="1.524" layer="95" rot="MR0"/>
<pinref part="U3" gate="A3" pin="A"/>
<wire x1="215.9" y1="83.82" x2="229.87" y2="83.82" width="0.1524" layer="91"/>
<wire x1="208.28" y1="106.68" x2="215.9" y2="106.68" width="0.1524" layer="91"/>
<wire x1="215.9" y1="106.68" x2="215.9" y2="83.82" width="0.1524" layer="91"/>
<junction x="215.9" y="83.82"/>
<wire x1="231.14" y1="85.09" x2="229.87" y2="83.82" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D3" class="0">
<segment>
<pinref part="T1" gate="A" pin="B8"/>
<label x="-6.35" y="89.154" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP1" gate="A" pin="5"/>
<wire x1="-92.71" y1="88.9" x2="-58.42" y2="88.9" width="0.1524" layer="91"/>
<wire x1="-58.42" y1="88.9" x2="-58.42" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-58.42" y1="88.9" x2="-5.08" y2="88.9" width="0.1524" layer="91"/>
<junction x="-58.42" y="88.9"/>
<wire x1="-3.81" y1="90.17" x2="-5.08" y2="88.9" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T8"/>
<wire x1="-125.73" y1="88.9" x2="-146.05" y2="88.9" width="0.1524" layer="91"/>
<label x="-144.78" y="89.154" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U1" gate="A4" pin="A"/>
<wire x1="50.8" y1="104.14" x2="60.96" y2="104.14" width="0.1524" layer="91"/>
<wire x1="60.96" y1="104.14" x2="60.96" y2="81.28" width="0.1524" layer="91"/>
<pinref part="U5" gate="A4" pin="Y"/>
<wire x1="60.96" y1="81.28" x2="50.8" y2="81.28" width="0.1524" layer="91"/>
<wire x1="60.96" y1="81.28" x2="72.39" y2="81.28" width="0.1524" layer="91"/>
<junction x="60.96" y="81.28"/>
<label x="71.12" y="81.534" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="82.55" x2="72.39" y2="81.28" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D19" class="0">
<segment>
<pinref part="T1" gate="A" pin="B9"/>
<label x="-6.35" y="86.614" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP3" gate="A" pin="5"/>
<wire x1="-92.71" y1="86.36" x2="-27.94" y2="86.36" width="0.1524" layer="91"/>
<wire x1="-27.94" y1="86.36" x2="-27.94" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-27.94" y1="86.36" x2="-5.08" y2="86.36" width="0.1524" layer="91"/>
<junction x="-27.94" y="86.36"/>
<wire x1="-3.81" y1="87.63" x2="-5.08" y2="86.36" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T9"/>
<wire x1="-125.73" y1="86.36" x2="-146.05" y2="86.36" width="0.1524" layer="91"/>
<label x="-144.78" y="86.614" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U7" gate="A4" pin="Y"/>
<wire x1="208.28" y1="81.28" x2="218.44" y2="81.28" width="0.1524" layer="91"/>
<label x="228.6" y="81.534" size="1.524" layer="95" rot="MR0"/>
<pinref part="U3" gate="A4" pin="A"/>
<wire x1="218.44" y1="81.28" x2="229.87" y2="81.28" width="0.1524" layer="91"/>
<wire x1="208.28" y1="104.14" x2="218.44" y2="104.14" width="0.1524" layer="91"/>
<wire x1="218.44" y1="104.14" x2="218.44" y2="81.28" width="0.1524" layer="91"/>
<junction x="218.44" y="81.28"/>
<wire x1="231.14" y1="82.55" x2="229.87" y2="81.28" width="0.1524" layer="91"/>
</segment>
</net>
<net name="A0" class="0">
<segment>
<pinref part="T1" gate="A" pin="B12"/>
<wire x1="-92.71" y1="78.74" x2="-5.08" y2="78.74" width="0.1524" layer="91"/>
<label x="-6.35" y="78.994" size="1.524" layer="95" rot="MR0"/>
<wire x1="-3.81" y1="80.01" x2="-5.08" y2="78.74" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T12"/>
<wire x1="-125.73" y1="78.74" x2="-146.05" y2="78.74" width="0.1524" layer="91"/>
<label x="-144.78" y="78.994" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U10" gate="A1" pin="Y"/>
<wire x1="129.54" y1="8.89" x2="151.13" y2="8.89" width="0.1524" layer="91"/>
<label x="149.86" y="9.144" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="10.16" x2="151.13" y2="8.89" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U12" gate="A1" pin="Y"/>
<wire x1="287.02" y1="8.89" x2="304.8" y2="8.89" width="0.1524" layer="91"/>
<label x="303.53" y="8.89" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="10.16" x2="304.8" y2="8.89" width="0.1524" layer="91"/>
</segment>
</net>
<net name="A1" class="0">
<segment>
<pinref part="T1" gate="A" pin="B13"/>
<wire x1="-92.71" y1="76.2" x2="-5.08" y2="76.2" width="0.1524" layer="91"/>
<label x="-6.35" y="76.454" size="1.524" layer="95" rot="MR0"/>
<wire x1="-3.81" y1="77.47" x2="-5.08" y2="76.2" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T13"/>
<wire x1="-125.73" y1="76.2" x2="-146.05" y2="76.2" width="0.1524" layer="91"/>
<label x="-144.78" y="76.454" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U10" gate="A2" pin="Y"/>
<wire x1="129.54" y1="6.35" x2="151.13" y2="6.35" width="0.1524" layer="91"/>
<label x="149.86" y="6.604" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="7.62" x2="151.13" y2="6.35" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U12" gate="A2" pin="Y"/>
<wire x1="287.02" y1="6.35" x2="304.8" y2="6.35" width="0.1524" layer="91"/>
<label x="303.53" y="6.35" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="7.62" x2="304.8" y2="6.35" width="0.1524" layer="91"/>
</segment>
</net>
<net name="A2" class="0">
<segment>
<pinref part="T1" gate="A" pin="B14"/>
<wire x1="-92.71" y1="73.66" x2="-5.08" y2="73.66" width="0.1524" layer="91"/>
<label x="-6.35" y="73.914" size="1.524" layer="95" rot="MR0"/>
<wire x1="-3.81" y1="74.93" x2="-5.08" y2="73.66" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T14"/>
<wire x1="-125.73" y1="73.66" x2="-146.05" y2="73.66" width="0.1524" layer="91"/>
<label x="-144.78" y="73.914" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U10" gate="A3" pin="Y"/>
<wire x1="129.54" y1="3.81" x2="151.13" y2="3.81" width="0.1524" layer="91"/>
<label x="149.86" y="4.064" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="5.08" x2="151.13" y2="3.81" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U12" gate="A3" pin="Y"/>
<wire x1="287.02" y1="3.81" x2="304.8" y2="3.81" width="0.1524" layer="91"/>
<label x="303.53" y="3.81" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="5.08" x2="304.8" y2="3.81" width="0.1524" layer="91"/>
</segment>
</net>
<net name="A3" class="0">
<segment>
<pinref part="T1" gate="A" pin="B15"/>
<wire x1="-92.71" y1="71.12" x2="-5.08" y2="71.12" width="0.1524" layer="91"/>
<label x="-6.35" y="71.374" size="1.524" layer="95" rot="MR0"/>
<wire x1="-3.81" y1="72.39" x2="-5.08" y2="71.12" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T15"/>
<wire x1="-125.73" y1="71.12" x2="-146.05" y2="71.12" width="0.1524" layer="91"/>
<label x="-144.78" y="71.374" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U10" gate="A4" pin="Y"/>
<wire x1="129.54" y1="1.27" x2="151.13" y2="1.27" width="0.1524" layer="91"/>
<label x="149.86" y="1.524" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="2.54" x2="151.13" y2="1.27" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U12" gate="A4" pin="Y"/>
<wire x1="287.02" y1="1.27" x2="304.8" y2="1.27" width="0.1524" layer="91"/>
<label x="303.53" y="1.27" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="2.54" x2="304.8" y2="1.27" width="0.1524" layer="91"/>
</segment>
</net>
<net name="A4" class="0">
<segment>
<pinref part="T1" gate="A" pin="B16"/>
<wire x1="-92.71" y1="68.58" x2="-5.08" y2="68.58" width="0.1524" layer="91"/>
<label x="-6.35" y="68.834" size="1.524" layer="95" rot="MR0"/>
<wire x1="-3.81" y1="69.85" x2="-5.08" y2="68.58" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T16"/>
<wire x1="-125.73" y1="68.58" x2="-146.05" y2="68.58" width="0.1524" layer="91"/>
<label x="-144.78" y="68.834" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U10" gate="B1" pin="Y"/>
<wire x1="129.54" y1="-13.97" x2="151.13" y2="-13.97" width="0.1524" layer="91"/>
<label x="149.86" y="-13.716" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="-12.7" x2="151.13" y2="-13.97" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U12" gate="B1" pin="Y"/>
<wire x1="287.02" y1="-13.97" x2="304.8" y2="-13.97" width="0.1524" layer="91"/>
<label x="303.53" y="-13.97" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="-12.7" x2="304.8" y2="-13.97" width="0.1524" layer="91"/>
</segment>
</net>
<net name="A5" class="0">
<segment>
<pinref part="T1" gate="A" pin="B17"/>
<wire x1="-92.71" y1="66.04" x2="-5.08" y2="66.04" width="0.1524" layer="91"/>
<label x="-6.35" y="66.294" size="1.524" layer="95" rot="MR0"/>
<wire x1="-3.81" y1="67.31" x2="-5.08" y2="66.04" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T17"/>
<wire x1="-125.73" y1="66.04" x2="-146.05" y2="66.04" width="0.1524" layer="91"/>
<label x="-144.78" y="66.294" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U10" gate="B2" pin="Y"/>
<wire x1="129.54" y1="-16.51" x2="151.13" y2="-16.51" width="0.1524" layer="91"/>
<label x="149.86" y="-16.256" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="-15.24" x2="151.13" y2="-16.51" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U12" gate="B2" pin="Y"/>
<wire x1="287.02" y1="-16.51" x2="304.8" y2="-16.51" width="0.1524" layer="91"/>
<label x="303.53" y="-16.51" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="-15.24" x2="304.8" y2="-16.51" width="0.1524" layer="91"/>
</segment>
</net>
<net name="A6" class="0">
<segment>
<pinref part="T1" gate="A" pin="B18"/>
<wire x1="-92.71" y1="63.5" x2="-5.08" y2="63.5" width="0.1524" layer="91"/>
<label x="-6.35" y="63.754" size="1.524" layer="95" rot="MR0"/>
<wire x1="-3.81" y1="64.77" x2="-5.08" y2="63.5" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T18"/>
<wire x1="-125.73" y1="63.5" x2="-146.05" y2="63.5" width="0.1524" layer="91"/>
<label x="-144.78" y="63.754" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U10" gate="B3" pin="Y"/>
<wire x1="129.54" y1="-19.05" x2="151.13" y2="-19.05" width="0.1524" layer="91"/>
<label x="149.86" y="-18.796" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="-17.78" x2="151.13" y2="-19.05" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U12" gate="B3" pin="Y"/>
<wire x1="287.02" y1="-19.05" x2="304.8" y2="-19.05" width="0.1524" layer="91"/>
<label x="303.53" y="-19.05" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="-17.78" x2="304.8" y2="-19.05" width="0.1524" layer="91"/>
</segment>
</net>
<net name="A10" class="0">
<segment>
<pinref part="T1" gate="A" pin="B19"/>
<wire x1="-92.71" y1="60.96" x2="-5.08" y2="60.96" width="0.1524" layer="91"/>
<label x="-6.35" y="61.214" size="1.524" layer="95" rot="MR0"/>
<wire x1="-3.81" y1="62.23" x2="-5.08" y2="60.96" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T19"/>
<wire x1="-125.73" y1="60.96" x2="-146.05" y2="60.96" width="0.1524" layer="91"/>
<label x="-144.78" y="61.214" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U11" gate="A3" pin="Y"/>
<wire x1="129.54" y1="-41.91" x2="151.13" y2="-41.91" width="0.1524" layer="91"/>
<label x="149.86" y="-41.656" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="-40.64" x2="151.13" y2="-41.91" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U11" gate="B3" pin="Y"/>
<wire x1="287.02" y1="-41.91" x2="304.8" y2="-41.91" width="0.1524" layer="91"/>
<label x="303.53" y="-41.91" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="-40.64" x2="304.8" y2="-41.91" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D4" class="0">
<segment>
<pinref part="T1" gate="A" pin="B20"/>
<label x="-6.35" y="58.674" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP1" gate="A" pin="6"/>
<wire x1="-92.71" y1="58.42" x2="-55.88" y2="58.42" width="0.1524" layer="91"/>
<wire x1="-55.88" y1="58.42" x2="-55.88" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-55.88" y1="58.42" x2="-5.08" y2="58.42" width="0.1524" layer="91"/>
<junction x="-55.88" y="58.42"/>
<wire x1="-3.81" y1="59.69" x2="-5.08" y2="58.42" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T20"/>
<wire x1="-125.73" y1="58.42" x2="-146.05" y2="58.42" width="0.1524" layer="91"/>
<label x="-144.78" y="58.674" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U5" gate="B1" pin="Y"/>
<wire x1="50.8" y1="36.83" x2="53.34" y2="36.83" width="0.1524" layer="91"/>
<label x="71.12" y="37.084" size="1.524" layer="95" rot="MR0"/>
<pinref part="U1" gate="B1" pin="A"/>
<wire x1="53.34" y1="36.83" x2="72.39" y2="36.83" width="0.1524" layer="91"/>
<wire x1="50.8" y1="59.69" x2="53.34" y2="59.69" width="0.1524" layer="91"/>
<wire x1="53.34" y1="59.69" x2="53.34" y2="36.83" width="0.1524" layer="91"/>
<junction x="53.34" y="36.83"/>
<wire x1="73.66" y1="38.1" x2="72.39" y2="36.83" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D20" class="0">
<segment>
<pinref part="T1" gate="A" pin="B21"/>
<label x="-6.35" y="56.134" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP3" gate="A" pin="6"/>
<wire x1="-92.71" y1="55.88" x2="-25.4" y2="55.88" width="0.1524" layer="91"/>
<wire x1="-25.4" y1="55.88" x2="-25.4" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-25.4" y1="55.88" x2="-5.08" y2="55.88" width="0.1524" layer="91"/>
<junction x="-25.4" y="55.88"/>
<wire x1="-3.81" y1="57.15" x2="-5.08" y2="55.88" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T21"/>
<wire x1="-125.73" y1="55.88" x2="-146.05" y2="55.88" width="0.1524" layer="91"/>
<label x="-144.78" y="56.134" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U7" gate="B1" pin="Y"/>
<wire x1="208.28" y1="36.83" x2="210.82" y2="36.83" width="0.1524" layer="91"/>
<pinref part="U3" gate="B1" pin="A"/>
<wire x1="210.82" y1="36.83" x2="229.87" y2="36.83" width="0.1524" layer="91"/>
<wire x1="208.28" y1="59.69" x2="210.82" y2="59.69" width="0.1524" layer="91"/>
<wire x1="210.82" y1="59.69" x2="210.82" y2="36.83" width="0.1524" layer="91"/>
<junction x="210.82" y="36.83"/>
<label x="228.6" y="37.084" size="1.524" layer="95" rot="MR0"/>
<wire x1="231.14" y1="38.1" x2="229.87" y2="36.83" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D5" class="0">
<segment>
<pinref part="T1" gate="A" pin="B22"/>
<label x="-6.35" y="53.594" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP1" gate="A" pin="7"/>
<wire x1="-92.71" y1="53.34" x2="-53.34" y2="53.34" width="0.1524" layer="91"/>
<wire x1="-53.34" y1="53.34" x2="-53.34" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-53.34" y1="53.34" x2="-5.08" y2="53.34" width="0.1524" layer="91"/>
<junction x="-53.34" y="53.34"/>
<wire x1="-3.81" y1="54.61" x2="-5.08" y2="53.34" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T22"/>
<wire x1="-125.73" y1="53.34" x2="-146.05" y2="53.34" width="0.1524" layer="91"/>
<label x="-144.78" y="53.594" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U5" gate="B2" pin="Y"/>
<wire x1="50.8" y1="34.29" x2="55.88" y2="34.29" width="0.1524" layer="91"/>
<label x="71.12" y="34.544" size="1.524" layer="95" rot="MR0"/>
<pinref part="U1" gate="B2" pin="A"/>
<wire x1="55.88" y1="34.29" x2="72.39" y2="34.29" width="0.1524" layer="91"/>
<wire x1="50.8" y1="57.15" x2="55.88" y2="57.15" width="0.1524" layer="91"/>
<wire x1="55.88" y1="57.15" x2="55.88" y2="34.29" width="0.1524" layer="91"/>
<junction x="55.88" y="34.29"/>
<wire x1="73.66" y1="35.56" x2="72.39" y2="34.29" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D21" class="0">
<segment>
<pinref part="T1" gate="A" pin="B23"/>
<label x="-6.35" y="51.054" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP3" gate="A" pin="7"/>
<wire x1="-92.71" y1="50.8" x2="-22.86" y2="50.8" width="0.1524" layer="91"/>
<wire x1="-22.86" y1="50.8" x2="-22.86" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-22.86" y1="50.8" x2="-5.08" y2="50.8" width="0.1524" layer="91"/>
<junction x="-22.86" y="50.8"/>
<wire x1="-3.81" y1="52.07" x2="-5.08" y2="50.8" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T23"/>
<wire x1="-125.73" y1="50.8" x2="-146.05" y2="50.8" width="0.1524" layer="91"/>
<label x="-144.78" y="51.054" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U7" gate="B2" pin="Y"/>
<wire x1="208.28" y1="34.29" x2="213.36" y2="34.29" width="0.1524" layer="91"/>
<pinref part="U3" gate="B2" pin="A"/>
<wire x1="213.36" y1="34.29" x2="229.87" y2="34.29" width="0.1524" layer="91"/>
<wire x1="208.28" y1="57.15" x2="213.36" y2="57.15" width="0.1524" layer="91"/>
<wire x1="213.36" y1="57.15" x2="213.36" y2="34.29" width="0.1524" layer="91"/>
<junction x="213.36" y="34.29"/>
<label x="228.6" y="34.544" size="1.524" layer="95" rot="MR0"/>
<wire x1="231.14" y1="35.56" x2="229.87" y2="34.29" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D6" class="0">
<segment>
<pinref part="T1" gate="A" pin="B24"/>
<label x="-6.35" y="48.514" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP1" gate="A" pin="8"/>
<wire x1="-92.71" y1="48.26" x2="-50.8" y2="48.26" width="0.1524" layer="91"/>
<wire x1="-50.8" y1="48.26" x2="-50.8" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-50.8" y1="48.26" x2="-5.08" y2="48.26" width="0.1524" layer="91"/>
<junction x="-50.8" y="48.26"/>
<wire x1="-3.81" y1="49.53" x2="-5.08" y2="48.26" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T24"/>
<wire x1="-125.73" y1="48.26" x2="-146.05" y2="48.26" width="0.1524" layer="91"/>
<label x="-144.78" y="48.514" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U5" gate="B3" pin="Y"/>
<wire x1="50.8" y1="31.75" x2="58.42" y2="31.75" width="0.1524" layer="91"/>
<label x="71.12" y="32.004" size="1.524" layer="95" rot="MR0"/>
<pinref part="U1" gate="B3" pin="A"/>
<wire x1="58.42" y1="31.75" x2="72.39" y2="31.75" width="0.1524" layer="91"/>
<wire x1="50.8" y1="54.61" x2="58.42" y2="54.61" width="0.1524" layer="91"/>
<wire x1="58.42" y1="54.61" x2="58.42" y2="31.75" width="0.1524" layer="91"/>
<junction x="58.42" y="31.75"/>
<wire x1="73.66" y1="33.02" x2="72.39" y2="31.75" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D22" class="0">
<segment>
<pinref part="T1" gate="A" pin="B25"/>
<label x="-6.35" y="45.974" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP3" gate="A" pin="8"/>
<wire x1="-92.71" y1="45.72" x2="-20.32" y2="45.72" width="0.1524" layer="91"/>
<wire x1="-20.32" y1="45.72" x2="-20.32" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-20.32" y1="45.72" x2="-5.08" y2="45.72" width="0.1524" layer="91"/>
<junction x="-20.32" y="45.72"/>
<wire x1="-3.81" y1="46.99" x2="-5.08" y2="45.72" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T25"/>
<wire x1="-125.73" y1="45.72" x2="-146.05" y2="45.72" width="0.1524" layer="91"/>
<label x="-144.78" y="45.974" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U7" gate="B3" pin="Y"/>
<wire x1="208.28" y1="31.75" x2="215.9" y2="31.75" width="0.1524" layer="91"/>
<pinref part="U3" gate="B3" pin="A"/>
<wire x1="215.9" y1="31.75" x2="229.87" y2="31.75" width="0.1524" layer="91"/>
<wire x1="208.28" y1="54.61" x2="215.9" y2="54.61" width="0.1524" layer="91"/>
<wire x1="215.9" y1="54.61" x2="215.9" y2="31.75" width="0.1524" layer="91"/>
<junction x="215.9" y="31.75"/>
<label x="228.6" y="32.004" size="1.524" layer="95" rot="MR0"/>
<wire x1="231.14" y1="33.02" x2="229.87" y2="31.75" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D7" class="0">
<segment>
<pinref part="T1" gate="A" pin="B26"/>
<label x="-6.35" y="43.434" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP1" gate="A" pin="9"/>
<wire x1="-92.71" y1="43.18" x2="-48.26" y2="43.18" width="0.1524" layer="91"/>
<wire x1="-48.26" y1="43.18" x2="-48.26" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-48.26" y1="43.18" x2="-5.08" y2="43.18" width="0.1524" layer="91"/>
<junction x="-48.26" y="43.18"/>
<wire x1="-3.81" y1="44.45" x2="-5.08" y2="43.18" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T26"/>
<wire x1="-125.73" y1="43.18" x2="-146.05" y2="43.18" width="0.1524" layer="91"/>
<label x="-144.78" y="43.434" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U5" gate="B4" pin="Y"/>
<wire x1="50.8" y1="29.21" x2="60.96" y2="29.21" width="0.1524" layer="91"/>
<label x="71.12" y="29.464" size="1.524" layer="95" rot="MR0"/>
<pinref part="U1" gate="B4" pin="A"/>
<wire x1="60.96" y1="29.21" x2="72.39" y2="29.21" width="0.1524" layer="91"/>
<wire x1="50.8" y1="52.07" x2="60.96" y2="52.07" width="0.1524" layer="91"/>
<wire x1="60.96" y1="52.07" x2="60.96" y2="29.21" width="0.1524" layer="91"/>
<junction x="60.96" y="29.21"/>
<wire x1="73.66" y1="30.48" x2="72.39" y2="29.21" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D23" class="0">
<segment>
<pinref part="T1" gate="A" pin="B27"/>
<label x="-6.35" y="40.894" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP3" gate="A" pin="9"/>
<wire x1="-92.71" y1="40.64" x2="-17.78" y2="40.64" width="0.1524" layer="91"/>
<wire x1="-17.78" y1="40.64" x2="-17.78" y2="106.68" width="0.1524" layer="91"/>
<wire x1="-17.78" y1="40.64" x2="-5.08" y2="40.64" width="0.1524" layer="91"/>
<junction x="-17.78" y="40.64"/>
<wire x1="-3.81" y1="41.91" x2="-5.08" y2="40.64" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T27"/>
<wire x1="-125.73" y1="40.64" x2="-146.05" y2="40.64" width="0.1524" layer="91"/>
<label x="-144.78" y="40.894" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U7" gate="B4" pin="Y"/>
<wire x1="208.28" y1="29.21" x2="218.44" y2="29.21" width="0.1524" layer="91"/>
<pinref part="U3" gate="B4" pin="A"/>
<wire x1="218.44" y1="29.21" x2="229.87" y2="29.21" width="0.1524" layer="91"/>
<wire x1="208.28" y1="52.07" x2="218.44" y2="52.07" width="0.1524" layer="91"/>
<wire x1="218.44" y1="52.07" x2="218.44" y2="29.21" width="0.1524" layer="91"/>
<junction x="218.44" y="29.21"/>
<label x="228.6" y="29.464" size="1.524" layer="95" rot="MR0"/>
<wire x1="231.14" y1="30.48" x2="229.87" y2="29.21" width="0.1524" layer="91"/>
</segment>
</net>
<net name="A7" class="0">
<segment>
<pinref part="T1" gate="A" pin="B28"/>
<wire x1="-92.71" y1="38.1" x2="-5.08" y2="38.1" width="0.1524" layer="91"/>
<label x="-6.35" y="38.354" size="1.524" layer="95" rot="MR0"/>
<wire x1="-3.81" y1="39.37" x2="-5.08" y2="38.1" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T28"/>
<wire x1="-125.73" y1="38.1" x2="-146.05" y2="38.1" width="0.1524" layer="91"/>
<label x="-144.78" y="38.354" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U10" gate="B4" pin="Y"/>
<wire x1="129.54" y1="-21.59" x2="151.13" y2="-21.59" width="0.1524" layer="91"/>
<label x="149.86" y="-21.336" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="-20.32" x2="151.13" y2="-21.59" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U12" gate="B4" pin="Y"/>
<wire x1="287.02" y1="-21.59" x2="304.8" y2="-21.59" width="0.1524" layer="91"/>
<label x="303.53" y="-21.59" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="-20.32" x2="304.8" y2="-21.59" width="0.1524" layer="91"/>
</segment>
</net>
<net name="A8" class="0">
<segment>
<pinref part="T1" gate="A" pin="B31"/>
<wire x1="-92.71" y1="30.48" x2="-5.08" y2="30.48" width="0.1524" layer="91"/>
<label x="-6.35" y="30.734" size="1.524" layer="95" rot="MR0"/>
<wire x1="-3.81" y1="31.75" x2="-5.08" y2="30.48" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T31"/>
<wire x1="-125.73" y1="30.48" x2="-146.05" y2="30.48" width="0.1524" layer="91"/>
<label x="-144.78" y="30.734" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U11" gate="A1" pin="Y"/>
<wire x1="129.54" y1="-36.83" x2="151.13" y2="-36.83" width="0.1524" layer="91"/>
<label x="149.86" y="-36.576" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="-35.56" x2="151.13" y2="-36.83" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U11" gate="B1" pin="Y"/>
<wire x1="287.02" y1="-36.83" x2="304.8" y2="-36.83" width="0.1524" layer="91"/>
<label x="303.53" y="-36.83" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="-35.56" x2="304.8" y2="-36.83" width="0.1524" layer="91"/>
</segment>
</net>
<net name="A9" class="0">
<segment>
<pinref part="T1" gate="A" pin="B32"/>
<wire x1="-92.71" y1="27.94" x2="-5.08" y2="27.94" width="0.1524" layer="91"/>
<label x="-6.35" y="28.194" size="1.524" layer="95" rot="MR0"/>
<wire x1="-3.81" y1="29.21" x2="-5.08" y2="27.94" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T32"/>
<wire x1="-125.73" y1="27.94" x2="-146.05" y2="27.94" width="0.1524" layer="91"/>
<label x="-144.78" y="28.194" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U11" gate="A2" pin="Y"/>
<wire x1="129.54" y1="-39.37" x2="151.13" y2="-39.37" width="0.1524" layer="91"/>
<label x="149.86" y="-39.116" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="-38.1" x2="151.13" y2="-39.37" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U11" gate="B2" pin="Y"/>
<wire x1="287.02" y1="-39.37" x2="304.8" y2="-39.37" width="0.1524" layer="91"/>
<label x="303.53" y="-39.37" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="-38.1" x2="304.8" y2="-39.37" width="0.1524" layer="91"/>
</segment>
</net>
<net name="!RAS0_2_" class="0">
<segment>
<pinref part="T1" gate="A" pin="B34"/>
<wire x1="-92.71" y1="22.86" x2="-86.36" y2="22.86" width="0.1524" layer="91"/>
<pinref part="T1" gate="A" pin="B44"/>
<wire x1="-86.36" y1="22.86" x2="-5.08" y2="22.86" width="0.1524" layer="91"/>
<wire x1="-92.71" y1="-2.54" x2="-86.36" y2="-2.54" width="0.1524" layer="91"/>
<wire x1="-86.36" y1="-2.54" x2="-86.36" y2="22.86" width="0.1524" layer="91"/>
<junction x="-86.36" y="22.86"/>
<label x="-6.35" y="23.114" size="1.524" layer="95" rot="MR0"/>
<wire x1="-3.81" y1="24.13" x2="-5.08" y2="22.86" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T34"/>
<wire x1="-125.73" y1="22.86" x2="-132.08" y2="22.86" width="0.1524" layer="91"/>
<pinref part="T1" gate="A" pin="T44"/>
<wire x1="-132.08" y1="22.86" x2="-146.05" y2="22.86" width="0.1524" layer="91"/>
<wire x1="-125.73" y1="-2.54" x2="-132.08" y2="-2.54" width="0.1524" layer="91"/>
<wire x1="-132.08" y1="-2.54" x2="-132.08" y2="22.86" width="0.1524" layer="91"/>
<junction x="-132.08" y="22.86"/>
<label x="-144.78" y="23.114" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="CN1" gate="A" pin="11"/>
<wire x1="21.59" y1="-78.74" x2="-2.54" y2="-78.74" width="0.1524" layer="91"/>
<label x="-1.27" y="-78.486" size="1.524" layer="95"/>
<wire x1="-3.81" y1="-77.47" x2="-2.54" y2="-78.74" width="0.1524" layer="91"/>
</segment>
</net>
<net name="DP2" class="0">
<segment>
<pinref part="T1" gate="A" pin="B35"/>
<wire x1="-92.71" y1="20.32" x2="-64.77" y2="20.32" width="0.1524" layer="91"/>
<label x="-6.35" y="20.574" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP5" gate="A" pin="2"/>
<wire x1="-64.77" y1="20.32" x2="-5.08" y2="20.32" width="0.1524" layer="91"/>
<wire x1="-64.77" y1="10.16" x2="-64.77" y2="20.32" width="0.1524" layer="91"/>
<junction x="-64.77" y="20.32"/>
<wire x1="-3.81" y1="21.59" x2="-5.08" y2="20.32" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T35"/>
<wire x1="-125.73" y1="20.32" x2="-146.05" y2="20.32" width="0.1524" layer="91"/>
<label x="-144.78" y="20.574" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U9" gate="B1" pin="A"/>
<wire x1="129.54" y1="-66.04" x2="132.08" y2="-66.04" width="0.1524" layer="91"/>
<label x="149.86" y="-88.646" size="1.524" layer="95" rot="MR0"/>
<pinref part="U9" gate="A1" pin="Y"/>
<wire x1="151.13" y1="-88.9" x2="132.08" y2="-88.9" width="0.1524" layer="91"/>
<wire x1="132.08" y1="-88.9" x2="129.54" y2="-88.9" width="0.1524" layer="91"/>
<wire x1="132.08" y1="-66.04" x2="132.08" y2="-88.9" width="0.1524" layer="91"/>
<junction x="132.08" y="-88.9"/>
<wire x1="152.4" y1="-87.63" x2="151.13" y2="-88.9" width="0.1524" layer="91"/>
</segment>
</net>
<net name="DP0" class="0">
<segment>
<pinref part="T1" gate="A" pin="B36"/>
<wire x1="-92.71" y1="17.78" x2="-62.23" y2="17.78" width="0.1524" layer="91"/>
<label x="-6.35" y="18.034" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP5" gate="A" pin="3"/>
<wire x1="-62.23" y1="17.78" x2="-5.08" y2="17.78" width="0.1524" layer="91"/>
<wire x1="-62.23" y1="10.16" x2="-62.23" y2="17.78" width="0.1524" layer="91"/>
<junction x="-62.23" y="17.78"/>
<wire x1="-3.81" y1="19.05" x2="-5.08" y2="17.78" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T36"/>
<wire x1="-125.73" y1="17.78" x2="-146.05" y2="17.78" width="0.1524" layer="91"/>
<label x="-144.78" y="18.034" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U9" gate="B2" pin="A"/>
<wire x1="129.54" y1="-68.58" x2="134.62" y2="-68.58" width="0.1524" layer="91"/>
<label x="149.86" y="-91.186" size="1.524" layer="95" rot="MR0"/>
<pinref part="U9" gate="A2" pin="Y"/>
<wire x1="151.13" y1="-91.44" x2="134.62" y2="-91.44" width="0.1524" layer="91"/>
<wire x1="134.62" y1="-91.44" x2="129.54" y2="-91.44" width="0.1524" layer="91"/>
<wire x1="134.62" y1="-68.58" x2="134.62" y2="-91.44" width="0.1524" layer="91"/>
<junction x="134.62" y="-91.44"/>
<wire x1="152.4" y1="-90.17" x2="151.13" y2="-91.44" width="0.1524" layer="91"/>
</segment>
</net>
<net name="DP1" class="0">
<segment>
<pinref part="T1" gate="A" pin="B37"/>
<wire x1="-92.71" y1="15.24" x2="-59.69" y2="15.24" width="0.1524" layer="91"/>
<label x="-6.35" y="15.494" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP5" gate="A" pin="4"/>
<wire x1="-59.69" y1="15.24" x2="-5.08" y2="15.24" width="0.1524" layer="91"/>
<wire x1="-59.69" y1="10.16" x2="-59.69" y2="15.24" width="0.1524" layer="91"/>
<junction x="-59.69" y="15.24"/>
<wire x1="-3.81" y1="16.51" x2="-5.08" y2="15.24" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T37"/>
<wire x1="-125.73" y1="15.24" x2="-146.05" y2="15.24" width="0.1524" layer="91"/>
<label x="-144.78" y="15.494" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U9" gate="B3" pin="A"/>
<wire x1="129.54" y1="-71.12" x2="137.16" y2="-71.12" width="0.1524" layer="91"/>
<label x="149.86" y="-93.726" size="1.524" layer="95" rot="MR0"/>
<pinref part="U9" gate="A3" pin="Y"/>
<wire x1="129.54" y1="-93.98" x2="137.16" y2="-93.98" width="0.1524" layer="91"/>
<wire x1="137.16" y1="-93.98" x2="151.13" y2="-93.98" width="0.1524" layer="91"/>
<wire x1="137.16" y1="-71.12" x2="137.16" y2="-93.98" width="0.1524" layer="91"/>
<junction x="137.16" y="-93.98"/>
<wire x1="152.4" y1="-92.71" x2="151.13" y2="-93.98" width="0.1524" layer="91"/>
</segment>
</net>
<net name="DP3" class="0">
<segment>
<pinref part="T1" gate="A" pin="B38"/>
<wire x1="-92.71" y1="12.7" x2="-57.15" y2="12.7" width="0.1524" layer="91"/>
<label x="-6.35" y="12.954" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP5" gate="A" pin="5"/>
<wire x1="-57.15" y1="12.7" x2="-5.08" y2="12.7" width="0.1524" layer="91"/>
<wire x1="-57.15" y1="10.16" x2="-57.15" y2="12.7" width="0.1524" layer="91"/>
<junction x="-57.15" y="12.7"/>
<wire x1="-3.81" y1="13.97" x2="-5.08" y2="12.7" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T38"/>
<wire x1="-125.73" y1="12.7" x2="-146.05" y2="12.7" width="0.1524" layer="91"/>
<label x="-144.78" y="12.954" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U9" gate="B4" pin="A"/>
<label x="149.86" y="-96.266" size="1.524" layer="95" rot="MR0"/>
<pinref part="U9" gate="A4" pin="Y"/>
<wire x1="139.7" y1="-73.66" x2="129.54" y2="-73.66" width="0.1524" layer="91"/>
<wire x1="129.54" y1="-96.52" x2="139.7" y2="-96.52" width="0.1524" layer="91"/>
<wire x1="139.7" y1="-96.52" x2="151.13" y2="-96.52" width="0.1524" layer="91"/>
<wire x1="139.7" y1="-73.66" x2="139.7" y2="-96.52" width="0.1524" layer="91"/>
<junction x="139.7" y="-96.52"/>
<wire x1="152.4" y1="-95.25" x2="151.13" y2="-96.52" width="0.1524" layer="91"/>
</segment>
</net>
<net name="!WE!_D0-D35" class="0">
<segment>
<pinref part="T1" gate="A" pin="B47"/>
<wire x1="-92.71" y1="-10.16" x2="-88.9" y2="-10.16" width="0.1524" layer="91"/>
<label x="-6.35" y="-7.366" size="1.524" layer="95" rot="MR0"/>
<wire x1="-88.9" y1="-10.16" x2="-88.9" y2="-7.62" width="0.1524" layer="91"/>
<wire x1="-88.9" y1="-7.62" x2="-5.08" y2="-7.62" width="0.1524" layer="91"/>
<wire x1="-3.81" y1="-6.35" x2="-5.08" y2="-7.62" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T47"/>
<wire x1="-125.73" y1="-10.16" x2="-129.54" y2="-10.16" width="0.1524" layer="91"/>
<wire x1="-129.54" y1="-10.16" x2="-129.54" y2="-7.62" width="0.1524" layer="91"/>
<wire x1="-129.54" y1="-7.62" x2="-146.05" y2="-7.62" width="0.1524" layer="91"/>
<label x="-144.78" y="-7.366" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="CN1" gate="A" pin="12"/>
<wire x1="21.59" y1="-81.28" x2="-2.54" y2="-81.28" width="0.1524" layer="91"/>
<label x="-1.27" y="-81.026" size="1.524" layer="95"/>
<wire x1="-3.81" y1="-80.01" x2="-2.54" y2="-81.28" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U7" gate="A" pin="G"/>
<wire x1="177.8" y1="76.2" x2="153.67" y2="76.2" width="0.1524" layer="91"/>
<label x="154.94" y="76.454" size="1.524" layer="95"/>
<wire x1="152.4" y1="77.47" x2="153.67" y2="76.2" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U7" gate="B" pin="G"/>
<wire x1="177.8" y1="24.13" x2="153.67" y2="24.13" width="0.1524" layer="91"/>
<label x="154.94" y="24.384" size="1.524" layer="95"/>
<wire x1="152.4" y1="25.4" x2="153.67" y2="24.13" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U5" gate="A" pin="G"/>
<wire x1="20.32" y1="76.2" x2="-2.54" y2="76.2" width="0.1524" layer="91"/>
<label x="-1.27" y="76.454" size="1.524" layer="95"/>
<wire x1="-3.81" y1="77.47" x2="-2.54" y2="76.2" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U5" gate="B" pin="G"/>
<wire x1="20.32" y1="24.13" x2="-2.54" y2="24.13" width="0.1524" layer="91"/>
<label x="-1.27" y="24.384" size="1.524" layer="95"/>
<wire x1="-3.81" y1="25.4" x2="-2.54" y2="24.13" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U8" gate="A" pin="G"/>
<wire x1="256.54" y1="76.2" x2="232.41" y2="76.2" width="0.1524" layer="91"/>
<label x="233.68" y="76.454" size="1.524" layer="95"/>
<wire x1="231.14" y1="77.47" x2="232.41" y2="76.2" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U8" gate="B" pin="G"/>
<wire x1="256.54" y1="24.13" x2="232.41" y2="24.13" width="0.1524" layer="91"/>
<label x="233.68" y="24.384" size="1.524" layer="95"/>
<wire x1="231.14" y1="25.4" x2="232.41" y2="24.13" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U6" gate="A" pin="G"/>
<wire x1="99.06" y1="76.2" x2="74.93" y2="76.2" width="0.1524" layer="91"/>
<label x="76.2" y="76.454" size="1.524" layer="95"/>
<wire x1="73.66" y1="77.47" x2="74.93" y2="76.2" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U6" gate="B" pin="G"/>
<wire x1="99.06" y1="24.13" x2="74.93" y2="24.13" width="0.1524" layer="91"/>
<label x="76.2" y="24.384" size="1.524" layer="95"/>
<wire x1="73.66" y1="25.4" x2="74.93" y2="24.13" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U9" gate="A" pin="G"/>
<wire x1="99.06" y1="-101.6" x2="74.93" y2="-101.6" width="0.1524" layer="91"/>
<label x="76.2" y="-101.346" size="1.524" layer="95"/>
<wire x1="73.66" y1="-100.33" x2="74.93" y2="-101.6" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D8" class="0">
<segment>
<pinref part="T1" gate="A" pin="B49"/>
<label x="-6.35" y="-14.986" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP2" gate="A" pin="2"/>
<wire x1="-92.71" y1="-15.24" x2="-66.04" y2="-15.24" width="0.1524" layer="91"/>
<wire x1="-66.04" y1="-15.24" x2="-66.04" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-66.04" y1="-15.24" x2="-5.08" y2="-15.24" width="0.1524" layer="91"/>
<junction x="-66.04" y="-15.24"/>
<wire x1="-3.81" y1="-13.97" x2="-5.08" y2="-15.24" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T49"/>
<wire x1="-125.73" y1="-15.24" x2="-146.05" y2="-15.24" width="0.1524" layer="91"/>
<label x="-144.78" y="-14.986" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U2" gate="A1" pin="A"/>
<wire x1="129.54" y1="111.76" x2="132.08" y2="111.76" width="0.1524" layer="91"/>
<wire x1="132.08" y1="111.76" x2="132.08" y2="88.9" width="0.1524" layer="91"/>
<pinref part="U6" gate="A1" pin="Y"/>
<wire x1="132.08" y1="88.9" x2="129.54" y2="88.9" width="0.1524" layer="91"/>
<wire x1="132.08" y1="88.9" x2="151.13" y2="88.9" width="0.1524" layer="91"/>
<junction x="132.08" y="88.9"/>
<label x="149.86" y="89.154" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="90.17" x2="151.13" y2="88.9" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D24" class="0">
<segment>
<pinref part="T1" gate="A" pin="B50"/>
<label x="-6.35" y="-17.526" size="1.524" layer="95" rot="MR0"/>
<wire x1="-92.71" y1="-17.78" x2="-35.56" y2="-17.78" width="0.1524" layer="91"/>
<pinref part="RP4" gate="A" pin="2"/>
<wire x1="-35.56" y1="-17.78" x2="-35.56" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-35.56" y1="-17.78" x2="-5.08" y2="-17.78" width="0.1524" layer="91"/>
<junction x="-35.56" y="-17.78"/>
<wire x1="-3.81" y1="-16.51" x2="-5.08" y2="-17.78" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T50"/>
<wire x1="-125.73" y1="-17.78" x2="-146.05" y2="-17.78" width="0.1524" layer="91"/>
<label x="-144.78" y="-17.526" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U8" gate="A1" pin="Y"/>
<wire x1="287.02" y1="88.9" x2="289.56" y2="88.9" width="0.1524" layer="91"/>
<pinref part="U4" gate="A1" pin="A"/>
<wire x1="289.56" y1="88.9" x2="304.8" y2="88.9" width="0.1524" layer="91"/>
<wire x1="287.02" y1="111.76" x2="289.56" y2="111.76" width="0.1524" layer="91"/>
<wire x1="289.56" y1="111.76" x2="289.56" y2="88.9" width="0.1524" layer="91"/>
<junction x="289.56" y="88.9"/>
<label x="303.53" y="88.9" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="90.17" x2="304.8" y2="88.9" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D9" class="0">
<segment>
<pinref part="T1" gate="A" pin="B51"/>
<label x="-6.35" y="-20.066" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP2" gate="A" pin="3"/>
<wire x1="-92.71" y1="-20.32" x2="-63.5" y2="-20.32" width="0.1524" layer="91"/>
<wire x1="-63.5" y1="-20.32" x2="-63.5" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-63.5" y1="-20.32" x2="-5.08" y2="-20.32" width="0.1524" layer="91"/>
<junction x="-63.5" y="-20.32"/>
<wire x1="-3.81" y1="-19.05" x2="-5.08" y2="-20.32" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T51"/>
<wire x1="-125.73" y1="-20.32" x2="-146.05" y2="-20.32" width="0.1524" layer="91"/>
<label x="-144.78" y="-20.066" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U2" gate="A2" pin="A"/>
<wire x1="129.54" y1="109.22" x2="134.62" y2="109.22" width="0.1524" layer="91"/>
<wire x1="134.62" y1="109.22" x2="134.62" y2="86.36" width="0.1524" layer="91"/>
<pinref part="U6" gate="A2" pin="Y"/>
<wire x1="134.62" y1="86.36" x2="129.54" y2="86.36" width="0.1524" layer="91"/>
<wire x1="134.62" y1="86.36" x2="151.13" y2="86.36" width="0.1524" layer="91"/>
<junction x="134.62" y="86.36"/>
<label x="149.86" y="86.614" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="87.63" x2="151.13" y2="86.36" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D25" class="0">
<segment>
<pinref part="T1" gate="A" pin="B52"/>
<label x="-6.35" y="-22.606" size="1.524" layer="95" rot="MR0"/>
<wire x1="-92.71" y1="-22.86" x2="-33.02" y2="-22.86" width="0.1524" layer="91"/>
<pinref part="RP4" gate="A" pin="3"/>
<wire x1="-33.02" y1="-22.86" x2="-33.02" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-33.02" y1="-22.86" x2="-5.08" y2="-22.86" width="0.1524" layer="91"/>
<junction x="-33.02" y="-22.86"/>
<wire x1="-3.81" y1="-21.59" x2="-5.08" y2="-22.86" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T52"/>
<wire x1="-125.73" y1="-22.86" x2="-146.05" y2="-22.86" width="0.1524" layer="91"/>
<label x="-144.78" y="-22.606" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U8" gate="A2" pin="Y"/>
<wire x1="287.02" y1="86.36" x2="292.1" y2="86.36" width="0.1524" layer="91"/>
<pinref part="U4" gate="A2" pin="A"/>
<wire x1="292.1" y1="86.36" x2="304.8" y2="86.36" width="0.1524" layer="91"/>
<wire x1="287.02" y1="109.22" x2="292.1" y2="109.22" width="0.1524" layer="91"/>
<wire x1="292.1" y1="109.22" x2="292.1" y2="86.36" width="0.1524" layer="91"/>
<junction x="292.1" y="86.36"/>
<label x="303.53" y="86.36" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="87.63" x2="304.8" y2="86.36" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D10" class="0">
<segment>
<pinref part="T1" gate="A" pin="B53"/>
<label x="-6.35" y="-25.146" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP2" gate="A" pin="4"/>
<wire x1="-92.71" y1="-25.4" x2="-60.96" y2="-25.4" width="0.1524" layer="91"/>
<wire x1="-60.96" y1="-25.4" x2="-60.96" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-60.96" y1="-25.4" x2="-5.08" y2="-25.4" width="0.1524" layer="91"/>
<junction x="-60.96" y="-25.4"/>
<wire x1="-3.81" y1="-24.13" x2="-5.08" y2="-25.4" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T53"/>
<wire x1="-125.73" y1="-25.4" x2="-146.05" y2="-25.4" width="0.1524" layer="91"/>
<label x="-144.78" y="-25.146" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U2" gate="A3" pin="A"/>
<wire x1="129.54" y1="106.68" x2="137.16" y2="106.68" width="0.1524" layer="91"/>
<wire x1="137.16" y1="106.68" x2="137.16" y2="83.82" width="0.1524" layer="91"/>
<pinref part="U6" gate="A3" pin="Y"/>
<wire x1="137.16" y1="83.82" x2="129.54" y2="83.82" width="0.1524" layer="91"/>
<wire x1="137.16" y1="83.82" x2="151.13" y2="83.82" width="0.1524" layer="91"/>
<junction x="137.16" y="83.82"/>
<label x="149.86" y="84.074" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="85.09" x2="151.13" y2="83.82" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D26" class="0">
<segment>
<pinref part="T1" gate="A" pin="B54"/>
<label x="-6.35" y="-27.686" size="1.524" layer="95" rot="MR0"/>
<wire x1="-92.71" y1="-27.94" x2="-30.48" y2="-27.94" width="0.1524" layer="91"/>
<pinref part="RP4" gate="A" pin="4"/>
<wire x1="-30.48" y1="-27.94" x2="-30.48" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-30.48" y1="-27.94" x2="-5.08" y2="-27.94" width="0.1524" layer="91"/>
<junction x="-30.48" y="-27.94"/>
<wire x1="-3.81" y1="-26.67" x2="-5.08" y2="-27.94" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T54"/>
<wire x1="-125.73" y1="-27.94" x2="-146.05" y2="-27.94" width="0.1524" layer="91"/>
<label x="-144.78" y="-27.686" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U8" gate="A3" pin="Y"/>
<wire x1="287.02" y1="83.82" x2="294.64" y2="83.82" width="0.1524" layer="91"/>
<pinref part="U4" gate="A3" pin="A"/>
<wire x1="294.64" y1="83.82" x2="304.8" y2="83.82" width="0.1524" layer="91"/>
<wire x1="287.02" y1="106.68" x2="294.64" y2="106.68" width="0.1524" layer="91"/>
<wire x1="294.64" y1="106.68" x2="294.64" y2="83.82" width="0.1524" layer="91"/>
<junction x="294.64" y="83.82"/>
<label x="303.53" y="83.82" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="85.09" x2="304.8" y2="83.82" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D11" class="0">
<segment>
<pinref part="T1" gate="A" pin="B55"/>
<label x="-6.35" y="-30.226" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP2" gate="A" pin="5"/>
<wire x1="-92.71" y1="-30.48" x2="-58.42" y2="-30.48" width="0.1524" layer="91"/>
<wire x1="-58.42" y1="-30.48" x2="-58.42" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-58.42" y1="-30.48" x2="-5.08" y2="-30.48" width="0.1524" layer="91"/>
<junction x="-58.42" y="-30.48"/>
<wire x1="-3.81" y1="-29.21" x2="-5.08" y2="-30.48" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T55"/>
<wire x1="-125.73" y1="-30.48" x2="-146.05" y2="-30.48" width="0.1524" layer="91"/>
<label x="-144.78" y="-30.226" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U2" gate="A4" pin="A"/>
<wire x1="129.54" y1="104.14" x2="139.7" y2="104.14" width="0.1524" layer="91"/>
<wire x1="139.7" y1="104.14" x2="139.7" y2="81.28" width="0.1524" layer="91"/>
<pinref part="U6" gate="A4" pin="Y"/>
<wire x1="139.7" y1="81.28" x2="129.54" y2="81.28" width="0.1524" layer="91"/>
<wire x1="139.7" y1="81.28" x2="151.13" y2="81.28" width="0.1524" layer="91"/>
<junction x="139.7" y="81.28"/>
<label x="149.86" y="81.534" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="82.55" x2="151.13" y2="81.28" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D27" class="0">
<segment>
<pinref part="T1" gate="A" pin="B56"/>
<label x="-6.35" y="-32.766" size="1.524" layer="95" rot="MR0"/>
<wire x1="-92.71" y1="-33.02" x2="-27.94" y2="-33.02" width="0.1524" layer="91"/>
<pinref part="RP4" gate="A" pin="5"/>
<wire x1="-27.94" y1="-33.02" x2="-27.94" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-27.94" y1="-33.02" x2="-5.08" y2="-33.02" width="0.1524" layer="91"/>
<junction x="-27.94" y="-33.02"/>
<wire x1="-3.81" y1="-31.75" x2="-5.08" y2="-33.02" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T56"/>
<wire x1="-125.73" y1="-33.02" x2="-146.05" y2="-33.02" width="0.1524" layer="91"/>
<label x="-144.78" y="-32.766" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U8" gate="A4" pin="Y"/>
<wire x1="287.02" y1="81.28" x2="297.18" y2="81.28" width="0.1524" layer="91"/>
<pinref part="U4" gate="A4" pin="A"/>
<wire x1="297.18" y1="81.28" x2="304.8" y2="81.28" width="0.1524" layer="91"/>
<wire x1="287.02" y1="104.14" x2="297.18" y2="104.14" width="0.1524" layer="91"/>
<wire x1="297.18" y1="104.14" x2="297.18" y2="81.28" width="0.1524" layer="91"/>
<junction x="297.18" y="81.28"/>
<label x="303.53" y="81.28" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="82.55" x2="304.8" y2="81.28" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D12" class="0">
<segment>
<pinref part="T1" gate="A" pin="B57"/>
<label x="-6.35" y="-35.306" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP2" gate="A" pin="6"/>
<wire x1="-92.71" y1="-35.56" x2="-55.88" y2="-35.56" width="0.1524" layer="91"/>
<wire x1="-55.88" y1="-35.56" x2="-55.88" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-55.88" y1="-35.56" x2="-5.08" y2="-35.56" width="0.1524" layer="91"/>
<junction x="-55.88" y="-35.56"/>
<wire x1="-3.81" y1="-34.29" x2="-5.08" y2="-35.56" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T57"/>
<wire x1="-125.73" y1="-35.56" x2="-146.05" y2="-35.56" width="0.1524" layer="91"/>
<label x="-144.78" y="-35.306" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U6" gate="B1" pin="Y"/>
<wire x1="129.54" y1="36.83" x2="132.08" y2="36.83" width="0.1524" layer="91"/>
<pinref part="U2" gate="B1" pin="A"/>
<wire x1="132.08" y1="36.83" x2="151.13" y2="36.83" width="0.1524" layer="91"/>
<wire x1="129.54" y1="59.69" x2="132.08" y2="59.69" width="0.1524" layer="91"/>
<wire x1="132.08" y1="59.69" x2="132.08" y2="36.83" width="0.1524" layer="91"/>
<junction x="132.08" y="36.83"/>
<label x="149.86" y="37.084" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="38.1" x2="151.13" y2="36.83" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D28" class="0">
<segment>
<pinref part="T1" gate="A" pin="B58"/>
<label x="-6.35" y="-37.846" size="1.524" layer="95" rot="MR0"/>
<wire x1="-92.71" y1="-38.1" x2="-25.4" y2="-38.1" width="0.1524" layer="91"/>
<pinref part="RP4" gate="A" pin="6"/>
<wire x1="-25.4" y1="-38.1" x2="-25.4" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-25.4" y1="-38.1" x2="-5.08" y2="-38.1" width="0.1524" layer="91"/>
<junction x="-25.4" y="-38.1"/>
<wire x1="-3.81" y1="-36.83" x2="-5.08" y2="-38.1" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T58"/>
<wire x1="-125.73" y1="-38.1" x2="-146.05" y2="-38.1" width="0.1524" layer="91"/>
<label x="-144.78" y="-37.846" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U8" gate="B1" pin="Y"/>
<wire x1="287.02" y1="36.83" x2="289.56" y2="36.83" width="0.1524" layer="91"/>
<pinref part="U4" gate="B1" pin="A"/>
<wire x1="289.56" y1="36.83" x2="304.8" y2="36.83" width="0.1524" layer="91"/>
<wire x1="287.02" y1="59.69" x2="289.56" y2="59.69" width="0.1524" layer="91"/>
<wire x1="289.56" y1="59.69" x2="289.56" y2="36.83" width="0.1524" layer="91"/>
<junction x="289.56" y="36.83"/>
<label x="303.53" y="36.83" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="38.1" x2="304.8" y2="36.83" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D29" class="0">
<segment>
<pinref part="T1" gate="A" pin="B60"/>
<label x="-6.35" y="-42.926" size="1.524" layer="95" rot="MR0"/>
<wire x1="-92.71" y1="-43.18" x2="-22.86" y2="-43.18" width="0.1524" layer="91"/>
<pinref part="RP4" gate="A" pin="7"/>
<wire x1="-22.86" y1="-43.18" x2="-22.86" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-22.86" y1="-43.18" x2="-5.08" y2="-43.18" width="0.1524" layer="91"/>
<junction x="-22.86" y="-43.18"/>
<wire x1="-3.81" y1="-41.91" x2="-5.08" y2="-43.18" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T60"/>
<wire x1="-125.73" y1="-43.18" x2="-146.05" y2="-43.18" width="0.1524" layer="91"/>
<label x="-144.78" y="-42.926" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U8" gate="B2" pin="Y"/>
<wire x1="287.02" y1="34.29" x2="292.1" y2="34.29" width="0.1524" layer="91"/>
<pinref part="U4" gate="B2" pin="A"/>
<wire x1="292.1" y1="34.29" x2="304.8" y2="34.29" width="0.1524" layer="91"/>
<wire x1="287.02" y1="57.15" x2="292.1" y2="57.15" width="0.1524" layer="91"/>
<wire x1="292.1" y1="57.15" x2="292.1" y2="34.29" width="0.1524" layer="91"/>
<junction x="292.1" y="34.29"/>
<label x="303.53" y="34.29" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="35.56" x2="304.8" y2="34.29" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D13" class="0">
<segment>
<pinref part="T1" gate="A" pin="B61"/>
<label x="-6.35" y="-45.466" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP2" gate="A" pin="7"/>
<wire x1="-92.71" y1="-45.72" x2="-53.34" y2="-45.72" width="0.1524" layer="91"/>
<wire x1="-53.34" y1="-45.72" x2="-53.34" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-53.34" y1="-45.72" x2="-5.08" y2="-45.72" width="0.1524" layer="91"/>
<junction x="-53.34" y="-45.72"/>
<wire x1="-3.81" y1="-44.45" x2="-5.08" y2="-45.72" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T61"/>
<wire x1="-125.73" y1="-45.72" x2="-146.05" y2="-45.72" width="0.1524" layer="91"/>
<label x="-144.78" y="-45.466" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U6" gate="B2" pin="Y"/>
<wire x1="129.54" y1="34.29" x2="134.62" y2="34.29" width="0.1524" layer="91"/>
<pinref part="U2" gate="B2" pin="A"/>
<wire x1="134.62" y1="34.29" x2="151.13" y2="34.29" width="0.1524" layer="91"/>
<wire x1="129.54" y1="57.15" x2="134.62" y2="57.15" width="0.1524" layer="91"/>
<wire x1="134.62" y1="57.15" x2="134.62" y2="34.29" width="0.1524" layer="91"/>
<junction x="134.62" y="34.29"/>
<label x="149.86" y="34.544" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="35.56" x2="151.13" y2="34.29" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D30" class="0">
<segment>
<pinref part="T1" gate="A" pin="B62"/>
<label x="-6.35" y="-48.006" size="1.524" layer="95" rot="MR0"/>
<wire x1="-92.71" y1="-48.26" x2="-20.32" y2="-48.26" width="0.1524" layer="91"/>
<pinref part="RP4" gate="A" pin="8"/>
<wire x1="-20.32" y1="-48.26" x2="-20.32" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-20.32" y1="-48.26" x2="-5.08" y2="-48.26" width="0.1524" layer="91"/>
<junction x="-20.32" y="-48.26"/>
<wire x1="-3.81" y1="-46.99" x2="-5.08" y2="-48.26" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T62"/>
<wire x1="-125.73" y1="-48.26" x2="-146.05" y2="-48.26" width="0.1524" layer="91"/>
<label x="-144.78" y="-48.006" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U8" gate="B3" pin="Y"/>
<wire x1="287.02" y1="31.75" x2="294.64" y2="31.75" width="0.1524" layer="91"/>
<pinref part="U4" gate="B3" pin="A"/>
<wire x1="294.64" y1="31.75" x2="304.8" y2="31.75" width="0.1524" layer="91"/>
<wire x1="287.02" y1="54.61" x2="294.64" y2="54.61" width="0.1524" layer="91"/>
<wire x1="294.64" y1="54.61" x2="294.64" y2="31.75" width="0.1524" layer="91"/>
<junction x="294.64" y="31.75"/>
<label x="303.53" y="31.75" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="33.02" x2="304.8" y2="31.75" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D14" class="0">
<segment>
<pinref part="T1" gate="A" pin="B63"/>
<label x="-6.35" y="-50.546" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP2" gate="A" pin="8"/>
<wire x1="-92.71" y1="-50.8" x2="-50.8" y2="-50.8" width="0.1524" layer="91"/>
<wire x1="-50.8" y1="-50.8" x2="-50.8" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-50.8" y1="-50.8" x2="-5.08" y2="-50.8" width="0.1524" layer="91"/>
<junction x="-50.8" y="-50.8"/>
<wire x1="-3.81" y1="-49.53" x2="-5.08" y2="-50.8" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T63"/>
<wire x1="-125.73" y1="-50.8" x2="-146.05" y2="-50.8" width="0.1524" layer="91"/>
<label x="-144.78" y="-50.546" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U6" gate="B3" pin="Y"/>
<wire x1="129.54" y1="31.75" x2="137.16" y2="31.75" width="0.1524" layer="91"/>
<pinref part="U2" gate="B3" pin="A"/>
<wire x1="137.16" y1="31.75" x2="151.13" y2="31.75" width="0.1524" layer="91"/>
<wire x1="129.54" y1="54.61" x2="137.16" y2="54.61" width="0.1524" layer="91"/>
<wire x1="137.16" y1="54.61" x2="137.16" y2="31.75" width="0.1524" layer="91"/>
<junction x="137.16" y="31.75"/>
<label x="149.86" y="32.004" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="33.02" x2="151.13" y2="31.75" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D31" class="0">
<segment>
<pinref part="T1" gate="A" pin="B64"/>
<label x="-6.35" y="-53.086" size="1.524" layer="95" rot="MR0"/>
<wire x1="-92.71" y1="-53.34" x2="-17.78" y2="-53.34" width="0.1524" layer="91"/>
<pinref part="RP4" gate="A" pin="9"/>
<wire x1="-17.78" y1="-53.34" x2="-17.78" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-17.78" y1="-53.34" x2="-5.08" y2="-53.34" width="0.1524" layer="91"/>
<junction x="-17.78" y="-53.34"/>
<wire x1="-3.81" y1="-52.07" x2="-5.08" y2="-53.34" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T64"/>
<wire x1="-125.73" y1="-53.34" x2="-146.05" y2="-53.34" width="0.1524" layer="91"/>
<label x="-144.78" y="-53.086" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U8" gate="B4" pin="Y"/>
<wire x1="287.02" y1="29.21" x2="297.18" y2="29.21" width="0.1524" layer="91"/>
<pinref part="U4" gate="B4" pin="A"/>
<wire x1="297.18" y1="29.21" x2="304.8" y2="29.21" width="0.1524" layer="91"/>
<wire x1="287.02" y1="52.07" x2="297.18" y2="52.07" width="0.1524" layer="91"/>
<wire x1="297.18" y1="52.07" x2="297.18" y2="29.21" width="0.1524" layer="91"/>
<junction x="297.18" y="29.21"/>
<label x="303.53" y="29.21" size="1.524" layer="95" rot="MR0"/>
<wire x1="306.07" y1="30.48" x2="304.8" y2="29.21" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D15" class="0">
<segment>
<pinref part="T1" gate="A" pin="B65"/>
<label x="-6.35" y="-55.626" size="1.524" layer="95" rot="MR0"/>
<pinref part="RP2" gate="A" pin="9"/>
<wire x1="-92.71" y1="-55.88" x2="-48.26" y2="-55.88" width="0.1524" layer="91"/>
<wire x1="-48.26" y1="-55.88" x2="-48.26" y2="-58.42" width="0.1524" layer="91"/>
<wire x1="-48.26" y1="-55.88" x2="-5.08" y2="-55.88" width="0.1524" layer="91"/>
<junction x="-48.26" y="-55.88"/>
<wire x1="-3.81" y1="-54.61" x2="-5.08" y2="-55.88" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="T1" gate="A" pin="T65"/>
<wire x1="-125.73" y1="-55.88" x2="-146.05" y2="-55.88" width="0.1524" layer="91"/>
<label x="-144.78" y="-55.626" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="U6" gate="B4" pin="Y"/>
<wire x1="129.54" y1="29.21" x2="139.7" y2="29.21" width="0.1524" layer="91"/>
<pinref part="U2" gate="B4" pin="A"/>
<wire x1="139.7" y1="29.21" x2="151.13" y2="29.21" width="0.1524" layer="91"/>
<wire x1="129.54" y1="52.07" x2="139.7" y2="52.07" width="0.1524" layer="91"/>
<wire x1="139.7" y1="52.07" x2="139.7" y2="29.21" width="0.1524" layer="91"/>
<junction x="139.7" y="29.21"/>
<label x="149.86" y="29.464" size="1.524" layer="95" rot="MR0"/>
<wire x1="152.4" y1="30.48" x2="151.13" y2="29.21" width="0.1524" layer="91"/>
</segment>
</net>
<net name="!RE!_D0-D15" class="0">
<segment>
<pinref part="CN1" gate="A" pin="2"/>
<wire x1="21.59" y1="-55.88" x2="-2.54" y2="-55.88" width="0.1524" layer="91"/>
<label x="-1.27" y="-55.626" size="1.524" layer="95"/>
<wire x1="-3.81" y1="-54.61" x2="-2.54" y2="-55.88" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U2" gate="A" pin="G"/>
<wire x1="99.06" y1="99.06" x2="74.93" y2="99.06" width="0.1524" layer="91"/>
<label x="76.2" y="99.314" size="1.524" layer="95"/>
<wire x1="73.66" y1="100.33" x2="74.93" y2="99.06" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U2" gate="B" pin="G"/>
<wire x1="99.06" y1="46.99" x2="74.93" y2="46.99" width="0.1524" layer="91"/>
<label x="76.2" y="47.244" size="1.524" layer="95"/>
<wire x1="73.66" y1="48.26" x2="74.93" y2="46.99" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U1" gate="A" pin="G"/>
<wire x1="20.32" y1="99.06" x2="-2.54" y2="99.06" width="0.1524" layer="91"/>
<label x="-1.27" y="99.314" size="1.524" layer="95"/>
<wire x1="-3.81" y1="100.33" x2="-2.54" y2="99.06" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U1" gate="B" pin="G"/>
<wire x1="20.32" y1="46.99" x2="-2.54" y2="46.99" width="0.1524" layer="91"/>
<label x="-1.27" y="47.244" size="1.524" layer="95"/>
<wire x1="-3.81" y1="48.26" x2="-2.54" y2="46.99" width="0.1524" layer="91"/>
</segment>
</net>
<net name="!RE!_D16-D31" class="0">
<segment>
<pinref part="CN1" gate="A" pin="3"/>
<wire x1="21.59" y1="-58.42" x2="-2.54" y2="-58.42" width="0.1524" layer="91"/>
<label x="-1.27" y="-58.166" size="1.524" layer="95"/>
<wire x1="-3.81" y1="-57.15" x2="-2.54" y2="-58.42" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U4" gate="A" pin="G"/>
<wire x1="256.54" y1="99.06" x2="232.41" y2="99.06" width="0.1524" layer="91"/>
<label x="233.68" y="99.314" size="1.524" layer="95"/>
<wire x1="231.14" y1="100.33" x2="232.41" y2="99.06" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U4" gate="B" pin="G"/>
<wire x1="256.54" y1="46.99" x2="232.41" y2="46.99" width="0.1524" layer="91"/>
<label x="233.68" y="47.244" size="1.524" layer="95"/>
<wire x1="231.14" y1="48.26" x2="232.41" y2="46.99" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U3" gate="A" pin="G"/>
<wire x1="177.8" y1="99.06" x2="153.67" y2="99.06" width="0.1524" layer="91"/>
<label x="154.94" y="99.314" size="1.524" layer="95"/>
<wire x1="152.4" y1="100.33" x2="153.67" y2="99.06" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U3" gate="B" pin="G"/>
<wire x1="177.8" y1="46.99" x2="153.67" y2="46.99" width="0.1524" layer="91"/>
<label x="154.94" y="47.244" size="1.524" layer="95"/>
<wire x1="152.4" y1="48.26" x2="153.67" y2="46.99" width="0.1524" layer="91"/>
</segment>
</net>
<net name="!RE!_D32-D35" class="0">
<segment>
<pinref part="CN1" gate="A" pin="4"/>
<wire x1="21.59" y1="-60.96" x2="-2.54" y2="-60.96" width="0.1524" layer="91"/>
<label x="-1.27" y="-60.706" size="1.524" layer="95"/>
<wire x1="-3.81" y1="-59.69" x2="-2.54" y2="-60.96" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U9" gate="B" pin="G"/>
<wire x1="99.06" y1="-78.74" x2="74.93" y2="-78.74" width="0.1524" layer="91"/>
<label x="76.2" y="-78.486" size="1.524" layer="95"/>
<wire x1="73.66" y1="-77.47" x2="74.93" y2="-78.74" width="0.1524" layer="91"/>
</segment>
</net>
<net name="!WE!_A0-A10" class="0">
<segment>
<pinref part="CN1" gate="A" pin="14"/>
<wire x1="21.59" y1="-86.36" x2="-2.54" y2="-86.36" width="0.1524" layer="91"/>
<label x="-1.27" y="-86.106" size="1.524" layer="95"/>
<wire x1="-3.81" y1="-85.09" x2="-2.54" y2="-86.36" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U10" gate="B" pin="G"/>
<wire x1="99.06" y1="-26.67" x2="74.93" y2="-26.67" width="0.1524" layer="91"/>
<label x="76.2" y="-26.416" size="1.524" layer="95"/>
<wire x1="73.66" y1="-25.4" x2="74.93" y2="-26.67" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U10" gate="A" pin="G"/>
<wire x1="99.06" y1="-3.81" x2="74.93" y2="-3.81" width="0.1524" layer="91"/>
<label x="76.2" y="-3.556" size="1.524" layer="95"/>
<wire x1="73.66" y1="-2.54" x2="74.93" y2="-3.81" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U11" gate="A" pin="G"/>
<wire x1="99.06" y1="-49.53" x2="74.93" y2="-49.53" width="0.1524" layer="91"/>
<label x="76.2" y="-49.276" size="1.524" layer="95"/>
<wire x1="73.66" y1="-48.26" x2="74.93" y2="-49.53" width="0.1524" layer="91"/>
</segment>
</net>
<net name="!WE!_A11-A21" class="0">
<segment>
<pinref part="CN1" gate="A" pin="13"/>
<wire x1="21.59" y1="-83.82" x2="-2.54" y2="-83.82" width="0.1524" layer="91"/>
<label x="-1.27" y="-83.566" size="1.524" layer="95"/>
<wire x1="-3.81" y1="-82.55" x2="-2.54" y2="-83.82" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U11" gate="B" pin="G"/>
<wire x1="256.54" y1="-49.53" x2="232.41" y2="-49.53" width="0.1524" layer="91"/>
<label x="233.68" y="-49.276" size="1.524" layer="95"/>
<wire x1="231.14" y1="-48.26" x2="232.41" y2="-49.53" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U12" gate="A" pin="G"/>
<wire x1="256.54" y1="-3.81" x2="232.41" y2="-3.81" width="0.1524" layer="91"/>
<label x="233.68" y="-3.556" size="1.524" layer="95"/>
<wire x1="231.14" y1="-2.54" x2="232.41" y2="-3.81" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U12" gate="B" pin="G"/>
<wire x1="256.54" y1="-26.67" x2="232.41" y2="-26.67" width="0.1524" layer="91"/>
<label x="233.68" y="-26.416" size="1.524" layer="95"/>
<wire x1="231.14" y1="-25.4" x2="232.41" y2="-26.67" width="0.1524" layer="91"/>
</segment>
</net>
<net name="INP_A11-A21" class="0">
<segment>
<pinref part="CN1" gate="A" pin="15"/>
<wire x1="21.59" y1="-88.9" x2="-2.54" y2="-88.9" width="0.1524" layer="91"/>
<label x="-1.27" y="-88.646" size="1.524" layer="95"/>
<wire x1="-3.81" y1="-87.63" x2="-2.54" y2="-88.9" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U14" gate="A" pin="P1"/>
<wire x1="177.8" y1="8.89" x2="153.67" y2="8.89" width="0.1524" layer="91"/>
<label x="154.94" y="9.144" size="1.524" layer="95"/>
<wire x1="152.4" y1="10.16" x2="153.67" y2="8.89" width="0.1524" layer="91"/>
</segment>
</net>
<net name="RES_A11-A21" class="0">
<segment>
<pinref part="CN1" gate="A" pin="18"/>
<wire x1="21.59" y1="-96.52" x2="-2.54" y2="-96.52" width="0.1524" layer="91"/>
<label x="-1.27" y="-96.266" size="1.524" layer="95"/>
<wire x1="-3.81" y1="-95.25" x2="-2.54" y2="-96.52" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U14" gate="A" pin="RES"/>
<wire x1="177.8" y1="-19.05" x2="153.67" y2="-19.05" width="0.1524" layer="91"/>
<label x="154.94" y="-18.796" size="1.524" layer="95"/>
<wire x1="152.4" y1="-17.78" x2="153.67" y2="-19.05" width="0.1524" layer="91"/>
</segment>
</net>
<net name="INP_A0-A10" class="0">
<segment>
<pinref part="CN1" gate="A" pin="16"/>
<wire x1="21.59" y1="-91.44" x2="-2.54" y2="-91.44" width="0.1524" layer="91"/>
<label x="-1.27" y="-91.186" size="1.524" layer="95"/>
<wire x1="-3.81" y1="-90.17" x2="-2.54" y2="-91.44" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U13" gate="A" pin="P1"/>
<wire x1="20.32" y1="8.89" x2="-2.54" y2="8.89" width="0.1524" layer="91"/>
<label x="-1.27" y="9.144" size="1.524" layer="95"/>
<wire x1="-3.81" y1="10.16" x2="-2.54" y2="8.89" width="0.1524" layer="91"/>
</segment>
</net>
<net name="RES_A0-A10" class="0">
<segment>
<pinref part="CN1" gate="A" pin="17"/>
<wire x1="21.59" y1="-93.98" x2="-2.54" y2="-93.98" width="0.1524" layer="91"/>
<label x="-1.27" y="-93.726" size="1.524" layer="95"/>
<wire x1="-3.81" y1="-92.71" x2="-2.54" y2="-93.98" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U13" gate="A" pin="RES"/>
<wire x1="20.32" y1="-19.05" x2="-2.54" y2="-19.05" width="0.1524" layer="91"/>
<label x="-1.27" y="-18.796" size="1.524" layer="95"/>
<wire x1="-3.81" y1="-17.78" x2="-2.54" y2="-19.05" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$1" class="0">
<segment>
<pinref part="U13" gate="A" pin="Q1"/>
<pinref part="U10" gate="A1" pin="A"/>
<wire x1="50.8" y1="8.89" x2="99.06" y2="8.89" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$2" class="0">
<segment>
<pinref part="U13" gate="A" pin="Q2"/>
<pinref part="U10" gate="A2" pin="A"/>
<wire x1="50.8" y1="6.35" x2="99.06" y2="6.35" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$3" class="0">
<segment>
<pinref part="U13" gate="A" pin="Q3"/>
<pinref part="U10" gate="A3" pin="A"/>
<wire x1="50.8" y1="3.81" x2="99.06" y2="3.81" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$4" class="0">
<segment>
<pinref part="U13" gate="A" pin="Q4"/>
<pinref part="U10" gate="A4" pin="A"/>
<wire x1="50.8" y1="1.27" x2="99.06" y2="1.27" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$5" class="0">
<segment>
<pinref part="U13" gate="A" pin="Q5"/>
<wire x1="50.8" y1="-1.27" x2="68.58" y2="-1.27" width="0.1524" layer="91"/>
<wire x1="68.58" y1="-1.27" x2="68.58" y2="-13.97" width="0.1524" layer="91"/>
<pinref part="U10" gate="B1" pin="A"/>
<wire x1="68.58" y1="-13.97" x2="99.06" y2="-13.97" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$6" class="0">
<segment>
<pinref part="U13" gate="A" pin="Q6"/>
<wire x1="50.8" y1="-3.81" x2="66.04" y2="-3.81" width="0.1524" layer="91"/>
<wire x1="66.04" y1="-3.81" x2="66.04" y2="-16.51" width="0.1524" layer="91"/>
<pinref part="U10" gate="B2" pin="A"/>
<wire x1="66.04" y1="-16.51" x2="99.06" y2="-16.51" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$7" class="0">
<segment>
<pinref part="U13" gate="A" pin="Q7"/>
<wire x1="50.8" y1="-6.35" x2="63.5" y2="-6.35" width="0.1524" layer="91"/>
<wire x1="63.5" y1="-6.35" x2="63.5" y2="-19.05" width="0.1524" layer="91"/>
<pinref part="U10" gate="B3" pin="A"/>
<wire x1="63.5" y1="-19.05" x2="99.06" y2="-19.05" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$8" class="0">
<segment>
<pinref part="U13" gate="A" pin="Q8"/>
<wire x1="50.8" y1="-8.89" x2="60.96" y2="-8.89" width="0.1524" layer="91"/>
<wire x1="60.96" y1="-8.89" x2="60.96" y2="-21.59" width="0.1524" layer="91"/>
<pinref part="U10" gate="B4" pin="A"/>
<wire x1="60.96" y1="-21.59" x2="99.06" y2="-21.59" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$9" class="0">
<segment>
<pinref part="U13" gate="A" pin="Q9"/>
<wire x1="50.8" y1="-11.43" x2="58.42" y2="-11.43" width="0.1524" layer="91"/>
<wire x1="58.42" y1="-11.43" x2="58.42" y2="-36.83" width="0.1524" layer="91"/>
<pinref part="U11" gate="A1" pin="A"/>
<wire x1="58.42" y1="-36.83" x2="99.06" y2="-36.83" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$10" class="0">
<segment>
<pinref part="U13" gate="A" pin="Q10"/>
<wire x1="50.8" y1="-13.97" x2="55.88" y2="-13.97" width="0.1524" layer="91"/>
<pinref part="U11" gate="A2" pin="A"/>
<wire x1="55.88" y1="-13.97" x2="55.88" y2="-39.37" width="0.1524" layer="91"/>
<wire x1="55.88" y1="-39.37" x2="99.06" y2="-39.37" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$11" class="0">
<segment>
<pinref part="U13" gate="A" pin="Q11"/>
<wire x1="50.8" y1="-16.51" x2="53.34" y2="-16.51" width="0.1524" layer="91"/>
<pinref part="U11" gate="A3" pin="A"/>
<wire x1="53.34" y1="-16.51" x2="53.34" y2="-41.91" width="0.1524" layer="91"/>
<wire x1="53.34" y1="-41.91" x2="99.06" y2="-41.91" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$12" class="0">
<segment>
<pinref part="U14" gate="A" pin="Q1"/>
<pinref part="U12" gate="A1" pin="A"/>
<wire x1="208.28" y1="8.89" x2="256.54" y2="8.89" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$13" class="0">
<segment>
<pinref part="U14" gate="A" pin="Q2"/>
<pinref part="U12" gate="A2" pin="A"/>
<wire x1="208.28" y1="6.35" x2="256.54" y2="6.35" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$14" class="0">
<segment>
<pinref part="U14" gate="A" pin="Q3"/>
<pinref part="U12" gate="A3" pin="A"/>
<wire x1="208.28" y1="3.81" x2="256.54" y2="3.81" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$15" class="0">
<segment>
<pinref part="U14" gate="A" pin="Q4"/>
<pinref part="U12" gate="A4" pin="A"/>
<wire x1="208.28" y1="1.27" x2="256.54" y2="1.27" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$16" class="0">
<segment>
<pinref part="U14" gate="A" pin="Q5"/>
<wire x1="208.28" y1="-1.27" x2="226.06" y2="-1.27" width="0.1524" layer="91"/>
<wire x1="226.06" y1="-1.27" x2="226.06" y2="-13.97" width="0.1524" layer="91"/>
<pinref part="U12" gate="B1" pin="A"/>
<wire x1="226.06" y1="-13.97" x2="256.54" y2="-13.97" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$17" class="0">
<segment>
<pinref part="U14" gate="A" pin="Q6"/>
<wire x1="208.28" y1="-3.81" x2="223.52" y2="-3.81" width="0.1524" layer="91"/>
<pinref part="U12" gate="B2" pin="A"/>
<wire x1="223.52" y1="-3.81" x2="223.52" y2="-16.51" width="0.1524" layer="91"/>
<wire x1="223.52" y1="-16.51" x2="256.54" y2="-16.51" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$18" class="0">
<segment>
<pinref part="U14" gate="A" pin="Q7"/>
<wire x1="208.28" y1="-6.35" x2="220.98" y2="-6.35" width="0.1524" layer="91"/>
<pinref part="U12" gate="B3" pin="A"/>
<wire x1="220.98" y1="-6.35" x2="220.98" y2="-19.05" width="0.1524" layer="91"/>
<wire x1="220.98" y1="-19.05" x2="256.54" y2="-19.05" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$19" class="0">
<segment>
<pinref part="U14" gate="A" pin="Q8"/>
<wire x1="208.28" y1="-8.89" x2="218.44" y2="-8.89" width="0.1524" layer="91"/>
<pinref part="U12" gate="B4" pin="A"/>
<wire x1="218.44" y1="-8.89" x2="218.44" y2="-21.59" width="0.1524" layer="91"/>
<wire x1="218.44" y1="-21.59" x2="256.54" y2="-21.59" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$20" class="0">
<segment>
<pinref part="U14" gate="A" pin="Q9"/>
<wire x1="208.28" y1="-11.43" x2="215.9" y2="-11.43" width="0.1524" layer="91"/>
<pinref part="U11" gate="B1" pin="A"/>
<wire x1="215.9" y1="-11.43" x2="215.9" y2="-36.83" width="0.1524" layer="91"/>
<wire x1="215.9" y1="-36.83" x2="256.54" y2="-36.83" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$21" class="0">
<segment>
<pinref part="U14" gate="A" pin="Q10"/>
<wire x1="208.28" y1="-13.97" x2="213.36" y2="-13.97" width="0.1524" layer="91"/>
<pinref part="U11" gate="B2" pin="A"/>
<wire x1="213.36" y1="-13.97" x2="213.36" y2="-39.37" width="0.1524" layer="91"/>
<wire x1="213.36" y1="-39.37" x2="256.54" y2="-39.37" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$22" class="0">
<segment>
<pinref part="U14" gate="A" pin="Q11"/>
<wire x1="208.28" y1="-16.51" x2="210.82" y2="-16.51" width="0.1524" layer="91"/>
<pinref part="U11" gate="B3" pin="A"/>
<wire x1="210.82" y1="-16.51" x2="210.82" y2="-41.91" width="0.1524" layer="91"/>
<wire x1="210.82" y1="-41.91" x2="256.54" y2="-41.91" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D0/16" class="0">
<segment>
<pinref part="CN1" gate="A" pin="25"/>
<wire x1="49.53" y1="-91.44" x2="72.39" y2="-91.44" width="0.1524" layer="91"/>
<label x="71.12" y="-91.186" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-90.17" x2="72.39" y2="-91.44" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U1" gate="A1" pin="Y"/>
<wire x1="20.32" y1="111.76" x2="17.78" y2="111.76" width="0.1524" layer="91"/>
<pinref part="U5" gate="A1" pin="A"/>
<wire x1="20.32" y1="88.9" x2="17.78" y2="88.9" width="0.1524" layer="91"/>
<label x="-1.27" y="89.154" size="1.524" layer="95"/>
<wire x1="17.78" y1="88.9" x2="-2.54" y2="88.9" width="0.1524" layer="91"/>
<wire x1="17.78" y1="111.76" x2="17.78" y2="88.9" width="0.1524" layer="91"/>
<junction x="17.78" y="88.9"/>
<wire x1="-3.81" y1="90.17" x2="-2.54" y2="88.9" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U9" gate="A1" pin="A"/>
<wire x1="99.06" y1="-88.9" x2="74.93" y2="-88.9" width="0.1524" layer="91"/>
<label x="76.2" y="-88.646" size="1.524" layer="95"/>
<wire x1="73.66" y1="-87.63" x2="74.93" y2="-88.9" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U3" gate="A1" pin="Y"/>
<wire x1="177.8" y1="111.76" x2="175.26" y2="111.76" width="0.1524" layer="91"/>
<pinref part="U7" gate="A1" pin="A"/>
<wire x1="177.8" y1="88.9" x2="175.26" y2="88.9" width="0.1524" layer="91"/>
<label x="154.94" y="89.154" size="1.524" layer="95"/>
<wire x1="175.26" y1="88.9" x2="153.67" y2="88.9" width="0.1524" layer="91"/>
<wire x1="175.26" y1="111.76" x2="175.26" y2="88.9" width="0.1524" layer="91"/>
<junction x="175.26" y="88.9"/>
<wire x1="152.4" y1="90.17" x2="153.67" y2="88.9" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D1/17" class="0">
<segment>
<pinref part="CN1" gate="A" pin="26"/>
<wire x1="49.53" y1="-88.9" x2="72.39" y2="-88.9" width="0.1524" layer="91"/>
<label x="71.12" y="-88.646" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-87.63" x2="72.39" y2="-88.9" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U1" gate="A2" pin="Y"/>
<wire x1="20.32" y1="109.22" x2="15.24" y2="109.22" width="0.1524" layer="91"/>
<pinref part="U5" gate="A2" pin="A"/>
<wire x1="20.32" y1="86.36" x2="15.24" y2="86.36" width="0.1524" layer="91"/>
<label x="-1.27" y="86.614" size="1.524" layer="95"/>
<wire x1="15.24" y1="86.36" x2="-2.54" y2="86.36" width="0.1524" layer="91"/>
<wire x1="15.24" y1="109.22" x2="15.24" y2="86.36" width="0.1524" layer="91"/>
<junction x="15.24" y="86.36"/>
<wire x1="-3.81" y1="87.63" x2="-2.54" y2="86.36" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U9" gate="A2" pin="A"/>
<wire x1="99.06" y1="-91.44" x2="74.93" y2="-91.44" width="0.1524" layer="91"/>
<label x="76.2" y="-91.186" size="1.524" layer="95"/>
<wire x1="73.66" y1="-90.17" x2="74.93" y2="-91.44" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U3" gate="A2" pin="Y"/>
<wire x1="177.8" y1="109.22" x2="172.72" y2="109.22" width="0.1524" layer="91"/>
<pinref part="U7" gate="A2" pin="A"/>
<wire x1="177.8" y1="86.36" x2="172.72" y2="86.36" width="0.1524" layer="91"/>
<label x="154.94" y="86.614" size="1.524" layer="95"/>
<wire x1="172.72" y1="86.36" x2="153.67" y2="86.36" width="0.1524" layer="91"/>
<wire x1="172.72" y1="109.22" x2="172.72" y2="86.36" width="0.1524" layer="91"/>
<junction x="172.72" y="86.36"/>
<wire x1="152.4" y1="87.63" x2="153.67" y2="86.36" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D34" class="0">
<segment>
<pinref part="U9" gate="B1" pin="Y"/>
<wire x1="99.06" y1="-66.04" x2="74.93" y2="-66.04" width="0.1524" layer="91"/>
<label x="76.2" y="-65.786" size="1.524" layer="95"/>
<wire x1="73.66" y1="-64.77" x2="74.93" y2="-66.04" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="CN1" gate="A" pin="24"/>
<wire x1="49.53" y1="-93.98" x2="72.39" y2="-93.98" width="0.1524" layer="91"/>
<label x="71.12" y="-93.726" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-92.71" x2="72.39" y2="-93.98" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D32" class="0">
<segment>
<pinref part="U9" gate="B2" pin="Y"/>
<wire x1="99.06" y1="-68.58" x2="74.93" y2="-68.58" width="0.1524" layer="91"/>
<label x="76.2" y="-68.326" size="1.524" layer="95"/>
<wire x1="73.66" y1="-67.31" x2="74.93" y2="-68.58" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="CN1" gate="A" pin="23"/>
<wire x1="49.53" y1="-96.52" x2="72.39" y2="-96.52" width="0.1524" layer="91"/>
<label x="71.12" y="-96.266" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-95.25" x2="72.39" y2="-96.52" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D33" class="0">
<segment>
<pinref part="U9" gate="B3" pin="Y"/>
<wire x1="99.06" y1="-71.12" x2="74.93" y2="-71.12" width="0.1524" layer="91"/>
<label x="76.2" y="-70.866" size="1.524" layer="95"/>
<wire x1="73.66" y1="-69.85" x2="74.93" y2="-71.12" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="CN1" gate="A" pin="22"/>
<wire x1="49.53" y1="-99.06" x2="72.39" y2="-99.06" width="0.1524" layer="91"/>
<label x="71.12" y="-98.806" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-97.79" x2="72.39" y2="-99.06" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D35" class="0">
<segment>
<pinref part="U9" gate="B4" pin="Y"/>
<wire x1="99.06" y1="-73.66" x2="74.93" y2="-73.66" width="0.1524" layer="91"/>
<label x="76.2" y="-73.406" size="1.524" layer="95"/>
<wire x1="73.66" y1="-72.39" x2="74.93" y2="-73.66" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="CN1" gate="A" pin="21"/>
<wire x1="49.53" y1="-101.6" x2="72.39" y2="-101.6" width="0.1524" layer="91"/>
<label x="71.12" y="-101.346" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-100.33" x2="72.39" y2="-101.6" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D2/18" class="0">
<segment>
<pinref part="U1" gate="A3" pin="Y"/>
<wire x1="20.32" y1="106.68" x2="12.7" y2="106.68" width="0.1524" layer="91"/>
<pinref part="U5" gate="A3" pin="A"/>
<wire x1="20.32" y1="83.82" x2="12.7" y2="83.82" width="0.1524" layer="91"/>
<label x="-1.27" y="84.074" size="1.524" layer="95"/>
<wire x1="12.7" y1="83.82" x2="-2.54" y2="83.82" width="0.1524" layer="91"/>
<wire x1="12.7" y1="106.68" x2="12.7" y2="83.82" width="0.1524" layer="91"/>
<junction x="12.7" y="83.82"/>
<wire x1="-3.81" y1="85.09" x2="-2.54" y2="83.82" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U3" gate="A3" pin="Y"/>
<wire x1="177.8" y1="106.68" x2="170.18" y2="106.68" width="0.1524" layer="91"/>
<pinref part="U7" gate="A3" pin="A"/>
<wire x1="177.8" y1="83.82" x2="170.18" y2="83.82" width="0.1524" layer="91"/>
<label x="154.94" y="84.074" size="1.524" layer="95"/>
<wire x1="170.18" y1="83.82" x2="153.67" y2="83.82" width="0.1524" layer="91"/>
<wire x1="170.18" y1="106.68" x2="170.18" y2="83.82" width="0.1524" layer="91"/>
<junction x="170.18" y="83.82"/>
<wire x1="152.4" y1="85.09" x2="153.67" y2="83.82" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U9" gate="A3" pin="A"/>
<wire x1="99.06" y1="-93.98" x2="74.93" y2="-93.98" width="0.1524" layer="91"/>
<label x="76.2" y="-93.726" size="1.524" layer="95"/>
<wire x1="73.66" y1="-92.71" x2="74.93" y2="-93.98" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="CN1" gate="A" pin="27"/>
<wire x1="49.53" y1="-86.36" x2="72.39" y2="-86.36" width="0.1524" layer="91"/>
<label x="71.12" y="-86.106" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-85.09" x2="72.39" y2="-86.36" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D4/20" class="0">
<segment>
<pinref part="CN1" gate="A" pin="29"/>
<wire x1="49.53" y1="-81.28" x2="72.39" y2="-81.28" width="0.1524" layer="91"/>
<label x="71.12" y="-81.026" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-80.01" x2="72.39" y2="-81.28" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U1" gate="B1" pin="Y"/>
<wire x1="20.32" y1="59.69" x2="17.78" y2="59.69" width="0.1524" layer="91"/>
<pinref part="U5" gate="B1" pin="A"/>
<wire x1="20.32" y1="36.83" x2="17.78" y2="36.83" width="0.1524" layer="91"/>
<label x="-1.27" y="37.084" size="1.524" layer="95"/>
<wire x1="17.78" y1="36.83" x2="-2.54" y2="36.83" width="0.1524" layer="91"/>
<wire x1="17.78" y1="59.69" x2="17.78" y2="36.83" width="0.1524" layer="91"/>
<junction x="17.78" y="36.83"/>
<wire x1="-3.81" y1="38.1" x2="-2.54" y2="36.83" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U3" gate="B1" pin="Y"/>
<wire x1="177.8" y1="59.69" x2="175.26" y2="59.69" width="0.1524" layer="91"/>
<pinref part="U7" gate="B1" pin="A"/>
<wire x1="177.8" y1="36.83" x2="175.26" y2="36.83" width="0.1524" layer="91"/>
<label x="154.94" y="37.084" size="1.524" layer="95"/>
<wire x1="175.26" y1="36.83" x2="153.67" y2="36.83" width="0.1524" layer="91"/>
<wire x1="175.26" y1="59.69" x2="175.26" y2="36.83" width="0.1524" layer="91"/>
<junction x="175.26" y="36.83"/>
<wire x1="152.4" y1="38.1" x2="153.67" y2="36.83" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D5/21" class="0">
<segment>
<pinref part="CN1" gate="A" pin="30"/>
<wire x1="49.53" y1="-78.74" x2="72.39" y2="-78.74" width="0.1524" layer="91"/>
<label x="71.12" y="-78.486" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-77.47" x2="72.39" y2="-78.74" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U1" gate="B2" pin="Y"/>
<wire x1="20.32" y1="57.15" x2="15.24" y2="57.15" width="0.1524" layer="91"/>
<pinref part="U5" gate="B2" pin="A"/>
<wire x1="20.32" y1="34.29" x2="15.24" y2="34.29" width="0.1524" layer="91"/>
<label x="-1.27" y="34.544" size="1.524" layer="95"/>
<wire x1="15.24" y1="34.29" x2="-2.54" y2="34.29" width="0.1524" layer="91"/>
<wire x1="15.24" y1="57.15" x2="15.24" y2="34.29" width="0.1524" layer="91"/>
<junction x="15.24" y="34.29"/>
<wire x1="-3.81" y1="35.56" x2="-2.54" y2="34.29" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U3" gate="B2" pin="Y"/>
<wire x1="177.8" y1="57.15" x2="172.72" y2="57.15" width="0.1524" layer="91"/>
<pinref part="U7" gate="B2" pin="A"/>
<wire x1="177.8" y1="34.29" x2="172.72" y2="34.29" width="0.1524" layer="91"/>
<label x="154.94" y="34.544" size="1.524" layer="95"/>
<wire x1="172.72" y1="34.29" x2="153.67" y2="34.29" width="0.1524" layer="91"/>
<wire x1="172.72" y1="57.15" x2="172.72" y2="34.29" width="0.1524" layer="91"/>
<junction x="172.72" y="34.29"/>
<wire x1="152.4" y1="35.56" x2="153.67" y2="34.29" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D6/22" class="0">
<segment>
<pinref part="CN1" gate="A" pin="31"/>
<wire x1="49.53" y1="-76.2" x2="72.39" y2="-76.2" width="0.1524" layer="91"/>
<label x="71.12" y="-75.946" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-74.93" x2="72.39" y2="-76.2" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U1" gate="B3" pin="Y"/>
<wire x1="20.32" y1="54.61" x2="12.7" y2="54.61" width="0.1524" layer="91"/>
<pinref part="U5" gate="B3" pin="A"/>
<wire x1="20.32" y1="31.75" x2="12.7" y2="31.75" width="0.1524" layer="91"/>
<label x="-1.27" y="32.004" size="1.524" layer="95"/>
<wire x1="12.7" y1="31.75" x2="-2.54" y2="31.75" width="0.1524" layer="91"/>
<wire x1="12.7" y1="54.61" x2="12.7" y2="31.75" width="0.1524" layer="91"/>
<junction x="12.7" y="31.75"/>
<wire x1="-3.81" y1="33.02" x2="-2.54" y2="31.75" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U3" gate="B3" pin="Y"/>
<wire x1="177.8" y1="54.61" x2="170.18" y2="54.61" width="0.1524" layer="91"/>
<pinref part="U7" gate="B3" pin="A"/>
<wire x1="177.8" y1="31.75" x2="170.18" y2="31.75" width="0.1524" layer="91"/>
<label x="154.94" y="32.004" size="1.524" layer="95"/>
<wire x1="170.18" y1="31.75" x2="153.67" y2="31.75" width="0.1524" layer="91"/>
<wire x1="170.18" y1="54.61" x2="170.18" y2="31.75" width="0.1524" layer="91"/>
<junction x="170.18" y="31.75"/>
<wire x1="152.4" y1="33.02" x2="153.67" y2="31.75" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D7/23" class="0">
<segment>
<pinref part="CN1" gate="A" pin="32"/>
<wire x1="49.53" y1="-73.66" x2="72.39" y2="-73.66" width="0.1524" layer="91"/>
<label x="71.12" y="-73.406" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-72.39" x2="72.39" y2="-73.66" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U1" gate="B4" pin="Y"/>
<wire x1="20.32" y1="52.07" x2="10.16" y2="52.07" width="0.1524" layer="91"/>
<pinref part="U5" gate="B4" pin="A"/>
<wire x1="20.32" y1="29.21" x2="10.16" y2="29.21" width="0.1524" layer="91"/>
<label x="-1.27" y="29.464" size="1.524" layer="95"/>
<wire x1="10.16" y1="29.21" x2="-2.54" y2="29.21" width="0.1524" layer="91"/>
<wire x1="10.16" y1="52.07" x2="10.16" y2="29.21" width="0.1524" layer="91"/>
<junction x="10.16" y="29.21"/>
<wire x1="-3.81" y1="30.48" x2="-2.54" y2="29.21" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U3" gate="B4" pin="Y"/>
<wire x1="177.8" y1="52.07" x2="167.64" y2="52.07" width="0.1524" layer="91"/>
<pinref part="U7" gate="B4" pin="A"/>
<wire x1="177.8" y1="29.21" x2="167.64" y2="29.21" width="0.1524" layer="91"/>
<label x="154.94" y="29.464" size="1.524" layer="95"/>
<wire x1="167.64" y1="29.21" x2="153.67" y2="29.21" width="0.1524" layer="91"/>
<wire x1="167.64" y1="52.07" x2="167.64" y2="29.21" width="0.1524" layer="91"/>
<junction x="167.64" y="29.21"/>
<wire x1="152.4" y1="30.48" x2="153.67" y2="29.21" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D8/24" class="0">
<segment>
<pinref part="U6" gate="A1" pin="A"/>
<wire x1="99.06" y1="88.9" x2="96.52" y2="88.9" width="0.1524" layer="91"/>
<pinref part="U2" gate="A1" pin="Y"/>
<wire x1="96.52" y1="88.9" x2="74.93" y2="88.9" width="0.1524" layer="91"/>
<wire x1="99.06" y1="111.76" x2="96.52" y2="111.76" width="0.1524" layer="91"/>
<wire x1="96.52" y1="111.76" x2="96.52" y2="88.9" width="0.1524" layer="91"/>
<junction x="96.52" y="88.9"/>
<label x="76.2" y="89.154" size="1.524" layer="95"/>
<wire x1="73.66" y1="90.17" x2="74.93" y2="88.9" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U8" gate="A1" pin="A"/>
<wire x1="256.54" y1="88.9" x2="254" y2="88.9" width="0.1524" layer="91"/>
<pinref part="U4" gate="A1" pin="Y"/>
<wire x1="254" y1="88.9" x2="232.41" y2="88.9" width="0.1524" layer="91"/>
<wire x1="256.54" y1="111.76" x2="254" y2="111.76" width="0.1524" layer="91"/>
<wire x1="254" y1="111.76" x2="254" y2="88.9" width="0.1524" layer="91"/>
<junction x="254" y="88.9"/>
<label x="233.68" y="89.154" size="1.524" layer="95"/>
<wire x1="231.14" y1="90.17" x2="232.41" y2="88.9" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="CN1" gate="A" pin="33"/>
<wire x1="49.53" y1="-71.12" x2="72.39" y2="-71.12" width="0.1524" layer="91"/>
<label x="71.12" y="-70.866" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-69.85" x2="72.39" y2="-71.12" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D9/25" class="0">
<segment>
<pinref part="U6" gate="A2" pin="A"/>
<wire x1="99.06" y1="86.36" x2="93.98" y2="86.36" width="0.1524" layer="91"/>
<pinref part="U2" gate="A2" pin="Y"/>
<wire x1="93.98" y1="86.36" x2="74.93" y2="86.36" width="0.1524" layer="91"/>
<wire x1="99.06" y1="109.22" x2="93.98" y2="109.22" width="0.1524" layer="91"/>
<wire x1="93.98" y1="109.22" x2="93.98" y2="86.36" width="0.1524" layer="91"/>
<junction x="93.98" y="86.36"/>
<label x="76.2" y="86.614" size="1.524" layer="95"/>
<wire x1="73.66" y1="87.63" x2="74.93" y2="86.36" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U8" gate="A2" pin="A"/>
<wire x1="256.54" y1="86.36" x2="251.46" y2="86.36" width="0.1524" layer="91"/>
<pinref part="U4" gate="A2" pin="Y"/>
<wire x1="251.46" y1="86.36" x2="232.41" y2="86.36" width="0.1524" layer="91"/>
<wire x1="256.54" y1="109.22" x2="251.46" y2="109.22" width="0.1524" layer="91"/>
<wire x1="251.46" y1="109.22" x2="251.46" y2="86.36" width="0.1524" layer="91"/>
<junction x="251.46" y="86.36"/>
<label x="233.68" y="86.614" size="1.524" layer="95"/>
<wire x1="231.14" y1="87.63" x2="232.41" y2="86.36" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="CN1" gate="A" pin="34"/>
<wire x1="49.53" y1="-68.58" x2="72.39" y2="-68.58" width="0.1524" layer="91"/>
<label x="71.12" y="-68.326" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-67.31" x2="72.39" y2="-68.58" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D10/26" class="0">
<segment>
<pinref part="U6" gate="A3" pin="A"/>
<wire x1="99.06" y1="83.82" x2="91.44" y2="83.82" width="0.1524" layer="91"/>
<pinref part="U2" gate="A3" pin="Y"/>
<wire x1="91.44" y1="83.82" x2="74.93" y2="83.82" width="0.1524" layer="91"/>
<wire x1="99.06" y1="106.68" x2="91.44" y2="106.68" width="0.1524" layer="91"/>
<wire x1="91.44" y1="106.68" x2="91.44" y2="83.82" width="0.1524" layer="91"/>
<junction x="91.44" y="83.82"/>
<label x="76.2" y="84.074" size="1.524" layer="95"/>
<wire x1="73.66" y1="85.09" x2="74.93" y2="83.82" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U8" gate="A3" pin="A"/>
<wire x1="256.54" y1="83.82" x2="248.92" y2="83.82" width="0.1524" layer="91"/>
<pinref part="U4" gate="A3" pin="Y"/>
<wire x1="248.92" y1="83.82" x2="232.41" y2="83.82" width="0.1524" layer="91"/>
<wire x1="256.54" y1="106.68" x2="248.92" y2="106.68" width="0.1524" layer="91"/>
<wire x1="248.92" y1="106.68" x2="248.92" y2="83.82" width="0.1524" layer="91"/>
<junction x="248.92" y="83.82"/>
<label x="233.68" y="84.074" size="1.524" layer="95"/>
<wire x1="231.14" y1="85.09" x2="232.41" y2="83.82" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="CN1" gate="A" pin="35"/>
<wire x1="49.53" y1="-66.04" x2="72.39" y2="-66.04" width="0.1524" layer="91"/>
<label x="71.12" y="-65.786" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-64.77" x2="72.39" y2="-66.04" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D11/27" class="0">
<segment>
<pinref part="U6" gate="A4" pin="A"/>
<wire x1="99.06" y1="81.28" x2="88.9" y2="81.28" width="0.1524" layer="91"/>
<pinref part="U2" gate="A4" pin="Y"/>
<wire x1="88.9" y1="81.28" x2="74.93" y2="81.28" width="0.1524" layer="91"/>
<wire x1="99.06" y1="104.14" x2="88.9" y2="104.14" width="0.1524" layer="91"/>
<wire x1="88.9" y1="104.14" x2="88.9" y2="81.28" width="0.1524" layer="91"/>
<junction x="88.9" y="81.28"/>
<label x="76.2" y="81.534" size="1.524" layer="95"/>
<wire x1="73.66" y1="82.55" x2="74.93" y2="81.28" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U8" gate="A4" pin="A"/>
<wire x1="256.54" y1="81.28" x2="246.38" y2="81.28" width="0.1524" layer="91"/>
<pinref part="U4" gate="A4" pin="Y"/>
<wire x1="246.38" y1="81.28" x2="232.41" y2="81.28" width="0.1524" layer="91"/>
<wire x1="256.54" y1="104.14" x2="246.38" y2="104.14" width="0.1524" layer="91"/>
<wire x1="246.38" y1="104.14" x2="246.38" y2="81.28" width="0.1524" layer="91"/>
<junction x="246.38" y="81.28"/>
<label x="233.68" y="81.534" size="1.524" layer="95"/>
<wire x1="231.14" y1="82.55" x2="232.41" y2="81.28" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="CN1" gate="A" pin="36"/>
<wire x1="49.53" y1="-63.5" x2="72.39" y2="-63.5" width="0.1524" layer="91"/>
<label x="71.12" y="-63.246" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-62.23" x2="72.39" y2="-63.5" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D12/28" class="0">
<segment>
<pinref part="U6" gate="B1" pin="A"/>
<wire x1="99.06" y1="36.83" x2="96.52" y2="36.83" width="0.1524" layer="91"/>
<pinref part="U2" gate="B1" pin="Y"/>
<wire x1="96.52" y1="36.83" x2="74.93" y2="36.83" width="0.1524" layer="91"/>
<wire x1="99.06" y1="59.69" x2="96.52" y2="59.69" width="0.1524" layer="91"/>
<wire x1="96.52" y1="59.69" x2="96.52" y2="36.83" width="0.1524" layer="91"/>
<junction x="96.52" y="36.83"/>
<label x="76.2" y="37.084" size="1.524" layer="95"/>
<wire x1="73.66" y1="38.1" x2="74.93" y2="36.83" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U8" gate="B1" pin="A"/>
<wire x1="256.54" y1="36.83" x2="254" y2="36.83" width="0.1524" layer="91"/>
<wire x1="254" y1="36.83" x2="232.41" y2="36.83" width="0.1524" layer="91"/>
<wire x1="254" y1="59.69" x2="254" y2="36.83" width="0.1524" layer="91"/>
<junction x="254" y="36.83"/>
<label x="233.68" y="37.084" size="1.524" layer="95"/>
<wire x1="231.14" y1="38.1" x2="232.41" y2="36.83" width="0.1524" layer="91"/>
<pinref part="U4" gate="B1" pin="Y"/>
<wire x1="254" y1="59.69" x2="256.54" y2="59.69" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="CN1" gate="A" pin="37"/>
<wire x1="49.53" y1="-60.96" x2="72.39" y2="-60.96" width="0.1524" layer="91"/>
<label x="71.12" y="-60.706" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-59.69" x2="72.39" y2="-60.96" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D3/19" class="0">
<segment>
<pinref part="CN1" gate="A" pin="28"/>
<wire x1="49.53" y1="-83.82" x2="72.39" y2="-83.82" width="0.1524" layer="91"/>
<label x="71.12" y="-83.566" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-82.55" x2="72.39" y2="-83.82" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U1" gate="A4" pin="Y"/>
<wire x1="20.32" y1="104.14" x2="10.16" y2="104.14" width="0.1524" layer="91"/>
<pinref part="U5" gate="A4" pin="A"/>
<wire x1="20.32" y1="81.28" x2="10.16" y2="81.28" width="0.1524" layer="91"/>
<label x="-1.27" y="81.534" size="1.524" layer="95"/>
<wire x1="10.16" y1="81.28" x2="-2.54" y2="81.28" width="0.1524" layer="91"/>
<wire x1="10.16" y1="104.14" x2="10.16" y2="81.28" width="0.1524" layer="91"/>
<junction x="10.16" y="81.28"/>
<wire x1="-3.81" y1="82.55" x2="-2.54" y2="81.28" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U9" gate="A4" pin="A"/>
<wire x1="99.06" y1="-96.52" x2="74.93" y2="-96.52" width="0.1524" layer="91"/>
<label x="76.2" y="-96.266" size="1.524" layer="95"/>
<wire x1="73.66" y1="-95.25" x2="74.93" y2="-96.52" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U3" gate="A4" pin="Y"/>
<wire x1="177.8" y1="104.14" x2="167.64" y2="104.14" width="0.1524" layer="91"/>
<pinref part="U7" gate="A4" pin="A"/>
<wire x1="177.8" y1="81.28" x2="167.64" y2="81.28" width="0.1524" layer="91"/>
<label x="154.94" y="81.534" size="1.524" layer="95"/>
<wire x1="167.64" y1="81.28" x2="153.67" y2="81.28" width="0.1524" layer="91"/>
<wire x1="167.64" y1="104.14" x2="167.64" y2="81.28" width="0.1524" layer="91"/>
<junction x="167.64" y="81.28"/>
<wire x1="152.4" y1="82.55" x2="153.67" y2="81.28" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D13/29" class="0">
<segment>
<pinref part="CN1" gate="A" pin="38"/>
<wire x1="49.53" y1="-58.42" x2="72.39" y2="-58.42" width="0.1524" layer="91"/>
<label x="71.12" y="-58.166" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-57.15" x2="72.39" y2="-58.42" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U6" gate="B2" pin="A"/>
<wire x1="99.06" y1="34.29" x2="93.98" y2="34.29" width="0.1524" layer="91"/>
<pinref part="U2" gate="B2" pin="Y"/>
<wire x1="93.98" y1="34.29" x2="74.93" y2="34.29" width="0.1524" layer="91"/>
<wire x1="99.06" y1="57.15" x2="93.98" y2="57.15" width="0.1524" layer="91"/>
<wire x1="93.98" y1="57.15" x2="93.98" y2="34.29" width="0.1524" layer="91"/>
<junction x="93.98" y="34.29"/>
<label x="76.2" y="34.544" size="1.524" layer="95"/>
<wire x1="73.66" y1="35.56" x2="74.93" y2="34.29" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U8" gate="B2" pin="A"/>
<wire x1="256.54" y1="34.29" x2="251.46" y2="34.29" width="0.1524" layer="91"/>
<wire x1="251.46" y1="34.29" x2="232.41" y2="34.29" width="0.1524" layer="91"/>
<wire x1="251.46" y1="57.15" x2="251.46" y2="34.29" width="0.1524" layer="91"/>
<junction x="251.46" y="34.29"/>
<label x="233.68" y="34.544" size="1.524" layer="95"/>
<wire x1="231.14" y1="35.56" x2="232.41" y2="34.29" width="0.1524" layer="91"/>
<pinref part="U4" gate="B2" pin="Y"/>
<wire x1="251.46" y1="57.15" x2="256.54" y2="57.15" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D14/30" class="0">
<segment>
<pinref part="CN1" gate="A" pin="39"/>
<wire x1="49.53" y1="-55.88" x2="72.39" y2="-55.88" width="0.1524" layer="91"/>
<label x="71.12" y="-55.626" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-54.61" x2="72.39" y2="-55.88" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U6" gate="B3" pin="A"/>
<wire x1="99.06" y1="31.75" x2="91.44" y2="31.75" width="0.1524" layer="91"/>
<pinref part="U2" gate="B3" pin="Y"/>
<wire x1="91.44" y1="31.75" x2="74.93" y2="31.75" width="0.1524" layer="91"/>
<wire x1="99.06" y1="54.61" x2="91.44" y2="54.61" width="0.1524" layer="91"/>
<wire x1="91.44" y1="54.61" x2="91.44" y2="31.75" width="0.1524" layer="91"/>
<junction x="91.44" y="31.75"/>
<label x="76.2" y="32.004" size="1.524" layer="95"/>
<wire x1="73.66" y1="33.02" x2="74.93" y2="31.75" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U8" gate="B3" pin="A"/>
<wire x1="256.54" y1="31.75" x2="248.92" y2="31.75" width="0.1524" layer="91"/>
<wire x1="248.92" y1="31.75" x2="232.41" y2="31.75" width="0.1524" layer="91"/>
<junction x="248.92" y="31.75"/>
<label x="233.68" y="32.004" size="1.524" layer="95"/>
<wire x1="248.92" y1="54.61" x2="248.92" y2="31.75" width="0.1524" layer="91"/>
<wire x1="231.14" y1="33.02" x2="232.41" y2="31.75" width="0.1524" layer="91"/>
<pinref part="U4" gate="B3" pin="Y"/>
<wire x1="256.54" y1="54.61" x2="248.92" y2="54.61" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D15/31" class="0">
<segment>
<pinref part="CN1" gate="A" pin="40"/>
<wire x1="49.53" y1="-53.34" x2="72.39" y2="-53.34" width="0.1524" layer="91"/>
<label x="71.12" y="-53.086" size="1.524" layer="95" rot="MR0"/>
<wire x1="73.66" y1="-52.07" x2="72.39" y2="-53.34" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U6" gate="B4" pin="A"/>
<wire x1="99.06" y1="29.21" x2="88.9" y2="29.21" width="0.1524" layer="91"/>
<pinref part="U2" gate="B4" pin="Y"/>
<wire x1="88.9" y1="29.21" x2="74.93" y2="29.21" width="0.1524" layer="91"/>
<wire x1="99.06" y1="52.07" x2="88.9" y2="52.07" width="0.1524" layer="91"/>
<wire x1="88.9" y1="52.07" x2="88.9" y2="29.21" width="0.1524" layer="91"/>
<junction x="88.9" y="29.21"/>
<label x="76.2" y="29.464" size="1.524" layer="95"/>
<wire x1="73.66" y1="30.48" x2="74.93" y2="29.21" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U8" gate="B4" pin="A"/>
<wire x1="256.54" y1="29.21" x2="246.38" y2="29.21" width="0.1524" layer="91"/>
<wire x1="246.38" y1="29.21" x2="232.41" y2="29.21" width="0.1524" layer="91"/>
<junction x="246.38" y="29.21"/>
<label x="233.68" y="29.464" size="1.524" layer="95"/>
<wire x1="246.38" y1="52.07" x2="246.38" y2="29.21" width="0.1524" layer="91"/>
<wire x1="231.14" y1="30.48" x2="232.41" y2="29.21" width="0.1524" layer="91"/>
<pinref part="U4" gate="B4" pin="Y"/>
<wire x1="256.54" y1="52.07" x2="246.38" y2="52.07" width="0.1524" layer="91"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
<errors>
<approved hash="101,1,129.54,-44.45,U11A4,Y,,,,"/>
<approved hash="101,1,287.02,-44.45,U11B4,Y,,,,"/>
<approved hash="104,1,180.34,-80.01,U1P,VCC,VCC4,,,"/>
<approved hash="104,1,195.58,-80.01,U2P,VCC,VCC4,,,"/>
<approved hash="104,1,210.82,-80.01,U3P,VCC,VCC4,,,"/>
<approved hash="104,1,226.06,-80.01,U4P,VCC,VCC4,,,"/>
<approved hash="104,1,241.3,-80.01,U5P,VCC,VCC4,,,"/>
<approved hash="104,1,256.54,-80.01,U6P,VCC,VCC4,,,"/>
<approved hash="104,1,271.78,-80.01,U7P,VCC,VCC4,,,"/>
<approved hash="104,1,287.02,-80.01,U8P,VCC,VCC4,,,"/>
<approved hash="104,1,302.26,-80.01,U9P,VCC,VCC4,,,"/>
<approved hash="104,1,-118.11,-86.36,U10P,VCC,VCC1,,,"/>
<approved hash="104,1,-102.87,-86.36,U11P,VCC,VCC1,,,"/>
<approved hash="202,1,99.06,-44.45,U11A4,A,,,,"/>
<approved hash="202,1,256.54,-44.45,U11B4,A,,,,"/>
<approved hash="104,1,-87.63,-86.36,U12P,VCC,VCC1,,,"/>
<approved hash="104,1,-72.39,-86.36,U13P,VCC,VCC1,,,"/>
<approved hash="104,1,-57.15,-86.36,U14P,VCC,VCC1,,,"/>
</errors>
</schematic>
</drawing>
</eagle>
